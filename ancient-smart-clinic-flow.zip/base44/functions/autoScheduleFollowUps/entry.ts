import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Runs every 5 minutes — auto-schedules follow-up calls for completed appointments
// Logic:
//   - When appointment is Completed: schedule call on day 1
//   - If patient responded "Recovered" on day 1 call: schedule call on day 3
//   - If patient responded "Not Recovered": flag for re-appointment (handled in UI)

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    // Get all completed appointments
    const completedAppts = await base44.asServiceRole.entities.Appointment.filter({ status: 'Completed' });
    console.log(`Found ${completedAppts.length} completed appointments`);

    let scheduled = 0;

    for (const appt of completedAppts) {
      if (!appt.patient_id || !appt.patient_name) continue;

      // Get all follow-ups already linked to this appointment
      const existingFollowUps = await base44.asServiceRole.entities.FollowUpCall.filter({ encounter_id: appt.id });

      // --- Schedule Day 1 follow-up if none exists yet ---
      if (existingFollowUps.length === 0) {
        const day1Date = new Date(appt.updated_date || appt.appointment_date || Date.now());
        day1Date.setDate(day1Date.getDate() + 1);
        day1Date.setHours(10, 0, 0, 0);

        // Get patient phone
        let phone = '';
        if (appt.patient_id) {
          const patients = await base44.asServiceRole.entities.Patient.filter({ id: appt.patient_id });
          phone = patients?.[0]?.phone || '';
        }
        // Also try to parse from notes
        if (!phone && appt.notes) {
          const match = appt.notes.match(/Phone:\s*([^\s|]+)/);
          if (match) phone = match[1];
        }

        await base44.asServiceRole.entities.FollowUpCall.create({
          patient_id: appt.patient_id,
          patient_name: appt.patient_name,
          encounter_id: appt.id,
          phone: phone || '',
          scheduled_date: day1Date.toISOString(),
          status: 'Scheduled',
          patient_response: 'No Answer',
        });

        console.log(`Scheduled Day-1 follow-up for ${appt.patient_name} (appt: ${appt.id})`);
        scheduled++;
        continue;
      }

      // --- Schedule Day 3 follow-up if Day 1 is Recovered and Day 3 doesn't exist yet ---
      const day1Call = existingFollowUps.find(f => f.status === 'Completed' && f.patient_response === 'Recovered');
      const alreadyHasDay3 = existingFollowUps.length >= 2;

      if (day1Call && !alreadyHasDay3) {
        const day3Date = new Date(appt.updated_date || appt.appointment_date || Date.now());
        day3Date.setDate(day3Date.getDate() + 3);
        day3Date.setHours(10, 0, 0, 0);

        await base44.asServiceRole.entities.FollowUpCall.create({
          patient_id: appt.patient_id,
          patient_name: appt.patient_name,
          encounter_id: appt.id,
          phone: day1Call.phone || '',
          scheduled_date: day3Date.toISOString(),
          status: 'Scheduled',
          patient_response: 'No Answer',
        });

        console.log(`Scheduled Day-3 follow-up for ${appt.patient_name}`);
        scheduled++;
      }
    }

    return Response.json({ success: true, scheduled });
  } catch (error) {
    console.error('autoScheduleFollowUps error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});