import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const BASE_URL = "https://api.base44.com/api/apps/6832a61e9fcbf453b4dcd2d3/functions";

// Multi-turn AI phone intake conversation
// Steps: name → age → complaint → duration → triage → save → goodbye
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const url = new URL(req.url);

    // Get step and session data from query params
    const step = url.searchParams.get('step') || 'name';
    const callSid = url.searchParams.get('callSid') || '';
    const from = url.searchParams.get('from') || '';
    const noSpeech = url.searchParams.get('noSpeech') === '1';

    // Carry forward collected data via URL params
    const patientName = decodeURIComponent(url.searchParams.get('name') || '');
    const patientAge = decodeURIComponent(url.searchParams.get('age') || '');
    const complaint = decodeURIComponent(url.searchParams.get('complaint') || '');
    const duration = decodeURIComponent(url.searchParams.get('duration') || '');

    // Parse speech result from POST body
    const body = await req.text();
    const params = new URLSearchParams(body);
    const speechResult = noSpeech ? '' : (params.get('SpeechResult') || '').trim();

    console.log(`Step: ${step}, Speech: "${speechResult}", From: ${from}`);

    // Helper: build next step URL with accumulated data
    const nextUrl = (nextStep, extra = {}) => {
      const p = new URLSearchParams({
        step: nextStep,
        callSid,
        from,
        name: extra.name || patientName,
        age: extra.age || patientAge,
        complaint: extra.complaint || complaint,
        duration: extra.duration || duration,
      });
      return `${BASE_URL}/twilioProcessSpeech?${p.toString()}`;
    };

    // Helper: gather TwiML
    const gather = (prompt, nextStep, extra = {}) => `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Gather input="speech" action="${nextUrl(nextStep, extra)}" method="POST" speechTimeout="5" language="en-US" timeout="12">
    <Say voice="alice" language="en-US">${prompt}</Say>
  </Gather>
  <Redirect method="POST">${nextUrl(nextStep, extra)}&amp;noSpeech=1</Redirect>
</Response>`;

    // ── STEP: name ──
    if (step === 'name') {
      const name = speechResult || 'unknown caller';
      return new Response(
        gather(`Thank you. Hello ${name}. How old are you?`, 'age', { name }),
        { status: 200, headers: { 'Content-Type': 'text/xml' } }
      );
    }

    // ── STEP: age ──
    if (step === 'age') {
      const age = speechResult || 'unknown';
      return new Response(
        gather(`Thank you. What is your main health concern or symptom today? Please describe it clearly.`, 'complaint', { age }),
        { status: 200, headers: { 'Content-Type': 'text/xml' } }
      );
    }

    // ── STEP: complaint ──
    if (step === 'complaint') {
      const comp = speechResult || 'not specified';
      return new Response(
        gather(`I understand. How long have you been experiencing this problem? For example: since this morning, two days, one week.`, 'duration', { complaint: comp }),
        { status: 200, headers: { 'Content-Type': 'text/xml' } }
      );
    }

    // ── STEP: duration ──
    if (step === 'duration') {
      const dur = speechResult || 'unknown';
      // Now run AI triage with all collected info
      return new Response(
        await runTriage(base44, { patientName, patientAge, complaint, duration: dur, from, callSid }),
        { status: 200, headers: { 'Content-Type': 'text/xml' } }
      );
    }

    // Fallback
    return new Response(`<?xml version="1.0" encoding="UTF-8"?><Response><Say>Thank you for calling Murava Health. Goodbye.</Say><Hangup/></Response>`,
      { status: 200, headers: { 'Content-Type': 'text/xml' } }
    );

  } catch (error) {
    console.error('twilioProcessSpeech error:', error.message);
    return new Response(`<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="en-US">We encountered an issue. Please call back or visit our clinic. Goodbye.</Say>
  <Hangup/>
</Response>`, { status: 200, headers: { 'Content-Type': 'text/xml' } });
  }
});

async function runTriage(base44, { patientName, patientAge, complaint, duration, from, callSid }) {
  try {
    console.log(`Running triage for ${patientName}, age ${patientAge}, complaint: ${complaint}, duration: ${duration}`);

    const aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are Murava, an AI clinical triage assistant for a Rwandan health clinic.

Patient information collected via phone call:
- Name: ${patientName}
- Age: ${patientAge}
- Phone: ${from}
- Main complaint: ${complaint}
- Duration of symptoms: ${duration}

Based on this, provide:
1. A triage priority level
2. A spoken response to give the patient (calm, clear, 2-3 sentences max)
3. Clinical notes for the healthcare team
4. Whether this is a high-alert emergency

Keep the patient response simple and reassuring. If critical, tell them to go to hospital immediately or call 912.`,
      response_json_schema: {
        type: "object",
        properties: {
          priority: { type: "string", enum: ["Critical", "High", "Medium", "Low"] },
          patient_response: { type: "string" },
          clinical_notes: { type: "string" },
          high_alert: { type: "boolean" },
          route_to: { type: "string" }
        }
      }
    });

    const priority = aiResult.priority || 'Medium';
    const patientResponse = aiResult.patient_response || 'Your concern has been noted. Please visit our clinic.';
    const clinicalNotes = aiResult.clinical_notes || complaint;
    const highAlert = aiResult.high_alert || false;
    const routeTo = aiResult.route_to || 'Clinic';

    // Save to database
    await base44.asServiceRole.entities.CommunityWorkerVisit.create({
      patient_name: patientName || `Caller ${from}`,
      phone: from,
      problem_description: complaint,
      symptoms: `Age: ${patientAge}. Complaint: ${complaint}. Duration: ${duration}`,
      priority,
      high_alert: highAlert,
      high_alert_reason: highAlert ? clinicalNotes : '',
      intake_source: 'AI Phone Call',
      status: 'Assigned',
      visit_date: new Date().toISOString(),
      assessment: clinicalNotes
    });

    console.log(`Triage done: ${priority}, route: ${routeTo}, alert: ${highAlert}`);

    const urgencyNote = priority === 'Critical' || priority === 'High'
      ? `Your priority level is ${priority}. Please seek care immediately.`
      : `Your priority level is ${priority}. We will follow up with you soon.`;

    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="en-US">${patientResponse}</Say>
  <Say voice="alice" language="en-US">${urgencyNote}</Say>
  <Say voice="alice" language="en-US">Your information has been saved. A health worker will contact you. Thank you for calling Murava Health. Murakoze. Goodbye.</Say>
  <Hangup/>
</Response>`;

  } catch (err) {
    console.error('Triage error:', err.message);
    return `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="en-US">Thank you for your information. Your call has been logged and a health worker will contact you shortly. Goodbye.</Say>
  <Hangup/>
</Response>`;
  }
}