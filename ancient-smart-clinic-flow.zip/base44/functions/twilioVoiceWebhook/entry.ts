import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

const BASE_URL = "https://api.base44.com/api/apps/6832a61e9fcbf453b4dcd2d3/functions";

// Step 1: Incoming call — greet and ask for name
Deno.serve(async (req) => {
  try {
    const body = await req.text();
    const params = new URLSearchParams(body);
    const callSid = params.get('CallSid') || '';
    const from = params.get('From') || '';

    console.log(`Incoming call from ${from}, CallSid: ${callSid}`);

    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="en-US">
    Murakaza neza kuri Murava Health. Welcome to Murava Health.
    I am your AI health assistant. I will ask you a few questions to help route you to the right care.
  </Say>
  <Gather input="speech" action="${BASE_URL}/twilioProcessSpeech?step=name&callSid=${encodeURIComponent(callSid)}&from=${encodeURIComponent(from)}" method="POST" speechTimeout="5" language="en-US" timeout="10">
    <Say voice="alice" language="en-US">Please tell me your name.</Say>
  </Gather>
  <Redirect method="POST">${BASE_URL}/twilioProcessSpeech?step=name&callSid=${encodeURIComponent(callSid)}&from=${encodeURIComponent(from)}&noSpeech=1</Redirect>
</Response>`;

    return new Response(twiml, {
      status: 200,
      headers: { 'Content-Type': 'text/xml' }
    });
  } catch (error) {
    console.error('twilioVoiceWebhook error:', error.message);
    const twiml = `<?xml version="1.0" encoding="UTF-8"?>
<Response>
  <Say voice="alice" language="en-US">An error occurred. Please call back later.</Say>
  <Hangup/>
</Response>`;
    return new Response(twiml, { status: 200, headers: { 'Content-Type': 'text/xml' } });
  }
});