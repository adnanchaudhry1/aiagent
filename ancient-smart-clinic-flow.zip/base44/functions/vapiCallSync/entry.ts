import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Polls VAPI for recent calls and saves any that aren't already in the DB
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);

    const vapiKey = Deno.env.get('VAPI_API_KEY');
    if (!vapiKey) return Response.json({ error: 'VAPI_API_KEY not set' }, { status: 500 });

    // Fetch last 25 calls from VAPI
    const vapiRes = await fetch('https://api.vapi.ai/call?limit=25', {
      headers: { 'Authorization': `Bearer ${vapiKey}` }
    });
    const calls = await vapiRes.json();
    if (!Array.isArray(calls)) return Response.json({ error: 'VAPI error', detail: calls }, { status: 500 });

    let saved = 0;
    let skipped = 0;

    for (const call of calls) {
      const transcript = call.artifact?.transcript || '';
      const summary = call.analysis?.summary || '';

      // Skip calls with no transcript (silence timeouts, etc.)
      if (!transcript || transcript.length < 50) { skipped++; continue; }

      const callId = call.id;
      const phone = call.customer?.number || 'unknown';

      // Check if this call is already saved (by VAPI call ID in notes)
      const existing = await base44.asServiceRole.entities.Appointment.filter({ notes: { $regex: callId } });
      if (existing && existing.length > 0) { skipped++; continue; }

      // Also check CommunityWorkerVisit
      const existingChw = await base44.asServiceRole.entities.CommunityWorkerVisit.filter({ assessment: { $regex: callId } });
      if (existingChw && existingChw.length > 0) { skipped++; continue; }

      // Use AI to extract patient data from transcript
      const aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: `Extract patient info from this health call transcript for a Rwandan clinic.
Transcript: """${transcript}"""
Summary: ${summary}

Extract: patient_name, phone (if mentioned), national_id, date_of_birth (ISO format YYYY-MM-DD), insurance_id, insurance_type (RSSB (RAMA)/MMI/Mutuelle de Santé/Private/None), main_complaint, complaint_duration, priority (Critical/High/Medium/Low), appointment_type (Hospital/Clinic or Community Health Worker), clinical_notes, district`,
        response_json_schema: {
          type: "object",
          properties: {
            patient_name: { type: "string" },
            phone: { type: "string" },
            national_id: { type: "string" },
            date_of_birth: { type: "string" },
            insurance_id: { type: "string" },
            insurance_type: { type: "string" },
            main_complaint: { type: "string" },
            complaint_duration: { type: "string" },
            priority: { type: "string" },
            appointment_type: { type: "string" },
            clinical_notes: { type: "string" },
            district: { type: "string" }
          }
        }
      });

      const patientName = aiResult.patient_name || `Caller ${phone}`;
      // Reject invalid/placeholder names
      const invalidNames = ['caller', 'unknown', 'user', 'n/a', 'patient', 'customer', ''];
      if (!patientName || patientName.trim().length === 0 || invalidNames.includes(patientName.toLowerCase().trim()) || patientName.startsWith('Caller ')) {
        console.log(`Skipping call ${callId}: invalid patient name extracted: ${patientName}`);
        skipped++;
        continue;
      }
      const patientPhone = aiResult.phone || phone;

      // Find or create patient — ONLY match by national_id (allows phone reuse for testing)
      let patientId;
      if (aiResult.national_id && aiResult.national_id.length >= 8) {
        const byId = await base44.asServiceRole.entities.Patient.filter({ national_id: aiResult.national_id });
        if (byId && byId.length > 0) { patientId = byId[0].id; }
      }
      
      // Create new patient if no national_id match (allows same phone for different patients)
      if (!patientId) {
        const mrNumber = 'MR-' + Math.floor(10000000 + Math.random() * 90000000);
        const newPatient = await base44.asServiceRole.entities.Patient.create({
          mr_number: mrNumber,
          full_name: patientName,
          phone: patientPhone,
          national_id: aiResult.national_id || '',
          insurance_id: aiResult.insurance_id || '',
          insurance_type: aiResult.insurance_type || 'None',
          date_of_birth: aiResult.date_of_birth || '',
          gender: 'Other',
          district: aiResult.district || '',
          status: 'Active'
        });
        patientId = newPatient.id;
      }

      const isChw = (aiResult.appointment_type || '').toLowerCase().includes('community');
      const apptNumber = 'APT-' + Math.floor(10000000 + Math.random() * 90000000);
      const apptDate = new Date(Date.now() + 86400000).toISOString();

      if (isChw) {
        await base44.asServiceRole.entities.CommunityWorkerVisit.create({
          patient_id: patientId,
          patient_name: patientName,
          national_id: aiResult.national_id || '',
          phone: patientPhone,
          date_of_birth: aiResult.date_of_birth || '',
          insurance_id: aiResult.insurance_id || '',
          problem_description: aiResult.main_complaint || summary,
          priority: aiResult.priority || 'Medium',
          intake_source: 'AI Phone Call',
          status: 'Assigned',
          visit_date: apptDate,
          assessment: `${aiResult.clinical_notes || summary} | VAPI Call ID: ${callId}`
        });
      } else {
        await base44.asServiceRole.entities.Appointment.create({
          appointment_number: apptNumber,
          patient_id: patientId,
          patient_name: patientName,
          appointment_date: apptDate,
          reason: aiResult.main_complaint || summary,
          status: 'Scheduled',
          intake_source: 'AI Phone Call',
          appointment_type: 'Hospital/Clinic',
          ai_call_notes: aiResult.clinical_notes || aiResult.main_complaint || '',
          call_transcript: transcript,
          notes: `Phone: ${patientPhone} | DOB: ${aiResult.date_of_birth || 'N/A'} | Insurance: ${aiResult.insurance_type || 'None'} (${aiResult.insurance_id || 'N/A'}) | National ID: ${aiResult.national_id || 'N/A'} | Duration: ${aiResult.complaint_duration || 'N/A'} | District: ${aiResult.district || 'N/A'} | VAPI Call ID: ${callId}`,
        });
      }

      console.log(`Saved call ${callId}: ${patientName}`);
      saved++;
    }

    return Response.json({ success: true, saved, skipped, total: calls.length });

  } catch (error) {
    console.error('vapiCallSync error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});