import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Triggers a VAPI outbound follow-up call to a patient
Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me();
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const { followUpCallId, phone, patientName } = await req.json();
    if (!phone) return Response.json({ error: 'Phone number is required' }, { status: 400 });
    if (!followUpCallId) return Response.json({ error: 'followUpCallId is required' }, { status: 400 });

    const VAPI_API_KEY = Deno.env.get('VAPI_API_KEY');
    const VAPI_PHONE_NUMBER_ID = Deno.env.get('VAPI_PHONE_NUMBER_ID');
    const VAPI_OUTBOUND_ASSISTANT_ID = Deno.env.get('VAPI_OUTBOUND_ASSISTANT_ID');

    if (!VAPI_API_KEY || !VAPI_PHONE_NUMBER_ID || !VAPI_OUTBOUND_ASSISTANT_ID) {
      return Response.json({ error: 'Missing VAPI configuration secrets' }, { status: 500 });
    }

    // Normalize phone: ensure it starts with +
    const normalizedPhone = phone.startsWith('+') ? phone : `+${phone}`;

    const vapiRes = await fetch('https://api.vapi.ai/call', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${VAPI_API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        phoneNumberId: VAPI_PHONE_NUMBER_ID,
        assistantId: VAPI_OUTBOUND_ASSISTANT_ID,
        customer: {
          number: normalizedPhone,
          name: patientName || 'Patient',
        },
        assistantOverrides: {
          variableValues: {
            patient_name: patientName || 'Patient',
            follow_up_call_id: followUpCallId,
          },
        },
      }),
    });

    const vapiData = await vapiRes.json();

    if (!vapiRes.ok) {
      console.error('VAPI outbound call failed:', JSON.stringify(vapiData));
      return Response.json({ error: vapiData?.message || 'VAPI call failed', details: vapiData }, { status: 500 });
    }

    console.log(`Outbound call triggered for ${patientName} (${normalizedPhone}), callId: ${vapiData.id}`);

    return Response.json({ success: true, callId: vapiData.id, status: vapiData.status });
  } catch (error) {
    console.error('vapiOutboundCall error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});