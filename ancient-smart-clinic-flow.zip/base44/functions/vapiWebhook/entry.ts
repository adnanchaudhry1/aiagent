import { createClientFromRequest } from 'npm:@base44/sdk@0.8.25';

// Multilingual medical terminology from dataset (560+ terms) - Cleaned for JS compatibility
const SYNONYM_MAP = {
  'umuriro': 'fever', 'umuriro mwinshi': 'high fever', 'umuriro muto': 'low grade fever',
  'fievre': 'fever', 'forte fievre': 'high fever', 'fievre legere': 'low grade fever',
  'homa': 'fever', 'homa kali': 'high fever', 'homa kidogo': 'low grade fever',
  'ububabare': 'pain', 'ububabare bukabije': 'severe pain', 'ububabare buto': 'mild pain',
  'douleur': 'pain', 'douleur severe': 'severe pain', 'douleur legere': 'mild pain',
  'maumivu': 'pain', 'maumivu makali': 'severe pain', 'maumivu madogo': 'mild pain',
  'inkorora': 'cough', 'toux': 'cough', 'kikohozi': 'cough',
  'guhumeka nabi': 'shortness of breath', 'guhumeka bigoye': 'difficulty breathing',
  'essoufflement': 'shortness of breath', 'difficulte a respirer': 'difficulty breathing',
  'upungufu wa pumzi': 'shortness of breath', 'shida ya kupumua': 'difficulty breathing',
  'impiswi': 'diarrhea', 'kuruka': 'vomiting', 'iseseme': 'nausea',
  'diarrhee': 'diarrhea', 'vomissements': 'vomiting', 'nausee': 'nausea',
  'kuhara': 'diarrhea', 'kutapika': 'vomiting', 'kichefuchefu': 'nausea',
  'isereri': 'dizziness', 'guhungira': 'fainting', 'indwara y ingunge': 'seizure',
  'vertige': 'dizziness', 'evanouissement': 'fainting', 'convulsion': 'seizure',
  'kizunguzungu': 'dizziness', 'kuzimia': 'fainting', 'degedege': 'seizure',
  'umunaniro': 'fatigue', 'ubumuga': 'weakness', 'gutakaza ibiro': 'weight loss',
  'fatigue': 'fatigue', 'faiblesse': 'weakness', 'perte de poids': 'weight loss',
  'uchovu': 'fatigue', 'udhaifu': 'weakness', 'kupungua uzito': 'weight loss',
  'umutwe': 'head', 'ijisho': 'eye', 'amaso': 'eyes', 'ugutwi': 'ear', 'amatwi': 'ears',
  'tete': 'head', 'oeil': 'eye', 'yeux': 'eyes', 'oreille': 'ear', 'oreilles': 'ears',
  'kichwa': 'head', 'jicho': 'eye', 'macho': 'eyes', 'sikio': 'ear', 'masikio': 'ears',
  'igituza': 'chest', 'inda': 'stomach', 'umugongo': 'back',
  'poitrine': 'chest', 'estomac': 'stomach', 'dos': 'back',
  'kifua': 'chest', 'tumbo': 'stomach', 'mgongo': 'back',
  'malariya': 'malaria', 'paludisme': 'malaria',
  'igituntu': 'tuberculosis', 'tuberculose': 'tuberculosis', 'kifua kikuu': 'tuberculosis',
  'diyabeti': 'diabetes', 'diabete': 'diabetes', 'kisukari': 'diabetes',
  'hypertension': 'hypertension', 'shinikizo la damu': 'hypertension',
  'indirarugira': 'pneumonia', 'pneumonie': 'pneumonia', 'nimonia': 'pneumonia',
  'umuti': 'medicine', 'medicament': 'medicine', 'dawa': 'medicine',
  'injection': 'injection', 'sindano': 'injection',
  'ibitaro': 'hospital', 'hopital': 'hospital', 'hospitali': 'hospital',
  'umuganga': 'doctor', 'medecin': 'doctor', 'daktari': 'doctor',
  'infermiyeri': 'nurse', 'infirmier': 'nurse', 'muuguzi': 'nurse',
  'uyu munsi': 'today', 'aujourdhui': 'today', 'leo': 'today',
  'ejo hashize': 'yesterday', 'hier': 'yesterday', 'jana': 'yesterday',
  'ejo hazaza': 'tomorrow', 'demain': 'tomorrow', 'kesho': 'tomorrow',
  'yego': 'yes', 'oui': 'yes', 'ndiyo': 'yes',
  'oya': 'no', 'non': 'no', 'hapana': 'no',
  'ihutiro': 'emergency', 'urgence': 'emergency', 'dharura': 'emergency',
  'zeru': '0', 'zero': '0', 'sufuri': '0',
  'rimwe': '1', 'imwe': '1', 'un': '1', 'moja': '1',
  'kabiri': '2', 'deux': '2', 'mbili': '2',
  'gatatu': '3', 'trois': '3', 'tatu': '3',
  'kane': '4', 'quatre': '4', 'nne': '4',
  'gatanu': '5', 'cinq': '5', 'tano': '5',
  'gatandatu': '6', 'six': '6', 'sita': '6',
  'karindwi': '7', 'sept': '7', 'saba': '7',
  'munani': '8', 'huit': '8', 'nane': '8',
  'icyenda': '9', 'neuf': '9', 'tisa': '9',
  'icumi': '10', 'dix': '10', 'kumi': '10',
  'makumyabiri': '20', 'vingt': '20', 'ishirini': '20',
  'mirongo itatu': '30', 'trente': '30', 'thelathini': '30',
  'mutarama': '01', 'janvier': '01', 'januari': '01',
  'gashyantare': '02', 'fevrier': '02', 'februari': '02',
  'werurwe': '03', 'mars': '03', 'machi': '03',
  'mata': '04', 'avril': '04', 'aprili': '04',
  'gicurasi': '05', 'mai': '05', 'mei': '05',
  'kamena': '06', 'juin': '06', 'juni': '06',
  'nyakanga': '07', 'juillet': '07', 'julai': '07',
  'kanama': '08', 'aout': '08', 'agosti': '08',
  'nzeli': '09', 'septembre': '09', 'septemba': '09',
  'ukwakira': '10', 'octobre': '10', 'oktoba': '10',
  'ugushyingo': '11', 'novembre': '11', 'novemba': '11',
  'ukuboza': '12', 'decembre': '12', 'desemba': '12'
};

// VAPI Webhook Handler - Multilingual AI Phone Intake for Rwanda Healthcare
// Supports: Kinyarwanda, French, Swahili, English
// Webhook URL: https://api.base44.com/api/apps/6832a61e9fcbf453b4dcd2d3/functions/vapiWebhook

function cleanName(name) {
  if (!name) return name;
  try { return decodeURIComponent(name); } catch { return name; }
}

// Normalize multilingual text to English using synonym map
function normalizeText(text) {
  if (!text) return text;
  const lower = text.toString().toLowerCase().trim();
  return SYNONYM_MAP[lower] || text;
}

// Normalize entire transcript by replacing multilingual terms
function normalizeTranscript(transcript) {
  if (!transcript) return transcript;
  let normalized = transcript;
  
  // Sort by length (longest first) to match multi-word phrases before single words
  const sortedTerms = Object.keys(SYNONYM_MAP).sort((a, b) => b.length - a.length);
  
  for (const term of sortedTerms) {
    const regex = new RegExp(`\\b${term.replace(/'/g, "[']")}\\b`, 'gi');
    normalized = normalized.replace(regex, SYNONYM_MAP[term]);
  }
  
  return normalized;
}

// Multilingual error messages
const ERROR_MESSAGES = {
  kinyarwanda: {
    phone_required: 'Nomero ya telefoni irasabwa',
    phone_invalid: 'Nomero ya telefoni ntabwo ari yo. Tegereza +2507XXXXXXXX (imibare 12)',
    national_id_required: 'Indangamuntu irasabwa',
    national_id_invalid: 'Indangamuntu ntabwo ari yo. Tegereza imibare 16',
    insurance_id_required: 'Nomero ya bwishingizi irasabwa',
    insurance_id_invalid: 'Nomero ya bwishingizi ntabwo ari yo. Tegereza imibare 4-16',
    dob_required: 'Itariki y\'amavuko irasabwa',
    dob_invalid: 'Itariki y\'amavuko ntabwo ari yo. Vuga umunsi, ukwezi, n\'umwaka (urugero: "15 Mutarama 1980")',
    dob_incomplete: 'Itariki y\'amavuko ntuzuye - ukeneye umunsi n\'ukwezi (urugero: "15 Mutarama 1980")',
    age_required: 'Imyaka irasabwa',
    age_invalid: 'Imyaka ntabwo ari yo. Tegereza imyaka 0-120',
    language_required: 'Hitamo ururimi: Kinyarwanda, English, Français, cyangwa Kiswahili',
    language_invalid: 'Ururimi rwatanzwe ntiruzwi. Hitamo: Kinyarwanda, English, Français, cyangwa Kiswahili',
    please_repeat: 'Ngwino usubireho'
  },
  french: {
    phone_required: 'Numéro de téléphone requis',
    phone_invalid: 'Numéro de téléphone invalide. Format attendu: +2507XXXXXXXX (12 chiffres)',
    national_id_required: 'Carte d\'identité requise',
    national_id_invalid: 'Numéro d\'identité invalide. 16 chiffres attendus',
    insurance_id_required: 'Numéro d\'assurance requis',
    insurance_id_invalid: 'Numéro d\'assurance invalide. 4-16 caractères attendus',
    dob_required: 'Date de naissance requise',
    dob_invalid: 'Date de naissance invalide. Dites jour, mois et année (ex: "15 janvier 1980")',
    dob_incomplete: 'Date de naissance incomplète - besoin du jour et du mois (ex: "15 janvier 1980")',
    age_required: 'Âge requis',
    age_invalid: 'Âge invalide. Doit être entre 0 et 120 ans',
    language_required: 'Veuillez choisir une langue: Kinyarwanda, English, Français, ou Kiswahili',
    language_invalid: 'Langue inconnue. Veuillez choisir: Kinyarwanda, English, Français, ou Kiswahili',
    please_repeat: 'Veuillez répéter'
  },
  swahili: {
    phone_required: 'Namba ya simu inahitajika',
    phone_invalid: 'Namba ya simu si sahihi. Tafadhali tumia +2507XXXXXXXX (namba 12)',
    national_id_required: 'Kitambulisho kinahitajika',
    national_id_invalid: 'Kitambulisho si sahihi. Inatarajiwa kuwa na tarakimu 16',
    insurance_id_required: 'Namba ya bima inahitajika',
    insurance_id_invalid: 'Namba ya bima si sahihi. Inatarajiwa kuwa na herufi 4-16',
    dob_required: 'Tarehe ya kuzaliwa inahitajika',
    dob_invalid: 'Tarehe ya kuzaliwa si sahihi. Sema siku, mwezi na mwaka (mfano: "15 Januari 1980")',
    dob_incomplete: 'Tarehe ya kuzaliwa haijakamilika - hitaji siku na mwezi (mfano: "15 Januari 1980")',
    age_required: 'Umri unahitajika',
    age_invalid: 'Umri si sahihi. Lazima uwe kati ya 0 na 120',
    language_required: 'Tafadhali chagua lugha: Kinyarwanda, English, Français, au Kiswahili',
    language_invalid: 'Lugha haijulikani. Tafadhali chagua: Kinyarwanda, English, Français, au Kiswahili',
    please_repeat: 'Tafadhali rudia'
  },
  english: {
    phone_required: 'Phone number required',
    phone_invalid: 'Invalid phone number. Expected +2507XXXXXXXX (12 digits)',
    national_id_required: 'National ID required',
    national_id_invalid: 'Invalid national ID. Expected 16 digits',
    insurance_id_required: 'Insurance ID required',
    insurance_id_invalid: 'Invalid insurance ID. Expected 4-16 characters',
    dob_required: 'Date of birth required',
    dob_invalid: 'Invalid date of birth. Please say day, month, and year (e.g., "15 January 1980")',
    dob_incomplete: 'Incomplete date of birth - need day and month (e.g., "15 January 1980")',
    age_required: 'Age required',
    age_invalid: 'Invalid age. Must be between 0 and 120',
    language_required: 'Please choose a language: Kinyarwanda, English, French, or Swahili',
    language_invalid: 'Unknown language. Please choose: Kinyarwanda, English, French, or Swahili',
    please_repeat: 'Please repeat'
  }
};

function getErrorMessage(errorKey, lang) {
  const language = lang || 'english';
  const messages = ERROR_MESSAGES[language] || ERROR_MESSAGES.english;
  return messages[errorKey] || ERROR_MESSAGES.english[errorKey] || 'Error';
}

// Multilingual month name mappings
const MONTH_MAP = {
  // Kinyarwanda
  'mutarama': '01', 'gashyantare': '02', 'werurwe': '03', 'mata': '04', 'gicurasi': '05', 'kamena': '06',
  'nyakanga': '07', 'kanama': '08', 'nzeri': '09', 'ukwakira': '10', 'ugushyingo': '11', 'ukuboza': '12',
  // French
  'janvier': '01', 'fevrier': '02', 'mars': '03', 'avril': '04', 'mai': '05', 'juin': '06',
  'juillet': '07', 'aout': '08', 'septembre': '09', 'octobre': '10', 'novembre': '11', 'decembre': '12',
  // Swahili
  'januari': '01', 'februari': '02', 'machi': '03', 'aprili': '04', 'mei': '05', 'juni': '06',
  'julai': '07', 'agosti': '08', 'septemba': '09', 'oktoba': '10', 'novemba': '11', 'desemba': '12',
  // English
  'january': '01', 'february': '02', 'march': '03', 'april': '04', 'may': '05', 'june': '06',
  'july': '07', 'august': '08', 'september': '09', 'october': '10', 'november': '11', 'december': '12'
};

// Number word mappings (common ones in RW/FR/SW/EN) - includes variants
const NUMBER_WORDS = {
  // Kinyarwanda (with common variants)
  'zeru': '0', 'zero': '0',
  'rimwe': '1', 'imwe': '1',
  'kabiri': '2', 'ebyiri': '2', 'ibiri': '2',
  'gatatu': '3', 'tatu': '3',
  'kane': '4', 'enye': '4', 'ine': '4',
  'gatanu': '5', 'tanu': '5',
  'gatandatu': '6', 'tandatu': '6',
  'karindwi': '7', 'indwi': '7', 'rwanda': '7',
  'umunani': '8', 'munani': '8', 'nani': '8',
  'icyenda': '9', 'cyenda': '9', 'yenda': '9',
  'icumi': '10', 'cumi': '10',
  'makumyabiri': '20', 'makumyabirin': '20', 'mirongoibiri': '20',
  'mirongoitatu': '30', 'mirongotatu': '30',
  'mirongoine': '40', 'mirongoine': '40',
  'mirongoitanu': '50', 'mirongotanu': '50',
  'mirongoitandatu': '60',
  'mirongoirindwi': '70',
  'mirongoiminani': '80',
  'mirongoicyenda': '90',
  // French
  'zero': '0',
  'un': '1', 'une': '1',
  'deux': '2',
  'trois': '3',
  'quatre': '4',
  'cinq': '5',
  'six': '6',
  'sept': '7',
  'huit': '8',
  'neuf': '9',
  'dix': '10',
  'onze': '11', 'douze': '12', 'treize': '13', 'quatorze': '14', 'quinze': '15', 'seize': '16',
  'dixsept': '17', 'dixhuit': '18', 'dix-huit': '18', 'dixneuf': '19', 'dix-neuf': '19',
  'vingt': '20', 'trente': '30', 'quarante': '40', 'cinquante': '50', 'soixante': '60',
  // Swahili
  'sifuri': '0',
  'moja': '1',
  'mbili': '2', 'wili': '2',
  'tatu': '3',
  'nne': '4',
  'tano': '5',
  'sita': '6',
  'saba': '7',
  'nane': '8',
  'tisa': '9',
  'kumi': '10',
  'ishirini': '20', 'thelathini': '30', 'arobaini': '40', 'hamsini': '50', 'sitini': '60', 'sabini': '70', 'themanini': '80', 'tisini': '90',
  // English
  'zero': '0',
  'one': '1',
  'two': '2', 'to': '2',
  'three': '3', 'tree': '3',
  'four': '4', 'for': '4',
  'five': '5',
  'six': '6',
  'seven': '7',
  'eight': '8',
  'nine': '9',
  'ten': '10', 'teen': '10',
  'eleven': '11', 'twelve': '12', 'thirteen': '13', 'fourteen': '14', 'fifteen': '15', 'sixteen': '16', 'seventeen': '17', 'eighteen': '18', 'nineteen': '19',
  'twenty': '20', 'thirty': '30', 'forty': '40', 'fifty': '50', 'sixty': '60', 'seventy': '70', 'eighty': '80', 'ninety': '90'
};

function normalizePhone(phone, lang = 'english') {
  if (!phone) return { valid: false, error: getErrorMessage('phone_required', lang), value: '' };
  let cleaned = phone.toString().trim().replace(/[\s\-\(\)]/g, '');
  
  // Convert digit words to digits first
  const words = cleaned.toLowerCase().split(/[\s,]+/);
  let hasDigitWords = false;
  let digitResult = '';
  for (const word of words) {
    if (NUMBER_WORDS[word]) {
      digitResult += NUMBER_WORDS[word];
      hasDigitWords = true;
    } else if (/^\d+$/.test(word)) {
      digitResult += word;
    } else {
      digitResult += word;
    }
  }
  if (hasDigitWords) cleaned = digitResult;
  
  // Convert 07XXXXXXXX to +2507XXXXXXXX
  if (cleaned.startsWith('07') || cleaned.startsWith('08')) {
    cleaned = '+250' + cleaned.substring(1);
  }
  // Ensure +250 prefix if 9 digits
  if (!cleaned.startsWith('+250') && cleaned.length === 9 && /^\d+$/.test(cleaned)) {
    cleaned = '+250' + cleaned;
  }
  
  // Validate Rwanda phone format: +2507XXXXXXXX (12-13 chars)
  const phoneRegex = /^\+250[78]\d{8}$/;
  if (!phoneRegex.test(cleaned)) {
    return { 
      valid: false, 
      error: getErrorMessage('phone_invalid', lang), 
      value: cleaned 
    };
  }
  
  return { valid: true, error: null, value: cleaned };
}

function normalizeId(id, idType = 'national_id', lang = 'english') {
  if (!id) {
    const errorKey = idType === 'national_id' ? 'national_id_required' : 'insurance_id_required';
    return { valid: false, error: getErrorMessage(errorKey, lang), value: '' };
  }
  
  // Remove spaces and hyphens
  let cleaned = id.toString().trim().replace(/[\s\-]/g, '');
  
  // Convert digit words to digits
  const lower = cleaned.toLowerCase();
  let result = '';
  const words = lower.split(/[\s,]+/);
  let hasDigitWords = false;
  
  for (const word of words) {
    if (NUMBER_WORDS[word]) {
      result += NUMBER_WORDS[word];
      hasDigitWords = true;
    } else if (/^\d+$/.test(word)) {
      result += word;
    } else {
      result += word; // Keep alphanumeric (e.g., P542)
    }
  }
  
  cleaned = hasDigitWords ? result : cleaned;
  cleaned = cleaned.toUpperCase(); // Standardize to uppercase for alphanumeric
  
  // Validate lengths
  if (idType === 'national_id') {
    // Accept any numeric string of 4+ digits — do NOT block on exact 16 digits
    if (cleaned.length < 4) {
      return { 
        valid: false, 
        error: getErrorMessage('national_id_invalid', lang), 
        value: cleaned 
      };
    }
  } else if (idType === 'insurance_id') {
    // Insurance IDs vary: RSSB/MMI/Mutuelle - typically 6-12 chars
    if (cleaned.length < 4 || cleaned.length > 16) {
      return { 
        valid: false, 
        error: getErrorMessage('insurance_id_invalid', lang), 
        value: cleaned 
      };
    }
  }
  
  return { valid: true, error: null, value: cleaned };
}

function normalizeDOB(dob, lang = 'english') {
  if (!dob) return { valid: false, error: getErrorMessage('dob_required', lang), value: '' };
  
  const dobStr = dob.toString().toLowerCase().trim();
  
  // Try parsing "day month year" format
  const parts = dobStr.split(/[\s,./-]+/).filter(p => p.length > 0);
  
  if (parts.length >= 3) {
    let day = parts[0];
    let month = parts[1];
    let year = parts[2];
    
    // Convert month name to number
    if (MONTH_MAP[month]) {
      month = MONTH_MAP[month];
    }
    
    // Convert digit words if needed
    if (NUMBER_WORDS[day]) day = NUMBER_WORDS[day];
    if (NUMBER_WORDS[year]) year = NUMBER_WORDS[year];
    
    // Pad day and year
    day = day.padStart(2, '0');
    if (year.length === 2) year = '20' + year;
    
    // Validate
    if (/^\d{2}$/.test(day) && /^\d{2}$/.test(month) && /^\d{4}$/.test(year)) {
      const dayNum = parseInt(day);
      const monthNum = parseInt(month);
      const yearNum = parseInt(year);
      
      // Basic date validation
      if (dayNum >= 1 && dayNum <= 31 && monthNum >= 1 && monthNum <= 12 && yearNum >= 1900 && yearNum <= 2026) {
        return { valid: true, error: null, value: `${year}-${month}-${day}` };
      }
      return { valid: false, error: getErrorMessage('dob_invalid', lang), value: '' };
    }
  }
  
  // Try existing YYYY-MM-DD format
  if (/^\d{4}-\d{2}-\d{2}$/.test(dobStr)) {
    return { valid: true, error: null, value: dobStr };
  }
  
  // Incomplete date (only year)
  if (/^\d{4}$/.test(dobStr)) {
    return { valid: false, error: getErrorMessage('dob_incomplete', lang), value: '' };
  }
  
  return { valid: false, error: getErrorMessage('dob_invalid', lang), value: '' };
}

function normalizeAge(age, lang = 'english') {
  if (!age) return { valid: false, error: getErrorMessage('age_required', lang), value: '' };
  const ageStr = age.toString().toLowerCase().trim();
  
  // If already a number, return it
  if (/^\d+$/.test(ageStr)) {
    const ageNum = parseInt(ageStr);
    if (ageNum >= 0 && ageNum <= 120) {
      return { valid: true, error: null, value: ageStr };
    }
    return { valid: false, error: getErrorMessage('age_invalid', lang), value: '' };
  }
  
  // Try to extract number words
  const words = ageStr.split(/[\s,]+/);
  let result = '';
  
  for (const word of words) {
    if (NUMBER_WORDS[word]) {
      result += NUMBER_WORDS[word];
    } else if (/^\d+$/.test(word)) {
      result += word;
    }
  }
  
  if (result) {
    const ageNum = parseInt(result);
    if (ageNum >= 0 && ageNum <= 120) {
      return { valid: true, error: null, value: result };
    }
    return { valid: false, error: getErrorMessage('age_invalid', lang), value: '' };
  }
  
  return { valid: false, error: getErrorMessage('age_invalid', lang), value: '' };
}

function normalizeLanguage(lang) {
  if (!lang) return { valid: false, error: getErrorMessage('language_required', 'english'), value: 'english' };
  const lower = lang.toString().toLowerCase().trim();
  const valid = ['kinyarwanda', 'english', 'french', 'swahili'];
  if (valid.includes(lower)) {
    return { valid: true, error: null, value: lower };
  }
  // Don't default silently - return error so assistant can re-ask
  return { valid: false, error: getErrorMessage('language_invalid', 'english'), value: lower };
}

async function findOrCreatePatient(base44, { patient_name, phone, national_id, insurance_id, insurance_type, dob, district }) {
  patient_name = cleanName(patient_name);
  
  // Reject invalid/placeholder names
  const invalidNames = ['caller', 'unknown', 'user', 'n/a', 'patient', 'customer', ''];
  if (!patient_name || patient_name.trim().length === 0 || invalidNames.includes(patient_name.toLowerCase().trim())) {
    throw new Error(`Invalid patient name: ${patient_name}`);
  }

  // Only match by national_id (unique identifier) - phone numbers can be reused for testing
  let existingPatient = null;
  if (national_id && national_id.length >= 8) {
    const found = await base44.asServiceRole.entities.Patient.filter({ national_id });
    if (found && found.length > 0) existingPatient = found[0];
  }

  if (existingPatient) {
    // Update existing patient with any new info from this call (don't overwrite with empty values)
    const updates = {};
    // Always update name if the call provided a more complete/different name
    if (patient_name && patient_name.trim().length > 0 && patient_name !== existingPatient.full_name) {
      updates.full_name = patient_name;
    }
    if (insurance_type && insurance_type !== 'None' && (!existingPatient.insurance_type || existingPatient.insurance_type === 'None')) updates.insurance_type = insurance_type;
    if (insurance_id && !existingPatient.insurance_id) updates.insurance_id = insurance_id;
    if (phone && phone !== 'unknown' && !existingPatient.phone) updates.phone = phone;
    if (dob && !existingPatient.date_of_birth) updates.date_of_birth = dob;
    if (district && !existingPatient.district) updates.district = district;
    if (Object.keys(updates).length > 0) {
      console.log(`findOrCreatePatient: updating existing patient ${existingPatient.id} with`, JSON.stringify(updates));
      await base44.asServiceRole.entities.Patient.update(existingPatient.id, updates);
    }
    return existingPatient.id;
  }

  // Create new patient with MR number (allows phone number reuse for testing)
  const mrNumber = 'MR-' + Math.floor(10000000 + Math.random() * 90000000);
  const newPatient = await base44.asServiceRole.entities.Patient.create({
    mr_number: mrNumber,
    full_name: patient_name || 'Unknown',
    phone: phone || '',
    national_id: national_id || '',
    insurance_id: insurance_id || '',
    insurance_type: insurance_type || 'None',
    date_of_birth: dob || '',
    district: district || '',
    gender: 'Other',
    status: 'Active'
  });
  return newPatient.id;
}

async function handleFunctionCall(fnNameRaw, fnParams, base44) {
  // Normalize function name — handle both camelCase and PascalCase from VAPI
  const fnName = fnNameRaw.charAt(0).toLowerCase() + fnNameRaw.slice(1);

  if (fnName === 'setPreferredLanguage' || fnName === 'setpreferredlanguage') {
    const { language, follow_up_call_id, patient_id } = fnParams;
    console.log('setPreferredLanguage called:', JSON.stringify(fnParams));
    const langMap = { kinyarwanda: 'Kinyarwanda', english: 'English', french: 'French', swahili: 'Swahili' };
    const langLabel = langMap[(language || '').toLowerCase()] || language || 'Unknown';
    if (follow_up_call_id) {
      await base44.asServiceRole.entities.FollowUpCall.update(follow_up_call_id, {
        ai_notes: `Language selected: ${langLabel}`,
      });
    }
    console.log(`Language set to: ${langLabel}`);
    return `Language preference set to ${langLabel}. I will continue in ${langLabel}.`;
  }

  if (fnName === 'saveFollowUpOutcome' || fnName === 'savefollowupoutcome') {
    const { follow_up_call_id, patient_response, ai_notes } = fnParams;
    console.log('saveFollowUpOutcome called:', JSON.stringify(fnParams));

    if (!follow_up_call_id) {
      return 'Follow-up call ID missing — outcome not saved.';
    }

    const validResponses = ['Recovered', 'Not Recovered', 'No Answer'];
    const response = validResponses.includes(patient_response) ? patient_response : 'No Answer';

    await base44.asServiceRole.entities.FollowUpCall.update(follow_up_call_id, {
      status: 'Completed',
      call_date: new Date().toISOString(),
      patient_response: response,
      ai_notes: ai_notes || '',
      re_escalated: response === 'Not Recovered',
    });

    if (response === 'Not Recovered') {
      const followUp = await base44.asServiceRole.entities.FollowUpCall.filter({ id: follow_up_call_id });
      const f = followUp?.[0];
      if (f) {
        const nextDay = new Date();
        nextDay.setDate(nextDay.getDate() + 1);
        nextDay.setHours(9, 0, 0, 0);
        await base44.asServiceRole.entities.Appointment.create({
          appointment_number: 'APT-' + Math.floor(10000000 + Math.random() * 90000000),
          patient_id: f.patient_id,
          patient_name: f.patient_name,
          appointment_date: nextDay.toISOString(),
          reason: `Follow-up re-appointment — patient still unwell after AI follow-up call.`,
          status: 'Scheduled',
          intake_source: 'Manual',
          appointment_type: 'Hospital/Clinic',
          notes: `Phone: ${f.phone || 'N/A'} | Re-scheduled from AI outbound follow-up call — patient not recovered`,
        });
        console.log(`Re-appointment created for ${f.patient_name}`);
      }
    }

    console.log(`Follow-up ${follow_up_call_id} saved: ${response}`);
    return `Follow-up outcome saved. Response: ${response}.`;
  }

  if (fnName === 'savePatientIntake') {
    const { patient_name, phone, complaint: comp, age, duration, priority: prio } = fnParams;
    await base44.asServiceRole.entities.CommunityWorkerVisit.create({
      patient_name: patient_name || 'Unknown',
      phone: phone || '',
      problem_description: comp || '',
      symptoms: age ? `Age: ${age}. Duration: ${duration || 'unknown'}` : '',
      priority: prio || 'Medium',
      intake_source: 'AI Phone Call',
      status: 'Assigned',
      visit_date: new Date().toISOString(),
    });
    return 'Patient intake saved successfully.';
  }

  if (fnName === 'checkEligibility' || fnName === 'checkeligibility') {
    let { insurance_id, insurance_type, language } = fnParams;
    
    const langResult = normalizeLanguage(language);
    const lang = langResult.valid ? langResult.value : 'english';
    
    const idResult = normalizeId(insurance_id, 'insurance_id', lang);
    if (!idResult.valid) {
      console.log('checkEligibility ID error:', idResult.error);
      return `${getErrorMessage('please_repeat', lang)}. ${idResult.error}`;
    }
    
    const eligible = idResult.value && idResult.value.length > 3;
    return eligible
      ? `Insurance verified! ${insurance_type || 'Your insurance'} is active. A small co-payment may apply.`
      : `Insurance could not be verified for ID: ${idResult.value}. Self-pay options are available.`;
  }

  if (fnName === 'triagePatient' || fnName === 'triagepatient') {
    let { patient_name, complaint, duration, language } = fnParams;
    
    const langResult = normalizeLanguage(language);
    const lang = langResult.valid ? langResult.value : 'english';
    
    patient_name = cleanName(patient_name);
    
    const aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
      prompt: `You are a clinical triage AI for a Rwandan clinic. Triage this patient.
Patient: ${patient_name}
Complaint: ${complaint}
Duration: ${duration}
Respond with triage priority (Critical/High/Medium/Low), recommended care type (Hospital/Community Health Worker), and a brief reason in 1 sentence.`,
      response_json_schema: {
        type: "object",
        properties: {
          priority: { type: "string", enum: ["Critical", "High", "Medium", "Low"] },
          appointment_type: { type: "string", enum: ["Hospital/Clinic", "Community Health Worker"] },
          reason: { type: "string" }
        }
      }
    });
    const triageMsg = `Based on your symptoms, I recommend a ${aiResult.appointment_type || 'clinic'} appointment. Priority: ${aiResult.priority || 'Medium'}. ${aiResult.reason || ''}`;
    console.log(`triagePatient result (lang: ${lang}):`, triageMsg);
    return triageMsg;
  }

  if (fnName === 'bookAppointment') {
    let { patient_name, dob, national_id, insurance_id, insurance_type, phone, caller_phone, complaint, priority, appointment_type, triage_notes, district, age, language } = fnParams;
    
    // Always default to english if language missing/invalid — never block booking over language
    const langResult = normalizeLanguage(language);
    const lang = langResult.valid ? langResult.value : 'english';
    console.log(`bookAppointment lang resolved: "${language}" -> "${lang}"`);
    
    patient_name = cleanName(patient_name);
    
    // Phone is auto-picked from caller ID — never block booking over phone validation
    // Use caller_phone (inbound caller ID) as primary, fall back to provided phone
    const rawPhone = caller_phone || phone || '';
    const phoneResult = rawPhone ? normalizePhone(rawPhone, lang) : { valid: true, value: '' };
    const resolvedPhone = phoneResult.valid ? phoneResult.value : (rawPhone || '');
    console.log(`bookAppointment phone: caller="${caller_phone}" provided="${phone}" resolved="${resolvedPhone}"`);
    
    // National ID is optional — never block booking if missing or short
    const nationalIdResult = national_id && national_id.toString().replace(/\D/g, '').length >= 4
      ? normalizeId(national_id, 'national_id', lang)
      : { valid: true, value: national_id || '' };
    console.log(`bookAppointment national_id: "${national_id}" -> valid=${nationalIdResult.valid}, value="${nationalIdResult.value}"`);

    // Insurance ID is optional — never block booking if missing
    const insuranceIdResult = insurance_id && insurance_id.toString().trim().length >= 4
      ? normalizeId(insurance_id, 'insurance_id', lang)
      : { valid: true, value: insurance_id || '' };
    console.log(`bookAppointment insurance_id: "${insurance_id}" -> valid=${insuranceIdResult.valid}, value="${insuranceIdResult.value}"`);
    
    // DOB is optional — never block booking if missing or invalid
    const dobResult = dob && dob.toString().trim().length > 0 && dob.toString().toLowerCase() !== 'skip'
      ? normalizeDOB(dob, lang)
      : { valid: true, value: '' };
    console.log(`bookAppointment DOB: "${dob}" -> valid=${dobResult.valid}, value="${dobResult.value}"`);
    // If DOB parsing fails, just continue with empty DOB — never block
    
    // Age is calculated server-side from DOB — never block booking if age is missing
    const ageResult = age ? normalizeAge(age, lang) : { valid: true, value: null };
    
    console.log('bookAppointment validated params:', JSON.stringify({ 
      patient_name, 
      phone: phoneResult.value, 
      national_id: nationalIdResult.value, 
      insurance_id: insuranceIdResult.value, 
      dob: dobResult.value, 
      age: ageResult.value,
      language: lang
    }));

    const apptDate = new Date();
    apptDate.setDate(apptDate.getDate() + 1);
    apptDate.setHours(9, 0, 0, 0);

    const patientId = await findOrCreatePatient(base44, { 
      patient_name, 
      phone: resolvedPhone, 
      national_id: nationalIdResult.value, 
      insurance_id: insuranceIdResult.value, 
      insurance_type, 
      dob: dobResult.value, 
      district 
    });
    
    const apptNumber = 'APT-' + Math.floor(10000000 + Math.random() * 90000000);
    const isChw = (appointment_type || '').toLowerCase().includes('community');

    if (isChw) {
      console.log(`bookAppointment CHW: patientId=${patientId}, patient_name=${patient_name}`);
      await base44.asServiceRole.entities.CommunityWorkerVisit.create({
        patient_id: patientId,
        patient_name: patient_name || 'Unknown',
        national_id: nationalIdResult.value || '',
        phone: resolvedPhone || '',
        date_of_birth: dobResult.value || '',
        insurance_id: insuranceIdResult.value || '',
        problem_description: complaint || '',
        priority: priority || 'Medium',
        intake_source: 'AI Phone Call',
        status: 'Assigned',
        visit_date: apptDate.toISOString(),
        assessment: triage_notes || complaint || '',
        needs_doctor: (priority === 'High' || priority === 'Critical'),
        high_alert: priority === 'Critical',
      });
      console.log(`bookAppointment CHW visit created, ref: ${apptNumber}`);
      return `BOOKING COMPLETE. Say EXACTLY this and then END THE CALL immediately: "Your Community Health Worker visit is confirmed. Reference number: ${apptNumber}. A health worker will visit you tomorrow. Thank you for calling Murava Health. Goodbye." Then hang up. Do NOT ask any follow-up questions.`;
    } else {
      await base44.asServiceRole.entities.Appointment.create({
        appointment_number: apptNumber,
        patient_id: patientId,
        patient_name: patient_name || 'Unknown',
        appointment_date: apptDate.toISOString(),
        reason: complaint || '',
        status: 'Scheduled',
        intake_source: 'AI Phone Call',
        appointment_type: 'Hospital/Clinic',
        ai_call_notes: triage_notes || complaint || '',
        notes: `Phone: ${resolvedPhone || 'N/A'} | DOB: ${dobResult.value || 'N/A'} | Insurance: ${insurance_type || 'None'} (${insuranceIdResult.value || 'N/A'}) | National ID: ${nationalIdResult.value || 'N/A'}`,
      });
      const responseMsg = `BOOKING COMPLETE. Say EXACTLY this and then END THE CALL immediately: "Your appointment is confirmed. Reference number: ${apptNumber}. Your appointment is tomorrow at 9am, please arrive 15 minutes early. Thank you for calling Murava Health. Goodbye." Then hang up. Do NOT ask any follow-up questions.`;
      console.log(`bookAppointment response: ${responseMsg}`);
      return responseMsg;
    }
  }

  if (fnName === 'triggerEmergency') {
    const { phone, reason } = fnParams;
    await base44.asServiceRole.entities.CommunityWorkerVisit.create({
      patient_name: phone ? `EMERGENCY — ${phone}` : 'EMERGENCY — Unknown Caller',
      phone: phone || '',
      problem_description: `🚨 EMERGENCY: ${reason || 'Life-threatening emergency'}`,
      priority: 'Critical',
      high_alert: true,
      high_alert_reason: `Emergency call: ${reason}. Ambulance requested.`,
      intake_source: 'AI Phone Call',
      status: 'Assigned',
      visit_date: new Date().toISOString(),
      assessment: `CRITICAL EMERGENCY — Patient told to call 912.`
    });
    return 'Emergency alert has been triggered. Please call 912 immediately for ambulance services in Rwanda. Our emergency team has been notified.';
  }

  return 'OK';
}

Deno.serve(async (req) => {
  try {
    const base44 = createClientFromRequest(req);
    const payload = await req.json();

    console.log('FULL VAPI PAYLOAD:', JSON.stringify(payload));

    if (payload?.toolCallId && payload?.name) {
      const fnName = payload.name;
      let fnParams = {};
      try { fnParams = typeof payload.parameters === 'string' ? JSON.parse(payload.parameters) : (payload.parameters || {}); } catch { fnParams = {}; }
      console.log(`VAPI direct tool call: ${fnName}`, JSON.stringify(fnParams));
      const result = await handleFunctionCall(fnName, fnParams, base44);
      return Response.json({ toolCallId: payload.toolCallId, result: typeof result === 'string' ? result : JSON.stringify(result) });
    }

    if (Array.isArray(payload?.toolCalls) || Array.isArray(payload?.tool_calls)) {
      const toolCallList = payload?.toolCalls || payload?.tool_calls || [];
      const results = [];
      for (const toolCall of toolCallList) {
        const fnName = toolCall?.function?.name || toolCall?.name;
        let fnParams = {};
        try { fnParams = typeof toolCall?.function?.arguments === 'string' ? JSON.parse(toolCall.function.arguments) : (toolCall?.function?.arguments || toolCall?.parameters || {}); } catch { fnParams = {}; }
        console.log(`VAPI tool call (array): ${fnName}`, JSON.stringify(fnParams));
        const result = await handleFunctionCall(fnName, fnParams, base44);
        results.push({ toolCallId: toolCall.id, result: typeof result === 'string' ? result : JSON.stringify(result) });
      }
      return Response.json({ results });
    }

    const { message } = payload;
    console.log('VAPI event type:', message?.type);

    if (message?.type === 'tool-calls') {
      const toolCallList = message?.toolCallList || [];
      const results = [];
      for (const toolCall of toolCallList) {
        const fnName = toolCall?.function?.name;
        let fnParams = {};
        try { fnParams = typeof toolCall?.function?.arguments === 'string' ? JSON.parse(toolCall.function.arguments) : (toolCall?.function?.arguments || {}); } catch { fnParams = {}; }
        console.log(`VAPI tool-call: ${fnName}`, JSON.stringify(fnParams));
        const result = await handleFunctionCall(fnName, fnParams, base44);
        results.push({ toolCallId: toolCall.id, result: typeof result === 'string' ? result : JSON.stringify(result) });
      }
      return Response.json({ results });
    }

    if (message?.type === 'function-call') {
      const fnName = message?.functionCall?.name;
      const fnParams = message?.functionCall?.parameters || {};
      console.log(`VAPI function call: ${fnName}`, JSON.stringify(fnParams));
      const result = await handleFunctionCall(fnName, fnParams, base44);
      return Response.json({ result });
    }

    if (message?.type === 'end-of-call-report') {
      const call = message?.call || {};
      const artifact = message?.artifact || {};
      const transcript = message?.transcript || artifact?.transcript || '';
      const summary = message?.summary || artifact?.summary || '';
      const from = call?.customer?.number || call?.phoneNumber || 'unknown';

      console.log('end-of-call-report. transcript length:', transcript.length);

      const allMessages = artifact?.messages || message?.messages || [];
      const alreadyBooked = allMessages.some(m =>
        (m?.role === 'tool' && m?.name === 'bookAppointment') ||
        m?.toolCalls?.some(tc => tc?.function?.name === 'bookAppointment')
      );

      if (alreadyBooked) {
        console.log('bookAppointment already fired — skipping fallback');
        return Response.json({ received: true, saved: false, reason: 'already_booked' });
      }

      if (!transcript || transcript.length < 20) {
        console.log('No transcript — skipping');
        return Response.json({ received: true, saved: false, reason: 'no_transcript' });
      }

      const normalizedTranscript = normalizeTranscript(transcript);
      
      const aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
        prompt: `You are a multilingual clinical data extractor for a Rwandan healthcare AI phone system.
This call may be in Kinyarwanda, French, Swahili, or English. Many terms have been automatically translated to English.

Original Transcript:
"""
${transcript}
"""

Normalized Transcript (terms translated to English):
"""
${normalizedTranscript}
"""

Summary: ${summary}

IMPORTANT: Use BOTH transcripts to extract information. The normalized version has medical terms translated to English.
Extract everything the patient said with these rules:

- patient_name: their full name (may be Rwandan names like Habimana, Mugisha, Mukamana, etc.)
- phone: phone number (formats: +250 78X XXX XXX, +25078XXXXXX, 078XXXXXX, or spoken digits)
- national_id: Rwanda national ID (16 digits, may be spoken as individual digits: "zero nine eight seven..." or "0987...")
- date_of_birth: DOB (may be spoken as "11 January 1980" or "1/1/1980" or digits spoken individually)
- insurance_id: insurance number (RSSB, MMI, Mutuelle - may be spoken digit by digit or with dashes)
- insurance_type: one of "RSSB (RAMA)", "MMI", "Mutuelle de Santé", "Private", "None" (listen for: "RSSB", "RAMA", "MMI", "Mutuelle", "private insurance", "nta bwishingizi")
- main_complaint: their health problem (may be in any language - fever=umuriro/fièvre/homa, pain=ububabare/douleur/maumivu, etc.)
- complaint_duration: how long (listen for: "days"/"iminsi"/"jours"/"siku", "weeks"/"ibyumweru"/"semaines"/"wiki", "months"/"amezi"/"mois")
- priority: Critical/High/Medium/Low based on severity (chest pain, difficulty breathing, severe bleeding = Critical/High)
- appointment_type: "Hospital/Clinic" if hospital/clinic/doctor mentioned, "Community Health Worker" if community/home/CHW mentioned
- clinical_notes: full clinical summary including ALL symptoms mentioned
- district: Rwanda district (Kigali, Gasabo, Nyarugenge, Kicukiro, Musanze, Huye, Ruhango, Nyanza, etc.)
- high_alert: true only if life-threatening (can't breathe, chest pain, unconscious, severe bleeding, stroke symptoms)

TIPS FOR NUMBER EXTRACTION:
- National IDs: 16 digits, often spoken slowly digit-by-digit
- Phone numbers: 9 digits after +250, often spoken in groups (788 123 456)
- Insurance IDs: may have dashes or spaces, extract all digits
- Dates: listen for day-month-year patterns in any language

Extract numbers CAREFULLY - if digits are spoken individually, concatenate them.`,
        response_json_schema: {
          type: "object",
          properties: {
            patient_name: { type: "string" },
            phone: { type: "string" },
            national_id: { type: "string" },
            date_of_birth: { type: "string" },
            insurance_id: { type: "string" },
            insurance_type: { type: "string" },
            main_complaint: { type: "string" },
            complaint_duration: { type: "string" },
            priority: { type: "string", enum: ["Critical", "High", "Medium", "Low"] },
            appointment_type: { type: "string", enum: ["Hospital/Clinic", "Community Health Worker"] },
            clinical_notes: { type: "string" },
            district: { type: "string" },
            high_alert: { type: "boolean" }
          }
        }
      });

      const transcriptLower = (transcript + ' ' + summary).toLowerCase();
      let detectedType = aiResult.appointment_type || 'Hospital/Clinic';
      if (transcriptLower.includes('hospital') || transcriptLower.includes('clinic') || transcriptLower.includes('doctor')) {
        detectedType = 'Hospital/Clinic';
      } else if (transcriptLower.includes('community') || transcriptLower.includes('chw') || transcriptLower.includes('home visit') || transcriptLower.includes('health worker')) {
        detectedType = 'Community Health Worker';
      }

      const patientName = cleanName(aiResult.patient_name);
      // Reject invalid/placeholder names
      const invalidNames = ['caller', 'unknown', 'user', 'n/a', 'patient', 'customer', ''];
      if (!patientName || patientName.trim().length === 0 || invalidNames.includes(patientName.toLowerCase().trim())) {
        console.log('Skipping appointment: invalid patient name extracted:', patientName);
        return Response.json({ received: true, saved: false, reason: 'invalid_patient_name' });
      }
      
      const phone = aiResult.phone || from;
      const complaint = aiResult.main_complaint || summary || 'Intake call';
      const priority = aiResult.priority || 'Medium';
      const isChw = detectedType === 'Community Health Worker';

      const patientId = await findOrCreatePatient(base44, {
        patient_name: patientName,
        phone,
        national_id: aiResult.national_id || '',
        insurance_id: aiResult.insurance_id || '',
        insurance_type: aiResult.insurance_type || 'None',
        dob: aiResult.date_of_birth || '',
        district: aiResult.district || ''
      });

      const apptNumber = 'APT-' + Math.floor(10000000 + Math.random() * 90000000);

      if (isChw) {
        await base44.asServiceRole.entities.CommunityWorkerVisit.create({
          patient_id: patientId,
          patient_name: patientName,
          national_id: aiResult.national_id || '',
          phone,
          date_of_birth: aiResult.date_of_birth || '',
          insurance_id: aiResult.insurance_id || '',
          problem_description: complaint,
          priority,
          high_alert: aiResult.high_alert || false,
          high_alert_reason: aiResult.high_alert ? aiResult.clinical_notes : '',
          intake_source: 'AI Phone Call',
          status: 'Assigned',
          visit_date: new Date().toISOString(),
          assessment: aiResult.clinical_notes || summary,
          notes: `Appointment Reference: ${apptNumber}`
        });
        console.log(`End-of-call CHW visit saved: ${patientName}, ref: ${apptNumber}`);
      } else {
        await base44.asServiceRole.entities.Appointment.create({
          appointment_number: apptNumber,
          patient_id: patientId,
          patient_name: patientName,
          appointment_date: new Date(Date.now() + 86400000).toISOString(),
          reason: complaint,
          status: 'Scheduled',
          intake_source: 'AI Phone Call',
          appointment_type: 'Hospital/Clinic',
          ai_call_notes: aiResult.clinical_notes || complaint,
          call_transcript: transcript,
          notes: `Phone: ${phone} | DOB: ${aiResult.date_of_birth || 'N/A'} | Insurance: ${aiResult.insurance_type || 'None'} (${aiResult.insurance_id || 'N/A'}) | National ID: ${aiResult.national_id || 'N/A'} | Duration: ${aiResult.complaint_duration || 'N/A'} | Appointment Reference: ${apptNumber}`,
        });
        console.log(`End-of-call appointment saved: ${patientName}, ref: ${apptNumber}`);
      }

      return Response.json({ received: true, saved: true, appointment_number: apptNumber });
    }

    if (message?.type === 'status-update') {
      console.log('Call status:', message?.status);
      console.log('status-update full message keys:', Object.keys(message || {}).join(', '));

      if (message?.status === 'ended') {
        const artifact = message?.artifact || message?.call?.artifact || {};
        const transcript = message?.transcript || artifact?.transcript || message?.call?.transcript || '';
        const summary = message?.summary || artifact?.summary || message?.call?.summary || '';
        const from = message?.call?.customer?.number || message?.call?.phoneNumber || 'unknown';

        console.log('ended status-update transcript length:', transcript?.length || 0);
        console.log('ended status-update artifact keys:', Object.keys(artifact).join(', '));

        if (transcript && transcript.length > 20) {
          const allMessages = artifact?.messages || message?.messages || [];
          const alreadyBooked = allMessages.some(m =>
            (m?.role === 'tool' && m?.name === 'bookAppointment') ||
            m?.toolCalls?.some(tc => tc?.function?.name === 'bookAppointment')
          );

          if (!alreadyBooked) {
            console.log('Extracting from status-update ended transcript...');
            const normalizedTranscript = normalizeTranscript(transcript);
            const aiResult = await base44.asServiceRole.integrations.Core.InvokeLLM({
              prompt: `You are a multilingual clinical data extractor for a Rwandan healthcare AI phone system.
This call may be in Kinyarwanda, French, Swahili, or English. Many terms have been automatically translated to English.

Original Transcript: """${transcript}"""
Normalized Transcript (terms translated): """${normalizedTranscript}"""
Summary: ${summary}

IMPORTANT: Use BOTH transcripts. The normalized version has medical terms translated to English.

Extract these fields:
- patient_name: full name (Rwandan names common: Habimana, Mugisha, Mukamana, etc.)
- phone: phone number (+250 78X XXX XXX, +25078XXXXXX, 078XXXXXX, or spoken digits)
- national_id: Rwanda national ID (16 digits, may be spoken digit-by-digit)
- date_of_birth: DOB (may be spoken as "11 January 1980" or digits individually)
- insurance_id: insurance number (RSSB/MMI/Mutuelle - extract all digits even if spoken slowly)
- insurance_type: "RSSB (RAMA)", "MMI", "Mutuelle de Santé", "Private", "None"Private", "None"
- main_complaint: health problem (any language - fever/pain/breathing issues)
- complaint_duration: how long (days/weeks/months in any language)
- priority: Critical/High/Medium/Low (chest pain/breathing difficulty = Critical/High)
- appointment_type: "Hospital/Clinic" or "Community Health Worker"
- clinical_notes: full symptom summary
- district: Rwanda district (Kigali, Gasabo, Musanze, Huye, etc.)

NUMBER EXTRACTION TIPS:
- National ID: 16 digits spoken individually (0-9-8-7-6-4-3-2-1-0...)
- Phone: 9 digits after +250, often in groups (788 123 456)
- Insurance IDs: may have dashes, extract all digits
- Dates: day-month-year patterns in any language

Be very careful with numbers spoken digit-by-digit - concatenate them properly.`,
              response_json_schema: {
                type: "object",
                properties: {
                  patient_name: { type: "string" },
                  phone: { type: "string" },
                  national_id: { type: "string" },
                  date_of_birth: { type: "string" },
                  insurance_id: { type: "string" },
                  insurance_type: { type: "string" },
                  main_complaint: { type: "string" },
                  complaint_duration: { type: "string" },
                  priority: { type: "string" },
                  appointment_type: { type: "string" },
                  clinical_notes: { type: "string" },
                  district: { type: "string" }
                }
              }
            });

            const patientName = cleanName(aiResult.patient_name);
            // Reject invalid/placeholder names
            const invalidNames = ['caller', 'unknown', 'user', 'n/a', 'patient', 'customer', ''];
            if (!patientName || patientName.trim().length === 0 || invalidNames.includes(patientName.toLowerCase().trim())) {
              console.log('Skipping appointment from status-update: invalid patient name extracted:', patientName);
              return Response.json({ received: true, saved: false, reason: 'invalid_patient_name' });
            }
            
            const phone = aiResult.phone || from;
            const patientId = await findOrCreatePatient(base44, {
              patient_name: patientName, phone,
              national_id: aiResult.national_id || '',
              insurance_id: aiResult.insurance_id || '',
              insurance_type: aiResult.insurance_type || 'None',
              dob: aiResult.date_of_birth || '',
              district: aiResult.district || ''
            });

            const isChw = (aiResult.appointment_type || '').toLowerCase().includes('community');
            const apptNumber = 'APT-' + Math.floor(10000000 + Math.random() * 90000000);

            if (isChw) {
              await base44.asServiceRole.entities.CommunityWorkerVisit.create({
                patient_id: patientId, patient_name: patientName,
                national_id: aiResult.national_id || '', phone,
                problem_description: aiResult.main_complaint || summary,
                priority: aiResult.priority || 'Medium',
                intake_source: 'AI Phone Call', status: 'Assigned',
                visit_date: new Date().toISOString(),
                assessment: aiResult.clinical_notes || summary
              });
            } else {
              await base44.asServiceRole.entities.Appointment.create({
                appointment_number: apptNumber, patient_id: patientId,
                patient_name: patientName,
                appointment_date: new Date(Date.now() + 86400000).toISOString(),
                reason: aiResult.main_complaint || summary,
                status: 'Scheduled', intake_source: 'AI Phone Call',
                appointment_type: 'Hospital/Clinic',
                ai_call_notes: aiResult.clinical_notes || aiResult.main_complaint,
                call_transcript: transcript,
                notes: `Phone: ${phone} | DOB: ${aiResult.date_of_birth || 'N/A'} | Insurance: ${aiResult.insurance_type || 'None'} (${aiResult.insurance_id || 'N/A'}) | National ID: ${aiResult.national_id || 'N/A'} | Duration: ${aiResult.complaint_duration || 'N/A'}`,
              });
            }
            console.log(`Saved from status-update ended: ${patientName}`);
            return Response.json({ received: true, saved: true, source: 'status-update-ended' });
          }
        }
      }

      return Response.json({ received: true });
    }

    return Response.json({ received: true });

  } catch (error) {
    console.error('vapiWebhook error:', error.message);
    return Response.json({ error: error.message }, { status: 500 });
  }
});