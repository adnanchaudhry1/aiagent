import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';
import AppLayout from '@/components/layout/AppLayout';
import Dashboard from '@/pages/Dashboard';
import Patients from '@/pages/Patients';
import Appointments from '@/pages/Appointments';
import Encounter from '@/pages/Encounter';
import MedicalCoding from '@/pages/MedicalCoding';
import InsuranceClaims from '@/pages/InsuranceClaims';
import PharmacySearch from '@/pages/PharmacySearch';
import Referrals from '@/pages/Referrals';
import GISMap from '@/pages/GISMap';
import AuditLog from '@/pages/AuditLog';
import LabSearch from '@/pages/LabSearch';
import PatientChart from '@/pages/PatientChart';
import Eligibility from '@/pages/Eligibility';
import AIReports from '@/pages/AIReports';
import DailyOverview from '@/pages/DailyOverview';
import FlaggedPatients from '@/pages/FlaggedPatients';
import PhoneIntake from '@/pages/PhoneIntake';
import CommunityWorker from '@/pages/CommunityWorker';
import FollowUp from '@/pages/FollowUp';
import FollowUpHistory from '@/pages/FollowUpHistory';


const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route element={<AppLayout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/patients" element={<Patients />} />
        <Route path="/appointments" element={<Appointments />} />
        <Route path="/encounter" element={<Encounter />} />
        <Route path="/coding" element={<MedicalCoding />} />
        <Route path="/insurance" element={<InsuranceClaims />} />
        <Route path="/pharmacy" element={<PharmacySearch />} />
        <Route path="/referrals" element={<Referrals />} />
        <Route path="/gis-map" element={<GISMap />} />
        <Route path="/lab" element={<LabSearch />} />
        <Route path="/audit" element={<AuditLog />} />
        <Route path="/patients/:patientId" element={<PatientChart />} />
        <Route path="/eligibility" element={<Eligibility />} />
        <Route path="/reports" element={<AIReports />} />
        <Route path="/daily" element={<DailyOverview />} />
        <Route path="/flagged-patients" element={<FlaggedPatients />} />
        <Route path="/phone-intake" element={<PhoneIntake />} />
        <Route path="/community-worker" element={<CommunityWorker />} />
        <Route path="/follow-up" element={<FollowUp />} />
        <Route path="/follow-up-history" element={<FollowUpHistory />} />

      </Route>
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App