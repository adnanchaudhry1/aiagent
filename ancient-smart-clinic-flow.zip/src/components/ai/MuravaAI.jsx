import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, X, Loader2 } from 'lucide-react';
import { toast } from 'sonner';

const ROUTES = {
  dashboard: '/',
  patients: '/patients',
  appointments: '/appointments',
  encounter: '/encounter',
  coding: '/coding',
  pharmacy: '/pharmacy',
  lab: '/lab',
  referrals: '/referrals',
  gis: '/gis-map',
  'gis map': '/gis-map',
  insurance: '/insurance',
  claims: '/insurance',
  audit: '/audit',
};

export default function MuravaAI() {
  const [active, setActive] = useState(false);
  const [listening, setListening] = useState(false);
  const [processing, setProcessing] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [response, setResponse] = useState('');
  const recognitionRef = useRef(null);
  const navigate = useNavigate();

  const stopListening = () => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch {}
      recognitionRef.current = null;
    }
    setListening(false);
  };

  const startListening = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      toast.error('Speech recognition not supported. Use Chrome or Edge.');
      return;
    }

    stopListening();

    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    const recognition = new SR();
    recognition.continuous = false;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    let finalText = '';

    recognition.onstart = () => setListening(true);

    recognition.onresult = (e) => {
      finalText = '';
      for (let i = 0; i < e.results.length; i++) {
        finalText += e.results[i][0].transcript;
      }
      setTranscript(finalText);
    };

    recognition.onend = () => {
      setListening(false);
      if (finalText.trim()) processCommand(finalText.trim());
    };

    recognition.onerror = (e) => {
      setListening(false);
      if (e.error === 'not-allowed') {
        toast.error('Microphone access denied.');
      }
    };

    recognitionRef.current = recognition;
    try {
      recognition.start();
    } catch {
      toast.error('Could not start mic. Try again.');
      setListening(false);
    }
  };

  const processCommand = async (text) => {
    setProcessing(true);
    const lower = text.toLowerCase();

    for (const [key, path] of Object.entries(ROUTES)) {
      if (lower.includes('go to ' + key) || lower.includes('open ' + key) || lower.includes('show ' + key) || lower.includes(key)) {
        setResponse(`Navigating to ${key}...`);
        setProcessing(false);
        setTimeout(() => { navigate(path); setActive(false); }, 600);
        return;
      }
    }

    try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are Murava AI, a voice assistant for a Rwandan clinical EHR system.
The doctor said: "${text}"
Available pages: Dashboard (/), Patients (/patients), Appointments (/appointments), Encounter (/encounter), Medical Coding (/coding), Pharmacy (/pharmacy), Lab Search (/lab), Referrals (/referrals), GIS Map (/gis-map), Insurance Claims (/insurance), Audit Log (/audit)
Determine what the doctor wants and respond with a route and a short spoken response.`,
      response_json_schema: {
        type: 'object',
        properties: {
          navigate_to: { type: 'string' },
          spoken_response: { type: 'string' },
          patient_name: { type: 'string' },
        }
      }
    });

    setResponse(result.spoken_response || "I'm here to help. Try saying 'go to patients' or 'open encounters'.");
    if (result.navigate_to) {
      let path = result.navigate_to;
      if (result.patient_name) path += `?patient=${encodeURIComponent(result.patient_name)}`;
      setTimeout(() => { navigate(path); setActive(false); }, 1200);
    }
    } catch (e) {
      setResponse("Sorry, I couldn't process that. Please try again.");
    } finally {
      setProcessing(false);
    }
  };

  const openAssistant = () => {
    setActive(true);
    setTranscript('');
    setResponse('How may I help you, Doctor? Say a command or click Speak.');
  };

  const close = () => {
    stopListening();
    setActive(false);
    setTranscript('');
    setResponse('');
  };

  return (
    <>
      <button
        onClick={active ? close : openAssistant}
        className={`fixed bottom-6 right-6 z-50 w-14 h-14 rounded-full shadow-lg flex items-center justify-center transition-all duration-300 ${active ? 'bg-destructive' : 'bg-primary hover:bg-primary/90'} text-white`}
        title="Murava AI Voice Assistant"
      >
        {active ? <X className="w-6 h-6" /> : <Mic className="w-6 h-6" />}
        {listening && <span className="absolute inset-0 rounded-full bg-primary animate-ping opacity-40" />}
      </button>

      {active && (
        <div className="fixed bottom-24 right-6 z-50 w-80 bg-background border border-border rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-4 py-3 bg-primary text-white">
            <div className="flex items-center gap-2">
              <div className="w-6 h-6 rounded-full bg-white/20 flex items-center justify-center">
                <Mic className="w-3 h-3" />
              </div>
              <p className="text-sm font-bold">Murava AI</p>
              {listening && <Badge className="bg-white/20 text-white text-xs animate-pulse">Listening...</Badge>}
            </div>
            <button onClick={close}><X className="w-4 h-4" /></button>
          </div>

          <div className="p-4 space-y-3">
            <div className="bg-primary/5 rounded-xl p-3">
              <p className="text-xs text-muted-foreground mb-1">Murava AI</p>
              {processing ? (
                <div className="flex items-center gap-2">
                  <Loader2 className="w-3 h-3 animate-spin text-primary" />
                  <p className="text-sm text-muted-foreground">Processing...</p>
                </div>
              ) : (
                <p className="text-sm font-medium">{response || 'How may I help you, Doctor?'}</p>
              )}
            </div>

            {transcript && (
              <div className="bg-muted/50 rounded-xl p-3">
                <p className="text-xs text-muted-foreground mb-1">You said</p>
                <p className="text-sm">{transcript}</p>
              </div>
            )}

            <div className="flex gap-2">
              <Button
                className="flex-1 gap-2"
                size="sm"
                variant={listening ? 'destructive' : 'default'}
                onClick={listening ? stopListening : startListening}
                disabled={processing}
              >
                {listening ? <><MicOff className="w-4 h-4" /> Stop</> : <><Mic className="w-4 h-4" /> Speak</>}
              </Button>
              <Button variant="outline" size="sm" onClick={close}>Close</Button>
            </div>

            <div className="text-xs text-muted-foreground space-y-0.5">
              <p className="font-medium">Try saying:</p>
              <p>• "Go to patients"</p>
              <p>• "Open appointments"</p>
              <p>• "Show pharmacy"</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}