import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Lock, Sparkles, Loader2, CheckCircle2, User, Clock, Stethoscope, DollarSign, ShieldCheck } from 'lucide-react';
import EligibilityModal from './EligibilityModal';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const statusColors = {
  'Scheduled': 'bg-primary/10 text-primary',
  'Checked In': 'bg-accent/10 text-accent',
  'In Progress': 'bg-orange-50 text-orange-600',
  'Completed': 'bg-green-50 text-green-700',
  'Cancelled': 'bg-destructive/10 text-destructive',
};

export default function AppointmentDetailModal({ appointment, patient, onClose, onSummaryUpdated }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [generatingSummary, setGeneratingSummary] = useState(false);
  const [generatingCost, setGeneratingCost] = useState(false);
  const [vitals, setVitals] = useState({ bp: '', temp: '', pulse: '', weight: '', spo2: '' });
  const [newDate, setNewDate] = useState('');
  const [savingPrescreen, setSavingPrescreen] = useState(false);
  const [showEligibilityModal, setShowEligibilityModal] = useState(false);

  // Keep newDate in sync when appointment changes
  useEffect(() => {
    setNewDate(appointment?.appointment_date?.slice(0, 16) || '');
    setVitals({ bp: '', temp: '', pulse: '', weight: '', spo2: '' });
  }, [appointment?.id]);

  if (!appointment) return null;

  const isLocked = appointment.is_locked || appointment.status === 'Completed';

  const generateSummary = async () => {
    setGeneratingSummary(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda clinical AI. Based on this appointment, generate a brief summary and identify any risk flags.
Patient: ${appointment.patient_name}
Reason: ${appointment.reason || 'Not specified'}
AI Call Notes: ${appointment.ai_call_notes || 'None'}
Patient history: ${patient ? `Allergies: ${patient.allergies || 'None'}, Chronic: ${patient.chronic_conditions || 'None'}` : 'N/A'}
Provide: a 2-3 sentence clinical summary and any risk flags.`,
        response_json_schema: {
          type: 'object',
          properties: {
            summary: { type: 'string' },
            risk_flags: { type: 'string' },
          }
        }
      });
      await base44.entities.Appointment.update(appointment.id, {
        ai_summary: res.summary,
        risk_flags: res.risk_flags || '',
      });
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      queryClient.invalidateQueries({ queryKey: ['patient-appointments', appointment.patient_id] });
      onSummaryUpdated?.({ ...appointment, ai_summary: res.summary, risk_flags: res.risk_flags });
      toast.success('AI summary generated');
    } catch {
      toast.error('Failed to generate summary');
    } finally {
      setGeneratingSummary(false);
    }
  };

  const generateCostEstimate = async () => {
    setGeneratingCost(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda healthcare billing estimator. Based on this appointment's information, estimate the total cost in RWF.
Patient: ${appointment.patient_name}
Reason: ${appointment.reason || 'General visit'}
AI Notes: ${appointment.ai_call_notes || 'None'}
Insurance: ${patient?.insurance_type || 'None'}

Provide ONLY a total estimated cost in RWF (number). Consider Rwanda tariffs and any insurance co-payment.
Do NOT list individual labs/medications — just the total.`,
        response_json_schema: {
          type: 'object',
          properties: {
            total_cost_rwf: { type: 'number' },
            cost_summary: { type: 'string' },
          }
        }
      });
      await base44.entities.Appointment.update(appointment.id, {
        estimated_cost_rwf: res.total_cost_rwf,
      });
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      queryClient.invalidateQueries({ queryKey: ['patient-appointments', appointment.patient_id] });
      onSummaryUpdated?.({ ...appointment, estimated_cost_rwf: res.total_cost_rwf });
      toast.success(`Estimated cost: ${res.total_cost_rwf?.toLocaleString()} RWF`);
    } catch {
      toast.error('Cost estimation failed');
    } finally {
      setGeneratingCost(false);
    }
  };

  const savePrescreen = async () => {
    setSavingPrescreen(true);
    try {
      const prescreenData = { vitals, prescreened_at: new Date().toISOString() };
      const updates = {
        receptionist_prescreening: JSON.stringify(prescreenData),
        status: 'Checked In',
      };
      if (newDate) updates.appointment_date = new Date(newDate).toISOString();
      await base44.entities.Appointment.update(appointment.id, updates);
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      queryClient.invalidateQueries({ queryKey: ['patient-appointments', appointment.patient_id] });
      toast.success('Pre-screening saved. Patient checked in.');
      onSummaryUpdated?.({ ...appointment, ...updates });
      onClose();
    } catch {
      toast.error('Failed to save pre-screening');
    } finally {
      setSavingPrescreen(false);
    }
  };

  return (
    <>
    <Dialog open={!!appointment} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
              <User className="w-4 h-4 text-primary" />
            </div>
            {appointment.patient_name}
            <Badge className={`text-xs ml-auto ${statusColors[appointment.status] || ''}`}>{appointment.status}</Badge>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Basic Info */}
          <div className="grid grid-cols-2 gap-3 text-sm">
            <div className="flex items-center gap-2 text-muted-foreground">
              <Clock className="w-3.5 h-3.5" />
              {appointment.appointment_date ? format(new Date(appointment.appointment_date), 'MMM d, yyyy HH:mm') : 'No date'}
            </div>
            {appointment.appointment_number && (
              <div className="text-xs font-mono text-muted-foreground">#{appointment.appointment_number}</div>
            )}
          </div>

          <div className="p-3 bg-muted/40 rounded-lg">
            <p className="text-xs text-muted-foreground">Reason</p>
            <p className="text-sm font-medium">{appointment.reason || 'No reason specified'}</p>
          </div>

          {/* Insurance Eligibility */}
          <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <ShieldCheck className="w-4 h-4 text-primary" />
                <p className="text-xs font-semibold">Insurance Eligibility</p>
                {patient?.insurance_type && (
                  <span className="text-xs text-muted-foreground">— {patient.insurance_type}</span>
                )}
              </div>
              <Button size="sm" variant="outline" className="gap-1 text-xs h-7" onClick={() => setShowEligibilityModal(true)}>
                <ShieldCheck className="w-3 h-3" /> Check Eligibility
              </Button>
            </div>
            <p className="text-xs text-muted-foreground mt-1">
              {patient?.insurance_id
                ? `Member ID: ${patient.insurance_id} — Click to verify full coverage & fraud check`
                : 'No insurance ID on file — click to verify eligibility'}
            </p>
          </div>

          {/* Patient contact info from call */}
          {appointment.notes && appointment.intake_source === 'AI Phone Call' && (
            <div className="p-3 bg-muted/40 rounded-lg grid grid-cols-2 gap-1.5 text-xs">
              <p className="col-span-2 font-semibold text-muted-foreground mb-0.5">📋 Patient Info from Call</p>
              {appointment.notes.split(' | ').map((item, i) => (
                <div key={i} className="text-foreground/80">{item}</div>
              ))}
            </div>
          )}

          {/* LOCKED AI Call Notes — shown to everyone but not editable */}
          {appointment.ai_call_notes && (
            <div className="p-4 bg-primary/5 rounded-xl border border-primary/20">
              <div className="flex items-center gap-2 mb-2">
                <Lock className="w-4 h-4 text-primary" />
                <p className="text-xs font-bold text-primary uppercase tracking-wider">AI Phone Call Notes — LOCKED</p>
              </div>
              <pre className="text-xs text-foreground/80 whitespace-pre-wrap leading-relaxed font-sans bg-background/60 p-3 rounded-lg border border-border/50">
                {appointment.ai_call_notes}
              </pre>
              <p className="text-xs text-muted-foreground mt-2">These notes are verbatim from the patient call and cannot be modified by anyone.</p>
            </div>
          )}

          {/* Call Transcript */}
          {appointment.call_transcript && (
            <details className="p-3 bg-muted/20 rounded-lg border border-border/40 cursor-pointer">
              <summary className="text-xs font-semibold text-muted-foreground">📞 Full Call Transcript (click to expand)</summary>
              <pre className="text-xs text-foreground/70 whitespace-pre-wrap mt-2 leading-relaxed">{appointment.call_transcript}</pre>
            </details>
          )}

          {/* AI Summary */}
          {appointment.ai_summary && (
            <div className="p-3 bg-accent/5 rounded-lg border border-accent/20">
              <p className="text-xs font-semibold text-accent mb-1">AI Clinical Summary</p>
              <p className="text-xs text-foreground/80">{appointment.ai_summary}</p>
              {appointment.risk_flags && (
                <p className="text-xs text-destructive mt-1 font-medium">⚠ {appointment.risk_flags}</p>
              )}
            </div>
          )}

          {/* RECEPTIONIST SECTION — only when not locked */}
          {!isLocked && (
            <>
              {/* Appointment Time Change */}
              <div>
                <Label className="text-xs font-semibold">Confirm/Change Appointment Time (based on doctor availability)</Label>
                <Input
                  type="datetime-local"
                  className="mt-1"
                  value={newDate}
                  onChange={e => setNewDate(e.target.value)}
                />
              </div>

              {/* Pre-screening Vitals */}
              <div>
                <Label className="text-xs font-semibold">Pre-Screening Vitals</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {[
                    { key: 'bp', label: 'BP (mmHg)' },
                    { key: 'temp', label: 'Temp (°C)' },
                    { key: 'pulse', label: 'Pulse (bpm)' },
                    { key: 'weight', label: 'Weight (kg)' },
                    { key: 'spo2', label: 'SpO2 (%)' },
                  ].map(f => (
                    <div key={f.key}>
                      <Label className="text-xs text-muted-foreground">{f.label}</Label>
                      <Input className="mt-0.5 h-8 text-xs" value={vitals[f.key]} onChange={e => setVitals(v => ({ ...v, [f.key]: e.target.value }))} placeholder={f.label} />
                    </div>
                  ))}
                </div>
              </div>

              {/* AI Cost Estimate — for receptionist ONLY (no lab/med details) */}
              <div className="p-3 bg-muted/30 rounded-lg border border-border/50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <DollarSign className="w-4 h-4 text-primary" />
                    <p className="text-xs font-semibold">Estimated Total Cost (Receptionist View)</p>
                  </div>
                  <Button size="sm" variant="outline" className="gap-1 text-xs h-7" onClick={generateCostEstimate} disabled={generatingCost}>
                    {generatingCost ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                    Estimate Cost
                  </Button>
                </div>
                {appointment.estimated_cost_rwf ? (
                  <p className="text-lg font-bold text-primary mt-2">{appointment.estimated_cost_rwf?.toLocaleString()} RWF</p>
                ) : (
                  <p className="text-xs text-muted-foreground mt-1">Click "Estimate Cost" to get AI cost estimate. Specific lab/medication details are doctor-only.</p>
                )}
              </div>

              <div className="flex gap-2 flex-wrap">
                <Button onClick={savePrescreen} disabled={savingPrescreen} className="gap-2">
                  {savingPrescreen ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                  Confirm Appointment & Check In Patient
                </Button>
                <Button variant="outline" className="gap-2" onClick={generateSummary} disabled={generatingSummary}>
                  {generatingSummary ? <Loader2 className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
                  AI Summary
                </Button>
              </div>
            </>
          )}

          {isLocked && (
            <div className="p-3 bg-muted/30 rounded-lg flex items-center gap-2">
              <Lock className="w-4 h-4 text-muted-foreground" />
              <p className="text-xs text-muted-foreground">This appointment is completed and locked. No edits are allowed.</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>

    <EligibilityModal
      open={showEligibilityModal}
      onClose={() => setShowEligibilityModal(false)}
      appointment={appointment}
      patient={patient}
    />
    </>
  );
}