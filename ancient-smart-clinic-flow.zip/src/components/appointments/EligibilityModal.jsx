import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  ShieldCheck, ShieldX, Loader2, CheckCircle2, XCircle,
  AlertTriangle, MapPin, Clock, Copy, User, Scan
} from 'lucide-react';
import { toast } from 'sonner';

const RWANDA_INSURERS = ['RSSB (RAMA)', 'MMI', 'Mutuelle de Santé', 'Private'];

export default function EligibilityModal({ open, onClose, appointment, patient }) {
  const [form, setForm] = useState({
    insurance_id: '',
    national_id: '',
    insurance_type: '',
    patient_name: '',
  });
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState(null);
  const [fraudAnalysis, setFraudAnalysis] = useState(null);

  // Pre-fill from patient/appointment when opened
  useEffect(() => {
    if (open) {
      setResult(null);
      setFraudAnalysis(null);
      setForm({
        insurance_id: patient?.insurance_id || '',
        national_id: patient?.national_id || '',
        insurance_type: patient?.insurance_type || '',
        patient_name: appointment?.patient_name || '',
      });
    }
  }, [open, patient, appointment]);

  const checkEligibility = async () => {
    if (!form.insurance_type) { toast.error('Select an insurance provider'); return; }
    setChecking(true);
    setResult(null);
    setFraudAnalysis(null);
    try {
      const [res, fraudRes] = await Promise.all([
        base44.integrations.Core.InvokeLLM({
          prompt: `You are a Rwanda real-time insurance eligibility verification system. Verify eligibility for:

Patient Name: ${form.patient_name || 'N/A'}
National ID: ${form.national_id || 'N/A'}
Insurance Provider: ${form.insurance_type}
Insurance Member ID: ${form.insurance_id || 'N/A'}

Rwanda insurance providers: RSSB (RAMA) — Rwanda Social Security Board, MMI — Military Medical Insurance, Mutuelle de Santé — Community Health Insurance.

Perform detailed eligibility verification. Include co-payment rates per Rwanda's tariff structure, benefit limits, active/inactive status, and any fraud flags.`,
          response_json_schema: {
            type: 'object',
            properties: {
              is_eligible: { type: 'boolean' },
              status: { type: 'string' },
              member_since: { type: 'string' },
              coverage_end: { type: 'string' },
              plan_name: { type: 'string' },
              co_payment_percentage: { type: 'number' },
              covered_services: { type: 'array', items: { type: 'string' } },
              excluded_services: { type: 'array', items: { type: 'string' } },
              prior_auth_required: { type: 'array', items: { type: 'string' } },
              benefit_limits: { type: 'array', items: { type: 'string' } },
              notes: { type: 'string' },
            }
          }
        }),
        base44.integrations.Core.InvokeLLM({
          prompt: `Analyze fraud risk for insurance eligibility:
Patient: ${form.patient_name}
National ID: ${form.national_id}
Insurance: ${form.insurance_type}
Member ID: ${form.insurance_id}

Check location inconsistencies, visit frequency abuse, duplicate service usage, member ID mismatches.`,
          response_json_schema: {
            type: 'object',
            properties: {
              location_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
              location_notes: { type: 'string' },
              visit_frequency_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
              visit_frequency_notes: { type: 'string' },
              duplicate_usage_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
              duplicate_usage_notes: { type: 'string' },
              overall_fraud_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
              recommendations: { type: 'array', items: { type: 'string' } }
            }
          }
        })
      ]);
      setResult(res);
      setFraudAnalysis(fraudRes);
    } catch {
      toast.error('Eligibility check failed. Please try again.');
    } finally {
      setChecking(false);
    }
  };

  const riskColor = (risk) => {
    if (risk === 'None') return 'bg-accent/10 text-accent';
    if (risk === 'Low') return 'bg-orange-100 text-orange-700';
    return 'bg-destructive/10 text-destructive';
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-primary" />
            Insurance Eligibility Verification
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 mt-2">
          {/* Patient Info Summary */}
          <div className="p-3 bg-muted/40 rounded-lg flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
              <User className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-semibold">{form.patient_name}</p>
              <p className="text-xs text-muted-foreground">
                {form.national_id ? `National ID: ${form.national_id}` : 'No National ID on file'}
              </p>
            </div>
            {patient?.national_id_card && (
              <img src={patient.national_id_card} alt="ID Card" className="h-12 rounded border border-border ml-auto" />
            )}
            {!patient?.national_id_card && (
              <div className="ml-auto flex items-center gap-1 text-xs text-muted-foreground">
                <Scan className="w-3.5 h-3.5" /> No ID card on file
              </div>
            )}
          </div>

          {/* Editable Insurance Fields */}
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label className="text-xs">Insurance Provider *</Label>
              <Select value={form.insurance_type} onValueChange={v => setForm(f => ({ ...f, insurance_type: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select insurer" /></SelectTrigger>
                <SelectContent>
                  {RWANDA_INSURERS.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Insurance Member ID</Label>
              <Input className="mt-1" value={form.insurance_id} onChange={e => setForm(f => ({ ...f, insurance_id: e.target.value }))} placeholder="Member ID" />
            </div>
            <div>
              <Label className="text-xs">National ID</Label>
              <Input className="mt-1" value={form.national_id} onChange={e => setForm(f => ({ ...f, national_id: e.target.value }))} placeholder="1XXXXXXXXXXXXXXXXX" />
            </div>
          </div>

          <Button className="w-full gap-2" onClick={checkEligibility} disabled={checking || !form.insurance_type}>
            {checking
              ? <><Loader2 className="w-4 h-4 animate-spin" /> Verifying Eligibility...</>
              : <><ShieldCheck className="w-4 h-4" /> Verify Eligibility</>}
          </Button>

          {/* Result */}
          {result && (
            <>
              {/* Final Decision Banner */}
              <div className={`p-4 rounded-xl border-l-4 flex items-center gap-4 ${result.is_eligible ? 'bg-accent/5 border-l-accent' : 'bg-destructive/5 border-l-destructive'}`}>
                {result.is_eligible
                  ? <CheckCircle2 className="w-10 h-10 text-accent shrink-0" />
                  : <XCircle className="w-10 h-10 text-destructive shrink-0" />}
                <div className="flex-1">
                  <p className="text-lg font-bold">{result.is_eligible ? '✓ ELIGIBLE FOR COVERAGE' : '✗ NOT ELIGIBLE'}</p>
                  <p className="text-xs text-muted-foreground mt-0.5">{result.status}</p>
                </div>
                {fraudAnalysis && (
                  <Badge className={`text-xs shrink-0 ${fraudAnalysis.overall_fraud_risk === 'None' ? 'bg-accent text-white' : fraudAnalysis.overall_fraud_risk === 'Low' ? 'bg-orange-500 text-white' : 'bg-destructive text-white'}`}>
                    Fraud Risk: {fraudAnalysis.overall_fraud_risk}
                  </Badge>
                )}
              </div>

              {/* Coverage Details */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
                {result.plan_name && (
                  <div className="p-2 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Plan</p>
                    <p className="text-sm font-semibold">{result.plan_name}</p>
                  </div>
                )}
                {result.co_payment_percentage !== undefined && (
                  <div className="p-2 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Co-Payment</p>
                    <p className="text-sm font-semibold">{result.co_payment_percentage}%</p>
                  </div>
                )}
                {result.member_since && (
                  <div className="p-2 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Member Since</p>
                    <p className="text-sm font-semibold">{result.member_since}</p>
                  </div>
                )}
                {result.coverage_end && (
                  <div className="p-2 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Expires</p>
                    <p className="text-sm font-semibold">{result.coverage_end}</p>
                  </div>
                )}
              </div>

              {/* Covered / Excluded */}
              <div className="grid grid-cols-2 gap-3">
                {result.covered_services?.length > 0 && (
                  <div className="p-3 bg-accent/5 rounded-lg border border-accent/20">
                    <p className="text-xs font-semibold text-accent mb-1">✓ Covered Services</p>
                    {result.covered_services.slice(0, 4).map((s, i) => (
                      <p key={i} className="text-xs text-foreground/80">• {s}</p>
                    ))}
                  </div>
                )}
                {result.excluded_services?.length > 0 && (
                  <div className="p-3 bg-destructive/5 rounded-lg border border-destructive/20">
                    <p className="text-xs font-semibold text-destructive mb-1">✗ Not Covered</p>
                    {result.excluded_services.slice(0, 4).map((s, i) => (
                      <p key={i} className="text-xs text-foreground/80">• {s}</p>
                    ))}
                  </div>
                )}
              </div>

              {/* Prior Auth */}
              {result.prior_auth_required?.length > 0 && (
                <div className="p-3 bg-orange-50 rounded-lg border border-orange-200">
                  <div className="flex items-center gap-2 mb-1">
                    <AlertTriangle className="w-3.5 h-3.5 text-orange-600" />
                    <p className="text-xs font-semibold text-orange-600">Prior Authorization Required</p>
                  </div>
                  <div className="flex flex-wrap gap-1.5">
                    {result.prior_auth_required.map((a, i) => (
                      <Badge key={i} className="text-xs bg-orange-100 text-orange-700">{a}</Badge>
                    ))}
                  </div>
                </div>
              )}

              {/* Fraud Analysis */}
              {fraudAnalysis && (
                <div className="p-3 bg-muted/30 rounded-lg border border-border/50 space-y-2">
                  <p className="text-xs font-bold text-foreground">Fraud Detection</p>
                  {[
                    { icon: MapPin, label: 'Location', risk: fraudAnalysis.location_risk, notes: fraudAnalysis.location_notes },
                    { icon: Clock, label: 'Visit Frequency', risk: fraudAnalysis.visit_frequency_risk, notes: fraudAnalysis.visit_frequency_notes },
                    { icon: Copy, label: 'Duplicate Usage', risk: fraudAnalysis.duplicate_usage_risk, notes: fraudAnalysis.duplicate_usage_notes },
                  ].map(({ icon: Icon, label, risk, notes }) => (
                    <div key={label} className="flex items-start gap-2 p-2 bg-background rounded-lg">
                      <Icon className="w-3.5 h-3.5 text-muted-foreground mt-0.5 shrink-0" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between">
                          <p className="text-xs font-medium">{label}</p>
                          <Badge className={`text-xs ${riskColor(risk)}`}>{risk}</Badge>
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">{notes}</p>
                      </div>
                    </div>
                  ))}
                  {fraudAnalysis.recommendations?.length > 0 && (
                    <div className="mt-1 space-y-0.5">
                      {fraudAnalysis.recommendations.map((r, i) => (
                        <p key={i} className="text-xs text-foreground/70">• {r}</p>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {result.notes && (
                <div className="p-3 bg-muted/40 rounded-lg">
                  <p className="text-xs font-semibold mb-1">Verification Notes</p>
                  <p className="text-xs text-muted-foreground">{result.notes}</p>
                </div>
              )}
            </>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}