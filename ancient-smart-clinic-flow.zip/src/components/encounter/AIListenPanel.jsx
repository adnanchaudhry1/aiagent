import React, { useState, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, Sparkles, Loader2, X } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function AIListenPanel({ onPopulate, patient, onClose }) {
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [analyzing, setAnalyzing] = useState(false);

  const recognitionRef = useRef(null);
  const shouldRestartRef = useRef(false);
  const transcriptRef = useRef('');

  const startRecording = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      toast.error('Speech recognition not supported. Use Chrome or Edge.');
      return;
    }
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

    const startSession = () => {
      const rec = new SR();
      rec.continuous = true;
      rec.interimResults = true;
      rec.lang = 'en-US';

      rec.onstart = () => setIsRecording(true);
      rec.onresult = (event) => {
        let newFinal = '';
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) newFinal += event.results[i][0].transcript + ' ';
          else interim += event.results[i][0].transcript;
        }
        if (newFinal) transcriptRef.current += newFinal;
        setTranscript(transcriptRef.current + interim);
      };
      rec.onerror = (e) => {
        if (e.error === 'not-allowed') {
          toast.error('Mic access denied.');
          shouldRestartRef.current = false;
          setIsRecording(false);
        }
      };
      rec.onend = () => {
        if (shouldRestartRef.current) {
          setTimeout(() => { if (shouldRestartRef.current) try { startSession(); } catch { setIsRecording(false); } }, 100);
        } else {
          setIsRecording(false);
        }
      };
      recognitionRef.current = rec;
      try { rec.start(); } catch { setIsRecording(false); }
    };

    shouldRestartRef.current = true;
    startSession();
  };

  const stopRecording = () => {
    shouldRestartRef.current = false;
    if (recognitionRef.current) { try { recognitionRef.current.stop(); } catch {} recognitionRef.current = null; }
    setIsRecording(false);
  };

  const analyzeAndPopulate = async () => {
    if (!transcript.trim()) { toast.error('No transcript to analyze'); return; }
    stopRecording();
    setAnalyzing(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are Murava AI — Rwanda's clinical copilot. Extract a complete encounter from this conversation (may be in English or Kinyarwanda — translate to English).

Patient: ${patient?.full_name || 'Unknown'}
${patient ? `Allergies: ${patient.allergies || 'None'}, Chronic: ${patient.chronic_conditions || 'None'}, Insurance: ${patient.insurance_type || 'N/A'}` : ''}

Conversation:
"${transcript}"

Extract and structure ALL encounter fields including vitals if mentioned, history, examination, diagnoses with ICD-10 codes, medications from Rwanda Essential Medicines List, lab orders, procedures, clinical notes, and disposition.`,
        response_json_schema: {
          type: 'object',
          properties: {
            chief_complaint: { type: 'string' },
            vitals: {
              type: 'object',
              properties: {
                temperature: { type: 'string' }, blood_pressure: { type: 'string' },
                pulse: { type: 'string' }, respiratory_rate: { type: 'string' },
                weight: { type: 'string' }, height: { type: 'string' }, oxygen_saturation: { type: 'string' }
              }
            },
            history_present_illness: { type: 'string' },
            past_medical_history: { type: 'string' },
            surgical_history: { type: 'string' },
            family_history: { type: 'string' },
            social_history: { type: 'string' },
            general_examination: { type: 'string' },
            systemic_examination: { type: 'string' },
            subjective: { type: 'string' },
            objective: { type: 'string' },
            assessment: { type: 'string' },
            plan: { type: 'string' },
            diagnoses: {
              type: 'array',
              items: { type: 'object', properties: { code: { type: 'string' }, description: { type: 'string' }, type: { type: 'string' } } }
            },
            medications: {
              type: 'array',
              items: { type: 'object', properties: { name: { type: 'string' }, dose: { type: 'string' }, frequency: { type: 'string' }, route: { type: 'string' }, duration: { type: 'string' } } }
            },
            lab_orders: {
              type: 'array',
              items: { type: 'object', properties: { test: { type: 'string' }, reason: { type: 'string' }, urgency: { type: 'string' } } }
            },
            procedures: { type: 'array', items: { type: 'string' } },
            clinical_notes: { type: 'string' },
            disposition: { type: 'string' },
            follow_up_date: { type: 'string' },
            referral: { type: 'string' },
          }
        }
      });
      onPopulate(result, transcript);
      toast.success('Encounter populated from AI Listen!');
      onClose();
    } catch {
      toast.error('AI analysis failed. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/60 z-50 flex items-center justify-center p-4">
      <div className="bg-background rounded-2xl shadow-2xl w-full max-w-2xl">
        <div className="flex items-center justify-between p-5 border-b">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
              <Mic className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-bold">AI Listen Mode</p>
              <p className="text-xs text-muted-foreground">Speak the encounter — AI will populate all fields</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={isRecording ? 'destructive' : 'secondary'}>
              {isRecording ? '🔴 Recording' : 'Ready'}
            </Badge>
            <Button variant="ghost" size="icon" onClick={() => { stopRecording(); onClose(); }}><X className="w-4 h-4" /></Button>
          </div>
        </div>
        <div className="p-5 space-y-4">
          <div className="flex justify-center">
            <Button
              size="lg"
              variant={isRecording ? 'destructive' : 'default'}
              className="gap-2 rounded-full px-8"
              onClick={isRecording ? stopRecording : startRecording}
            >
              {isRecording ? <><MicOff className="w-5 h-5" /> Stop Recording</> : <><Mic className="w-5 h-5" /> Start Recording</>}
            </Button>
          </div>
          {isRecording && (
            <div className="flex items-center justify-center gap-2 text-sm text-destructive">
              <span className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
              Listening — speak clearly in English or Kinyarwanda
            </div>
          )}
          <Textarea
            value={transcript}
            onChange={e => { setTranscript(e.target.value); transcriptRef.current = e.target.value; }}
            placeholder="Transcription appears here... or type manually"
            className="min-h-[180px] text-sm leading-relaxed"
          />
          <div className="flex gap-2">
            <Button className="flex-1 gap-2" onClick={analyzeAndPopulate} disabled={analyzing || !transcript.trim()}>
              {analyzing ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing & Populating...</> : <><Sparkles className="w-4 h-4" /> Generate & Populate Entire Encounter</>}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}