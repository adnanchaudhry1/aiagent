import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Search, Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function DiagnosisSection({ diagnoses, onChange }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState([]);

  const searchDiagnosis = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Find ICD-10 diagnosis codes matching: "${searchQuery}". Return the top 5 most relevant results with code and description. Rwanda uses ICD-10.`,
        response_json_schema: {
          type: 'object',
          properties: {
            results: {
              type: 'array',
              items: { type: 'object', properties: { code: { type: 'string' }, description: { type: 'string' } } }
            }
          }
        }
      });
      setResults(result.results || []);
    } catch {
      toast.error('Search failed');
    } finally {
      setSearching(false);
    }
  };

  const addDiagnosis = (code, description, type = 'Primary') => {
    if (diagnoses.some(d => d.code === code)) { toast.info('Already added'); return; }
    onChange([...diagnoses, { code, description, type }]);
    setResults([]);
    setSearchQuery('');
  };

  const removeDiagnosis = (idx) => onChange(diagnoses.filter((_, i) => i !== idx));

  const updateType = (idx, type) => {
    const updated = [...diagnoses];
    updated[idx] = { ...updated[idx], type };
    onChange(updated);
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Input
          className="h-8 text-xs flex-1"
          placeholder="Search by name or ICD-10 code..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && searchDiagnosis()}
        />
        <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={searchDiagnosis} disabled={searching}>
          {searching ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
          Search
        </Button>
        <Button size="sm" variant="default" className="h-8 gap-1 text-xs bg-primary" onClick={() => {
          if (searchQuery.trim()) addDiagnosis(searchQuery, searchQuery, 'Primary');
        }}>
          <Plus className="w-3 h-3" /> Add
        </Button>
      </div>

      {results.length > 0 && (
        <div className="border rounded-lg overflow-hidden">
          {results.map((r, i) => (
            <div key={i} className="flex items-center justify-between px-3 py-2 hover:bg-muted/50 cursor-pointer border-b last:border-0"
              onClick={() => addDiagnosis(r.code, r.description)}>
              <div>
                <span className="text-xs font-mono font-bold text-primary mr-2">{r.code}</span>
                <span className="text-xs">{r.description}</span>
              </div>
              <Plus className="w-3.5 h-3.5 text-primary" />
            </div>
          ))}
        </div>
      )}

      {diagnoses.length > 0 && (
        <table className="w-full text-xs">
          <thead><tr className="border-b">
            <th className="text-left py-1.5 font-semibold text-muted-foreground">Diagnosis</th>
            <th className="text-left py-1.5 font-semibold text-muted-foreground">Type</th>
            <th className="py-1.5"></th>
          </tr></thead>
          <tbody>
            {diagnoses.map((d, i) => (
              <tr key={i} className="border-b last:border-0">
                <td className="py-2">
                  <span className="font-mono font-bold text-primary mr-2">{d.code}</span>
                  {d.description}
                </td>
                <td className="py-2">
                  <Select value={d.type} onValueChange={v => updateType(i, v)}>
                    <SelectTrigger className="h-7 w-28 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Primary" className="text-xs">Primary</SelectItem>
                      <SelectItem value="Secondary" className="text-xs">Secondary</SelectItem>
                      <SelectItem value="Complication" className="text-xs">Complication</SelectItem>
                    </SelectContent>
                  </Select>
                </td>
                <td className="py-2 text-right">
                  <button onClick={() => removeDiagnosis(i)} className="text-destructive hover:text-destructive/70">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}