import React from 'react';
import { Card } from '@/components/ui/card';
import { Map } from 'lucide-react';
import PatientGISPanel from '@/components/patient/PatientGISPanel';

export default function EncounterGISSection({ patient, assessment }) {
  if (!patient || !assessment) {
    return (
      <Card className="p-6 border-0 shadow-sm text-center">
        <Map className="w-6 h-6 text-muted-foreground mx-auto mb-2" />
        <p className="text-xs text-muted-foreground">Complete diagnosis/assessment to see GIS disease intelligence for this patient.</p>
      </Card>
    );
  }
  return (
    <PatientGISPanel
      patient={patient}
      latestEncounter={{ assessment }}
    />
  );
}