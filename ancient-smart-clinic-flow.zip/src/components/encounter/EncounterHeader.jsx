import React from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';

const ENCOUNTER_TYPES = ['Outpatient Visit', 'Inpatient Admission', 'Emergency', 'Follow-up', 'Telehealth', 'ANC Visit', 'Immunization'];
const LOCATIONS = ['Outpatient Clinic', 'Emergency Department', 'Inpatient Ward', 'ICU', 'Maternity Ward', 'Pediatric Ward', 'Lab'];

export default function EncounterHeader({ form, onChange, patients, status }) {
  return (
    <div className="bg-primary/5 border border-primary/20 rounded-xl p-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-bold text-primary uppercase tracking-wider">Encounter Details</h2>
        <Badge variant={status === 'Doctor Approved' ? 'default' : status === 'AI Review' ? 'secondary' : 'outline'} className="text-xs">
          {status}
        </Badge>
      </div>
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <div>
          <Label className="text-xs text-muted-foreground">Patient *</Label>
          <Select value={form.patient_id} onValueChange={v => {
            const p = patients.find(p => p.id === v);
            onChange({ patient_id: v, patient_name: p?.full_name || '' });
          }}>
            <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue placeholder="Select patient" /></SelectTrigger>
            <SelectContent>
              {patients.map(p => <SelectItem key={p.id} value={p.id} className="text-xs">{p.full_name}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Encounter Type *</Label>
          <Select value={form.encounter_type} onValueChange={v => onChange({ encounter_type: v })}>
            <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue placeholder="Type" /></SelectTrigger>
            <SelectContent>
              {ENCOUNTER_TYPES.map(t => <SelectItem key={t} value={t} className="text-xs">{t}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Date *</Label>
          <Input type="date" className="mt-1 h-8 text-xs" value={form.encounter_date} onChange={e => onChange({ encounter_date: e.target.value })} />
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Location *</Label>
          <Select value={form.location} onValueChange={v => onChange({ location: v })}>
            <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue placeholder="Location" /></SelectTrigger>
            <SelectContent>
              {LOCATIONS.map(l => <SelectItem key={l} value={l} className="text-xs">{l}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
        <div>
          <Label className="text-xs text-muted-foreground">Provider</Label>
          <Input className="mt-1 h-8 text-xs" value={form.provider} placeholder="Dr. Name" onChange={e => onChange({ provider: e.target.value })} />
        </div>
      </div>
    </div>
  );
}