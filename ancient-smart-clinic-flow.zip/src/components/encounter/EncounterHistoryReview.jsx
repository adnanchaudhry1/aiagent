import React, { useMemo } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, TrendingUp, Clock, CheckCircle2 } from 'lucide-react';
import { format } from 'date-fns';

export default function EncounterHistoryReview({ currentEncounter, allEncounters = [], onCompareWithHistory }) {
  // Get previous encounters for same patient
  const previousEncounters = useMemo(() => {
    if (!currentEncounter?.patient_id) return [];
    return allEncounters
      .filter(e => e.patient_id === currentEncounter.patient_id && e.id !== currentEncounter.id)
      .sort((a, b) => new Date(b.encounter_date) - new Date(a.encounter_date))
      .slice(0, 3); // Show last 3 encounters
  }, [currentEncounter, allEncounters]);

  if (!currentEncounter || previousEncounters.length === 0) {
    return null;
  }

  return (
    <Card className="p-5 border-0 shadow-sm bg-primary/5 rounded-xl">
      <div className="flex items-center gap-2 mb-4">
        <TrendingUp className="w-4 h-4 text-primary" />
        <h3 className="text-sm font-semibold text-primary">Encounter History</h3>
        <Badge variant="secondary" className="text-xs">{previousEncounters.length} previous</Badge>
      </div>

      {/* Key Changes Summary */}
      <div className="space-y-3 mb-4">
        {previousEncounters.map((prev, idx) => {
          const currentChief = currentEncounter.chief_complaint || '';
          const prevChief = prev.chief_complaint || '';
          const isDifferent = currentChief.toLowerCase() !== prevChief.toLowerCase();

          return (
            <div key={prev.id} className="p-3 bg-white rounded-lg border border-border/50">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <p className="text-xs font-semibold text-foreground">
                    {idx === 0 ? 'Most Recent Encounter' : `${idx} visit${idx > 1 ? 's' : ''} ago`}
                  </p>
                  <p className="text-xs text-muted-foreground mt-0.5">
                    {format(new Date(prev.encounter_date), 'MMM d, yyyy')}
                  </p>
                </div>
                <Badge variant="outline" className="text-xs">{prev.status}</Badge>
              </div>

              {/* Quick Summary */}
              <div className="space-y-1.5 text-xs">
                <div className="flex items-start gap-2">
                  <span className="font-semibold text-muted-foreground min-w-20">Chief:</span>
                  <span className="text-foreground">{prevChief || '—'}</span>
                </div>

                {isDifferent && (
                  <div className="flex items-center gap-2 p-2 bg-orange-50 rounded border border-orange-200">
                    <AlertTriangle className="w-3 h-3 text-orange-600 flex-shrink-0" />
                    <span className="text-orange-700 font-medium">Chief complaint changed from previous visit</span>
                  </div>
                )}

                {prev.assessment && (
                  <div className="flex items-start gap-2">
                    <span className="font-semibold text-muted-foreground min-w-20">Assessment:</span>
                    <span className="text-foreground line-clamp-2">{prev.assessment}</span>
                  </div>
                )}
              </div>
            </div>
          );
        })}
      </div>

      {/* Pattern Analysis */}
      {previousEncounters.length > 1 && (
        <div className="p-3 bg-white rounded-lg border border-accent/20 mb-4">
          <p className="text-xs font-semibold text-accent mb-2 flex items-center gap-1.5">
            <Clock className="w-3 h-3" /> Pattern Recognition
          </p>
          <p className="text-xs text-muted-foreground">
            This patient has visited {previousEncounters.length} times. Review history to identify ongoing issues or changes in condition.
          </p>
        </div>
      )}

      {/* Action Button */}
      {onCompareWithHistory && (
        <Button
          size="sm"
          variant="outline"
          className="text-xs h-8 w-full gap-2 border-primary/20 hover:bg-primary/5"
          onClick={onCompareWithHistory}
        >
          <CheckCircle2 className="w-3 h-3" /> Review Full History
        </Button>
      )}
    </Card>
  );
}