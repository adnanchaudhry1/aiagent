import { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// Workflow: Encounter → Coding → Pharmacy → Lab → Referrals → GIS Map → Insurance Claims → Follow-Up
const WORKFLOW_STEPS = {
  encounter: { next: 'coding', label: 'Medical Coding' },
  coding: { next: 'pharmacy', label: 'Pharmacy' },
  pharmacy: { next: 'lab', label: 'Lab Search' },
  lab: { next: 'referrals', label: 'Referrals' },
  referrals: { next: 'gis-map', label: 'GIS Disease Map' },
  'gis-map': { next: 'insurance', label: 'Insurance Claims' },
  insurance: { next: 'follow-up', label: 'Follow-Up Calls' },
  'follow-up': { next: null, label: 'Complete' },
};

const ROUTE_MAP = {
  encounter: '/encounter',
  coding: '/coding',
  pharmacy: '/pharmacy',
  lab: '/lab',
  referrals: '/referrals',
  'gis-map': '/gis-map',
  insurance: '/insurance',
  'follow-up': '/follow-up',
};

export function getNextStep(currentStep) {
  return WORKFLOW_STEPS[currentStep]?.next;
}

export function getNextStepLabel(currentStep) {
  return WORKFLOW_STEPS[currentStep]?.label;
}

export function getNextStepRoute(currentStep, encounterId, appointmentId) {
  const nextStep = getNextStep(currentStep);
  if (!nextStep) return null;
  const route = ROUTE_MAP[nextStep];
  if (!route) return null;
  const params = new URLSearchParams();
  if (encounterId) params.set('encounterId', encounterId);
  if (appointmentId) params.set('appointmentId', appointmentId);
  return `${route}?${params.toString()}`;
}

export function useEncounterWorkflow(currentStep, encounterId, shouldNavigate = false, appointmentId = null) {
  const navigate = useNavigate();

  useEffect(() => {
    if (shouldNavigate && encounterId) {
      const nextRoute = getNextStepRoute(currentStep, encounterId, appointmentId);
      if (nextRoute) {
        setTimeout(() => navigate(nextRoute), 500);
      }
    }
  }, [shouldNavigate, currentStep, encounterId, appointmentId, navigate]);
}

// Save/Proceed button used across all workflow pages
export function WorkflowProceedButton({ currentStep, encounterId, appointmentId, onSaveAndProceed, saving, label }) {
  const navigate = useNavigate();
  const nextLabel = WORKFLOW_STEPS[currentStep]?.label || 'Next';

  const handleClick = async () => {
    if (onSaveAndProceed) {
      await onSaveAndProceed();
    }
    const nextRoute = getNextStepRoute(currentStep, encounterId, appointmentId);
    if (nextRoute) navigate(nextRoute);
  };

  return (
    <button
      onClick={handleClick}
      disabled={saving}
      className="inline-flex items-center gap-2 px-4 py-2 bg-accent text-white rounded-md text-sm font-medium hover:bg-accent/90 disabled:opacity-50"
    >
      {saving ? '...' : (label || `Save & Proceed to ${nextLabel} →`)}
    </button>
  );
}