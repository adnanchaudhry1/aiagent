import { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, FlaskConical, Pill, CheckCircle2, Globe2, BookOpen, ChevronDown, ChevronUp, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

const SCHEMA = {
  type: "object",
  properties: {
    disease_summary: { type: "string" },
    treatment_plan: {
      type: "object",
      properties: {
        first_line: { type: "string" },
        second_line: { type: "string" },
        supportive_care: { type: "string" },
        contraindications: { type: "string" },
        duration: { type: "string" }
      }
    },
    recommended_labs: {
      type: "array",
      items: {
        type: "object",
        properties: {
          test: { type: "string" },
          reason: { type: "string" },
          priority: { type: "string" }
        }
      }
    },
    recommended_medications: {
      type: "array",
      items: {
        type: "object",
        properties: {
          drug: { type: "string" },
          dose: { type: "string" },
          route: { type: "string" },
          duration: { type: "string" },
          notes: { type: "string" }
        }
      }
    },
    global_outcomes: {
      type: "array",
      items: {
        type: "object",
        properties: {
          country: { type: "string" },
          approach: { type: "string" },
          success_rate: { type: "string" },
          key_factor: { type: "string" }
        }
      }
    },
    best_practice_resolution: {
      type: "object",
      properties: {
        who_guideline: { type: "string" },
        rwanda_moh_note: { type: "string" },
        monitoring_plan: { type: "string" },
        red_flags: { type: "array", items: { type: "string" } },
        patient_education: { type: "string" }
      }
    }
  }
};

export default function EvidenceBasedPanel({ diagnoses, chiefComplaint, patient, onApplyLabs, onApplyMeds }) {
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState(null);
  const [expanded, setExpanded] = useState(true);
  const [activeTab, setActiveTab] = useState('treatment');

  const diseaseContext = diagnoses?.map(d => d.description || d.code).join(', ') || chiefComplaint || '';

  const runAnalysis = async () => {
    if (!diseaseContext.trim()) {
      toast.error('Please add a diagnosis or chief complaint first');
      return;
    }
    setLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an expert clinical decision support system for Rwanda healthcare. 
        
Patient context:
- Disease/Diagnosis: ${diseaseContext}
- Chief Complaint: ${chiefComplaint || 'N/A'}
- Insurance: ${patient?.insurance_type || 'Unknown'}
- Known Allergies: ${patient?.allergies || 'None reported'}
- Chronic Conditions: ${patient?.chronic_conditions || 'None reported'}

Provide a comprehensive evidence-based best practice analysis including:
1. A brief disease summary (2-3 sentences)
2. Treatment plan (first-line, second-line, supportive care, contraindications, duration) - Rwanda Essential Medicines List preferred
3. Recommended laboratory tests with reason and priority (Critical/Routine/Optional) - list up to 6 key tests
4. Recommended medications with exact dose/route/duration - list up to 5 medications, prefer Rwanda EML
5. Global outcomes: how 4-5 different countries (include at least one African country) treat this disease, their approach, success rate, and key success factor
6. Best practice resolution: WHO guideline summary, Rwanda MOH specific note, monitoring plan, 3-4 red flag warning signs, and patient education point

Be specific, practical, and evidence-based. Tailor to Rwanda context and resource availability.`,
        add_context_from_internet: true,
        response_json_schema: SCHEMA,
        model: 'gemini_3_flash'
      });
      setResult(res);
      setExpanded(true);
    } catch {
      toast.error('Evidence analysis failed');
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { key: 'treatment', label: 'Treatment Plan', icon: BookOpen },
    { key: 'labs', label: 'Lab Tests', icon: FlaskConical },
    { key: 'meds', label: 'Medications', icon: Pill },
    { key: 'global', label: 'Global Outcomes', icon: Globe2 },
    { key: 'practice', label: 'Best Practice', icon: CheckCircle2 },
  ];

  return (
    <Card className="border-2 border-primary/30 shadow-md rounded-xl overflow-hidden">
      {/* Header */}
      <div className="bg-gradient-to-r from-primary/10 to-accent/10 p-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-primary flex items-center justify-center">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <p className="text-sm font-bold text-foreground">Evidence-Based Best Practice</p>
            <p className="text-xs text-muted-foreground">WHO + Global outcomes + Rwanda MOH guidelines</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            size="sm"
            className="h-8 gap-1.5 text-xs bg-primary hover:bg-primary/90"
            onClick={runAnalysis}
            disabled={loading}
          >
            {loading ? <Loader2 className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
            {loading ? 'Analyzing...' : result ? 'Re-Analyze' : 'Run Analysis'}
          </Button>
          {result && (
            <button onClick={() => setExpanded(e => !e)} className="text-muted-foreground hover:text-foreground">
              {expanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
            </button>
          )}
        </div>
      </div>

      {/* Disease tag */}
      {diseaseContext && (
        <div className="px-3 py-1.5 bg-muted/30 border-b flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Analyzing:</span>
          <Badge variant="outline" className="text-xs font-medium text-primary border-primary/40">{diseaseContext.slice(0, 80)}</Badge>
        </div>
      )}

      {/* Loading state */}
      {loading && (
        <div className="p-6 flex flex-col items-center gap-3">
          <Loader2 className="w-8 h-8 text-primary animate-spin" />
          <p className="text-sm text-muted-foreground text-center">Searching WHO guidelines, Rwanda MOH protocols,<br />and global treatment outcomes...</p>
        </div>
      )}

      {/* Results */}
      {result && expanded && !loading && (
        <div>
          {/* Disease summary */}
          {result.disease_summary && (
            <div className="px-4 py-3 bg-blue-50/60 border-b text-xs text-slate-700 leading-relaxed">
              <span className="font-semibold text-primary">Summary: </span>{result.disease_summary}
            </div>
          )}

          {/* Tabs */}
          <div className="flex border-b overflow-x-auto">
            {tabs.map(t => (
              <button
                key={t.key}
                onClick={() => setActiveTab(t.key)}
                className={`flex items-center gap-1.5 px-3 py-2 text-xs font-medium whitespace-nowrap border-b-2 transition-colors ${
                  activeTab === t.key
                    ? 'border-primary text-primary'
                    : 'border-transparent text-muted-foreground hover:text-foreground'
                }`}
              >
                <t.icon className="w-3.5 h-3.5" />
                {t.label}
              </button>
            ))}
          </div>

          <div className="p-4">
            {/* Treatment Plan */}
            {activeTab === 'treatment' && result.treatment_plan && (
              <div className="space-y-3">
                {[
                  { key: 'first_line', label: '1st Line Treatment', color: 'text-green-700 bg-green-50' },
                  { key: 'second_line', label: '2nd Line Treatment', color: 'text-blue-700 bg-blue-50' },
                  { key: 'supportive_care', label: 'Supportive Care', color: 'text-purple-700 bg-purple-50' },
                  { key: 'duration', label: 'Treatment Duration', color: 'text-orange-700 bg-orange-50' },
                  { key: 'contraindications', label: 'Contraindications', color: 'text-red-700 bg-red-50' },
                ].filter(f => result.treatment_plan[f.key]).map(f => (
                  <div key={f.key} className={`p-3 rounded-lg ${f.color}`}>
                    <p className="text-xs font-bold mb-1">{f.label}</p>
                    <p className="text-xs leading-relaxed">{result.treatment_plan[f.key]}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Lab Tests */}
            {activeTab === 'labs' && (
              <div className="space-y-2">
                {result.recommended_labs?.map((lab, i) => (
                  <div key={i} className="flex items-center justify-between p-2.5 rounded-lg border bg-muted/20">
                    <div>
                      <p className="text-xs font-semibold">{lab.test}</p>
                      <p className="text-xs text-muted-foreground mt-0.5">{lab.reason}</p>
                    </div>
                    <Badge className={`text-xs shrink-0 ml-2 ${
                      lab.priority === 'Critical' ? 'bg-red-100 text-red-700 border-red-200' :
                      lab.priority === 'Routine' ? 'bg-blue-100 text-blue-700 border-blue-200' :
                      'bg-gray-100 text-gray-600 border-gray-200'
                    }`} variant="outline">
                      {lab.priority}
                    </Badge>
                  </div>
                ))}
                {onApplyLabs && result.recommended_labs?.length > 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full mt-2 text-xs h-8 border-primary text-primary hover:bg-primary/5"
                    onClick={() => {
                      onApplyLabs(result.recommended_labs.map(l => ({ test: l.test, notes: l.reason, status: 'Ordered' })));
                      toast.success('Lab tests applied to order section');
                    }}
                  >
                    <FlaskConical className="w-3 h-3 mr-1" /> Apply All to Lab Orders
                  </Button>
                )}
              </div>
            )}

            {/* Medications */}
            {activeTab === 'meds' && (
              <div className="space-y-2">
                {result.recommended_medications?.map((med, i) => (
                  <div key={i} className="p-2.5 rounded-lg border bg-muted/20">
                    <div className="flex items-center justify-between mb-1">
                      <p className="text-xs font-semibold text-primary">{med.drug}</p>
                      <Badge variant="outline" className="text-xs">{med.route}</Badge>
                    </div>
                    <p className="text-xs text-foreground">{med.dose} · {med.duration}</p>
                    {med.notes && <p className="text-xs text-muted-foreground mt-0.5 italic">{med.notes}</p>}
                  </div>
                ))}
                {onApplyMeds && result.recommended_medications?.length > 0 && (
                  <Button
                    size="sm"
                    variant="outline"
                    className="w-full mt-2 text-xs h-8 border-accent text-accent hover:bg-accent/5"
                    onClick={() => {
                      onApplyMeds(result.recommended_medications.map(m => ({ drug: m.drug, dose: m.dose, route: m.route, duration: m.duration, notes: m.notes })));
                      toast.success('Medications applied to medication orders');
                    }}
                  >
                    <Pill className="w-3 h-3 mr-1" /> Apply All to Medications
                  </Button>
                )}
              </div>
            )}

            {/* Global Outcomes */}
            {activeTab === 'global' && (
              <div className="space-y-2">
                <p className="text-xs text-muted-foreground mb-3">Real-world treatment outcomes by country for <strong>{diseaseContext.slice(0, 40)}</strong></p>
                {result.global_outcomes?.map((g, i) => (
                  <div key={i} className="p-3 rounded-lg border bg-muted/10">
                    <div className="flex items-center justify-between mb-1.5">
                      <div className="flex items-center gap-2">
                        <Globe2 className="w-3.5 h-3.5 text-primary" />
                        <span className="text-xs font-bold">{g.country}</span>
                      </div>
                      <Badge variant="outline" className="text-xs text-green-700 bg-green-50 border-green-200">{g.success_rate}</Badge>
                    </div>
                    <p className="text-xs text-foreground mb-1"><span className="font-medium">Approach:</span> {g.approach}</p>
                    <p className="text-xs text-muted-foreground"><span className="font-medium">Key factor:</span> {g.key_factor}</p>
                  </div>
                ))}
              </div>
            )}

            {/* Best Practice Resolution */}
            {activeTab === 'practice' && result.best_practice_resolution && (
              <div className="space-y-3">
                {result.best_practice_resolution.who_guideline && (
                  <div className="p-3 rounded-lg bg-blue-50 border border-blue-200">
                    <p className="text-xs font-bold text-blue-800 mb-1">WHO Guideline</p>
                    <p className="text-xs text-blue-700 leading-relaxed">{result.best_practice_resolution.who_guideline}</p>
                  </div>
                )}
                {result.best_practice_resolution.rwanda_moh_note && (
                  <div className="p-3 rounded-lg bg-green-50 border border-green-200">
                    <p className="text-xs font-bold text-green-800 mb-1">Rwanda MOH Protocol</p>
                    <p className="text-xs text-green-700 leading-relaxed">{result.best_practice_resolution.rwanda_moh_note}</p>
                  </div>
                )}
                {result.best_practice_resolution.monitoring_plan && (
                  <div className="p-3 rounded-lg bg-purple-50 border border-purple-200">
                    <p className="text-xs font-bold text-purple-800 mb-1">Monitoring Plan</p>
                    <p className="text-xs text-purple-700 leading-relaxed">{result.best_practice_resolution.monitoring_plan}</p>
                  </div>
                )}
                {result.best_practice_resolution.red_flags?.length > 0 && (
                  <div className="p-3 rounded-lg bg-red-50 border border-red-200">
                    <div className="flex items-center gap-1.5 mb-2">
                      <AlertTriangle className="w-3.5 h-3.5 text-red-600" />
                      <p className="text-xs font-bold text-red-800">Red Flag Warning Signs</p>
                    </div>
                    <ul className="space-y-1">
                      {result.best_practice_resolution.red_flags.map((flag, i) => (
                        <li key={i} className="text-xs text-red-700 flex items-start gap-1.5">
                          <span className="mt-0.5 shrink-0">•</span> {flag}
                        </li>
                      ))}
                    </ul>
                  </div>
                )}
                {result.best_practice_resolution.patient_education && (
                  <div className="p-3 rounded-lg bg-orange-50 border border-orange-200">
                    <p className="text-xs font-bold text-orange-800 mb-1">Patient Education</p>
                    <p className="text-xs text-orange-700 leading-relaxed">{result.best_practice_resolution.patient_education}</p>
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Empty state */}
      {!result && !loading && (
        <div className="p-5 text-center">
          <BookOpen className="w-8 h-8 text-muted-foreground/40 mx-auto mb-2" />
          <p className="text-xs text-muted-foreground">Add a diagnosis or chief complaint, then click <strong>Run Analysis</strong> to get evidence-based treatment guidelines, lab recommendations, medications, and global outcomes.</p>
        </div>
      )}
    </Card>
  );
}