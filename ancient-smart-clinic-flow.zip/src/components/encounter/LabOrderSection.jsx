import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Plus, Trash2, Search, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

export default function LabOrderSection({ labOrders, onChange }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState([]);

  const searchTest = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Search for laboratory tests matching "${searchQuery}" available in Rwanda hospitals. Return top 5 tests with name, reason, and urgency (Routine/Urgent/STAT).`,
        response_json_schema: {
          type: 'object',
          properties: {
            results: {
              type: 'array',
              items: {
                type: 'object',
                properties: { test: { type: 'string' }, reason: { type: 'string' }, urgency: { type: 'string' } }
              }
            }
          }
        }
      });
      setResults(result.results || []);
    } catch {
      toast.error('Search failed');
    } finally {
      setSearching(false);
    }
  };

  const addTest = (t) => {
    const entry = { test: t.test || searchQuery, reason: t.reason || '', urgency: t.urgency || 'Routine' };
    if (labOrders.some(l => l.test === entry.test)) { toast.info('Already ordered'); return; }
    onChange([...labOrders, entry]);
    setResults([]);
    setSearchQuery('');
  };

  const removeTest = (idx) => onChange(labOrders.filter((_, i) => i !== idx));

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Input
          className="h-8 text-xs flex-1"
          placeholder="Search by test name..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && searchTest()}
        />
        <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={searchTest} disabled={searching}>
          {searching ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
          Search
        </Button>
        <Button size="sm" className="h-8 gap-1 text-xs bg-primary" onClick={() => { if (searchQuery.trim()) addTest({ test: searchQuery }); }}>
          <Plus className="w-3 h-3" /> Add
        </Button>
      </div>

      {results.length > 0 && (
        <div className="border rounded-lg overflow-hidden">
          {results.map((r, i) => (
            <div key={i} className="flex items-center justify-between px-3 py-2 hover:bg-muted/50 cursor-pointer border-b last:border-0"
              onClick={() => addTest(r)}>
              <div>
                <span className="text-xs font-semibold">{r.test}</span>
                <span className="text-xs text-muted-foreground ml-2">· {r.reason}</span>
              </div>
              <span className={`text-xs font-medium ${r.urgency === 'STAT' ? 'text-destructive' : r.urgency === 'Urgent' ? 'text-orange-500' : 'text-muted-foreground'}`}>{r.urgency}</span>
            </div>
          ))}
        </div>
      )}

      {labOrders.length > 0 && (
        <table className="w-full text-xs">
          <thead><tr className="border-b">
            <th className="text-left py-1.5 font-semibold text-muted-foreground">Test</th>
            <th className="py-1.5 font-semibold text-muted-foreground text-right">Actions</th>
          </tr></thead>
          <tbody>
            {labOrders.map((l, i) => (
              <tr key={i} className="border-b last:border-0">
                <td className="py-2">
                  <p className="font-semibold">{l.test}</p>
                  {l.reason && <p className="text-muted-foreground text-xs">{l.reason}</p>}
                </td>
                <td className="py-2 text-right">
                  <button onClick={() => removeTest(i)} className="text-destructive hover:text-destructive/70">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}