import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, Search, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const FREQUENCIES = ['OD', 'BD', 'TDS', 'QID', 'PRN', 'Stat', 'Nocte'];
const ROUTES = ['Oral', 'IV', 'IM', 'SC', 'Topical', 'Inhaled', 'Rectal', 'Sublingual'];
const DURATIONS = ['1 day', '3 days', '5 days', '7 days', '10 days', '14 days', '1 month', '3 months', 'Ongoing'];

export default function MedicationOrderSection({ medications, onChange }) {
  const [searchQuery, setSearchQuery] = useState('');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState([]);

  const searchDrug = async () => {
    if (!searchQuery.trim()) return;
    setSearching(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `Search for medications matching "${searchQuery}" from Rwanda's Essential Medicines List. Return top 5 drugs with name, typical dose, frequency, and route.`,
        response_json_schema: {
          type: 'object',
          properties: {
            results: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  dose: { type: 'string' },
                  frequency: { type: 'string' },
                  route: { type: 'string' },
                  duration: { type: 'string' }
                }
              }
            }
          }
        }
      });
      setResults(result.results || []);
    } catch {
      toast.error('Search failed');
    } finally {
      setSearching(false);
    }
  };

  const addMedication = (med) => {
    onChange([...medications, { name: med.name || searchQuery, dose: med.dose || '', frequency: med.frequency || 'OD', route: med.route || 'Oral', duration: med.duration || '5 days' }]);
    setResults([]);
    setSearchQuery('');
  };

  const removeMedication = (idx) => onChange(medications.filter((_, i) => i !== idx));

  const updateField = (idx, field, value) => {
    const updated = [...medications];
    updated[idx] = { ...updated[idx], [field]: value };
    onChange(updated);
  };

  return (
    <div className="space-y-3">
      <div className="flex gap-2">
        <Input
          className="h-8 text-xs flex-1"
          placeholder="Search by drug name..."
          value={searchQuery}
          onChange={e => setSearchQuery(e.target.value)}
          onKeyDown={e => e.key === 'Enter' && searchDrug()}
        />
        <Button size="sm" className="h-8 gap-1.5 text-xs" onClick={searchDrug} disabled={searching}>
          {searching ? <Loader2 className="w-3 h-3 animate-spin" /> : <Search className="w-3 h-3" />}
          Search
        </Button>
        <Button size="sm" className="h-8 gap-1 text-xs bg-primary" onClick={() => { if (searchQuery.trim()) addMedication({ name: searchQuery }); }}>
          <Plus className="w-3 h-3" /> Add
        </Button>
      </div>

      {results.length > 0 && (
        <div className="border rounded-lg overflow-hidden">
          {results.map((r, i) => (
            <div key={i} className="flex items-center justify-between px-3 py-2 hover:bg-muted/50 cursor-pointer border-b last:border-0"
              onClick={() => addMedication(r)}>
              <div>
                <span className="text-xs font-semibold">{r.name}</span>
                <span className="text-xs text-muted-foreground ml-2">{r.dose} · {r.frequency} · {r.route}</span>
              </div>
              <Plus className="w-3.5 h-3.5 text-primary" />
            </div>
          ))}
        </div>
      )}

      {medications.length > 0 && (
        <table className="w-full text-xs">
          <thead><tr className="border-b">
            {['Drug', 'Dose', 'Frequency', 'Duration', 'Route', ''].map(h => (
              <th key={h} className="text-left py-1.5 font-semibold text-muted-foreground">{h}</th>
            ))}
          </tr></thead>
          <tbody>
            {medications.map((m, i) => (
              <tr key={i} className="border-b last:border-0">
                <td className="py-1.5 font-semibold">{m.name}</td>
                <td className="py-1.5"><Input className="h-7 text-xs w-20" value={m.dose} onChange={e => updateField(i, 'dose', e.target.value)} /></td>
                <td className="py-1.5">
                  <Select value={m.frequency} onValueChange={v => updateField(i, 'frequency', v)}>
                    <SelectTrigger className="h-7 w-20 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>{FREQUENCIES.map(f => <SelectItem key={f} value={f} className="text-xs">{f}</SelectItem>)}</SelectContent>
                  </Select>
                </td>
                <td className="py-1.5">
                  <Select value={m.duration} onValueChange={v => updateField(i, 'duration', v)}>
                    <SelectTrigger className="h-7 w-24 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>{DURATIONS.map(d => <SelectItem key={d} value={d} className="text-xs">{d}</SelectItem>)}</SelectContent>
                  </Select>
                </td>
                <td className="py-1.5">
                  <Select value={m.route} onValueChange={v => updateField(i, 'route', v)}>
                    <SelectTrigger className="h-7 w-24 text-xs"><SelectValue /></SelectTrigger>
                    <SelectContent>{ROUTES.map(r => <SelectItem key={r} value={r} className="text-xs">{r}</SelectItem>)}</SelectContent>
                  </Select>
                </td>
                <td className="py-1.5 text-right">
                  <button onClick={() => removeMedication(i)} className="text-destructive hover:text-destructive/70">
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}