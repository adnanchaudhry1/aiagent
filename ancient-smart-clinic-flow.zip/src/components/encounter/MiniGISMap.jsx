import React from 'react';
import { MapContainer, TileLayer, CircleMarker, Tooltip } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const DISTRICTS = [
  { name: 'Gasabo', lat: -1.87, lng: 30.12, cases: 45 },
  { name: 'Kicukiro', lat: -1.97, lng: 30.10, cases: 38 },
  { name: 'Nyarugenge', lat: -1.95, lng: 30.06, cases: 52 },
  { name: 'Musanze', lat: -1.50, lng: 29.63, cases: 21 },
  { name: 'Huye', lat: -2.60, lng: 29.74, cases: 18 },
  { name: 'Rubavu', lat: -1.68, lng: 29.26, cases: 29 },
  { name: 'Gicumbi', lat: -1.57, lng: 30.09, cases: 14 },
  { name: 'Rwamagana', lat: -1.95, lng: 30.44, cases: 22 },
];

export default function MiniGISMap() {
  return (
    <div className="h-48 rounded-lg overflow-hidden">
      <MapContainer center={[-1.94, 30.06]} zoom={8} style={{ height: '100%', width: '100%' }} zoomControl={false} dragging={false} scrollWheelZoom={false}>
        <TileLayer url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png" attribution="" />
        {DISTRICTS.map(d => (
          <CircleMarker
            key={d.name}
            center={[d.lat, d.lng]}
            radius={Math.max(6, d.cases / 5)}
            fillColor="hsl(0, 72%, 51%)"
            color="white"
            weight={1}
            fillOpacity={0.7}
          >
            <Tooltip>{d.name}: {d.cases} cases</Tooltip>
          </CircleMarker>
        ))}
      </MapContainer>
    </div>
  );
}