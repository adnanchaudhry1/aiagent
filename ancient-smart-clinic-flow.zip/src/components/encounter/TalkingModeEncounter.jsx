import React, { useState, useRef, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import {
  Mic, MicOff, Sparkles, Loader2, CheckCircle2, Save,
  RotateCcw, X, AlertTriangle
} from 'lucide-react';
import { toast } from 'sonner';
import MiniGISMap from './MiniGISMap';

export default function TalkingModeEncounter({ open, onClose, appointment, patient, onEncounterSaved }) {
  const navigate = useNavigate();
  const [phase, setPhase] = useState('recording');
  const [isRecording, setIsRecording] = useState(false);
  const [transcription, setTranscription] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [soap, setSoap] = useState({ subjective: '', objective: '', assessment: '', plan: '' });
  const [aiSuggestions, setAiSuggestions] = useState(null);
  const [saving, setSaving] = useState(false);

  const recognitionRef = useRef(null);
  const shouldRestartRef = useRef(false);
  const transcriptRef = useRef('');
  const queryClient = useQueryClient();

  useEffect(() => {
    if (open) {
      setPhase('recording');
      const base = appointment?.reason ? `Reason: ${appointment.reason}\n` : '';
      setTranscription(base);
      transcriptRef.current = base;
      setSoap({ subjective: '', objective: '', assessment: '', plan: '' });
      setAiSuggestions(null);
      setIsRecording(false);
      shouldRestartRef.current = false;
    } else {
      stopRecording();
    }
  }, [open, appointment]);

  const stopRecording = () => {
    shouldRestartRef.current = false;
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch {}
      recognitionRef.current = null;
    }
    setIsRecording(false);
  };

  const startRecording = () => {
    if (!('webkitSpeechRecognition' in window || 'SpeechRecognition' in window)) {
      toast.error('Speech recognition not supported. Please use Chrome or Edge.');
      return;
    }

    // Request mic permission first
    navigator.mediaDevices?.getUserMedia({ audio: true }).then(() => {
      createAndStartRecognition();
    }).catch(() => {
      // Try anyway without explicit permission
      createAndStartRecognition();
    });
  };

  const createAndStartRecognition = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;

    const startSession = () => {
      const recognition = new SR();
      recognition.continuous = true;
      recognition.interimResults = true;
      recognition.lang = 'en-US';
      recognition.maxAlternatives = 1;

      recognition.onstart = () => {
        setIsRecording(true);
      };

      recognition.onresult = (event) => {
        // Only process new results since last final
        let newFinal = '';
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; i++) {
          if (event.results[i].isFinal) {
            newFinal += event.results[i][0].transcript + ' ';
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        if (newFinal) {
          transcriptRef.current += newFinal;
        }
        setTranscription(transcriptRef.current + interim);
      };

      recognition.onerror = (event) => {
        if (event.error === 'not-allowed') {
          toast.error('Microphone access denied. Please allow mic access in your browser.');
          shouldRestartRef.current = false;
          setIsRecording(false);
          return;
        }
        // For all other errors (no-speech, network, etc.), let onend handle restart
      };

      recognition.onend = () => {
        if (shouldRestartRef.current) {
          // Restart a fresh session — accumulation continues via transcriptRef
          setTimeout(() => {
            if (shouldRestartRef.current) {
              try { startSession(); } catch { setIsRecording(false); }
            }
          }, 100);
        } else {
          setIsRecording(false);
        }
      };

      recognitionRef.current = recognition;
      try {
        recognition.start();
      } catch {
        setIsRecording(false);
      }
    };

    shouldRestartRef.current = true;
    startSession();
  };

  const analyzeAndGenerate = async () => {
    if (!transcription.trim()) { toast.error('No transcription to analyze'); return; }
    stopRecording();
    setAnalyzing(true);
    setPhase('analyzing');
    try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are Murava AI — Rwanda's clinical copilot. Convert this doctor-patient conversation into a complete clinical encounter.

IMPORTANT LANGUAGE NOTE: The conversation may be in Kinyarwanda, English, or mixed. Translate everything to English and structure it properly.

Patient: ${appointment?.patient_name || 'Unknown'}
${patient ? `History: Allergies: ${patient.allergies || 'None'}, Chronic: ${patient.chronic_conditions || 'None'}, Insurance: ${patient.insurance_type || 'N/A'}, Blood: ${patient.blood_type || 'Unknown'}, District: ${patient.district || 'N/A'}` : ''}
Appointment reason: ${appointment?.reason || 'N/A'}

Conversation (may be in Kinyarwanda or English):
"${transcription}"

Generate complete SOAP notes, medications (Rwanda Essential Medicines List), lab tests, ICD-10 codes (Rwanda uses ICD-10 NOT ICD-11), CPT codes, referral recommendation, fraud risk check, and district disease relevance.
For medications, include Rwanda-available drugs from the Essential Medicines List.
Check for billing fraud risks based on diagnosis-procedure alignment.`,
      response_json_schema: {
        type: 'object',
        properties: {
          subjective: { type: 'string' },
          objective: { type: 'string' },
          assessment: { type: 'string' },
          plan: { type: 'string' },
          chief_complaint: { type: 'string' },
          medications: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, dose: { type: 'string' }, frequency: { type: 'string' }, rationale: { type: 'string' } } } },
          lab_tests: { type: 'array', items: { type: 'object', properties: { test: { type: 'string' }, reason: { type: 'string' }, urgency: { type: 'string' } } } },
          icd_codes: { type: 'array', items: { type: 'object', properties: { code: { type: 'string', description: 'ICD-10 code' }, description: { type: 'string' } } } },
          cpt_codes: { type: 'array', items: { type: 'object', properties: { code: { type: 'string' }, description: { type: 'string' } } } },
          fraud_risk: { type: 'string', description: 'None, Low, Medium, High' },
          fraud_notes: { type: 'string' },
          referral_needed: { type: 'boolean' },
          referral_specialty: { type: 'string' },
          referral_reason: { type: 'string' },
          disease_district_relevance: { type: 'string' },
        }
      }
    });
    setSoap({ subjective: result.subjective, objective: result.objective, assessment: result.assessment, plan: result.plan });
    setAiSuggestions(result);
    setPhase('review');
    } catch (e) {
      toast.error('AI analysis failed. Please try again.');
      setPhase('recording');
    } finally {
      setAnalyzing(false);
    }
  };

  const saveEncounter = async (status) => {
    setSaving(true);
    try {
    // Generate unique encounter number
    const encNum = `ENC-${Date.now().toString().slice(-8)}`;
    const data = {
      patient_id: appointment?.patient_id || '',
      patient_name: appointment?.patient_name || '',
      encounter_date: new Date().toISOString(),
      encounter_number: encNum,
      status,
      chief_complaint: aiSuggestions?.chief_complaint || appointment?.reason || '',
      transcription,
      subjective: soap.subjective,
      objective: soap.objective,
      assessment: soap.assessment,
      plan: soap.plan,
      medications: JSON.stringify(aiSuggestions?.medications || []),
      lab_orders: JSON.stringify(aiSuggestions?.lab_tests || []),
      icd_codes: JSON.stringify(aiSuggestions?.icd_codes || []),
      cpt_codes: JSON.stringify(aiSuggestions?.cpt_codes || []),
      ai_suggestions_log: JSON.stringify({ generated_at: new Date().toISOString(), from_appointment: appointment?.id }),
      doctor_actions_log: JSON.stringify({ action: status, at: new Date().toISOString() }),
    };
    const created = await base44.entities.Encounter.create(data);
    // Update appointment status if linked
    if (appointment?.id && status === 'Doctor Approved') {
      await base44.entities.Appointment.update(appointment.id, { status: 'Completed' });
      // Schedule 1-week follow-up call (Phase 7)
      const followUpDate = new Date();
      followUpDate.setDate(followUpDate.getDate() + 7);
      await base44.entities.FollowUpCall.create({
        patient_id: appointment.patient_id || '',
        patient_name: appointment.patient_name || '',
        encounter_id: created.id,
        phone: patient?.phone || '',
        scheduled_date: followUpDate.toISOString(),
        status: 'Scheduled',
      });
    }
    queryClient.invalidateQueries({ queryKey: ['encounters'] });
    queryClient.invalidateQueries({ queryKey: ['patient-encounters', appointment?.patient_id] });
    queryClient.invalidateQueries({ queryKey: ['patient-appointments', appointment?.patient_id] });
    queryClient.invalidateQueries({ queryKey: ['appointments'] });
    setSaving(false);
    toast.success(status === 'Draft' ? 'Encounter saved as draft' : 'Encounter approved & saved to patient chart!');
    onClose();
    if (onEncounterSaved) onEncounterSaved(created);
    // Navigate to patient chart coding tab after approval
    if (status === 'Doctor Approved' && appointment?.patient_id) {
      navigate(`/patients/${appointment.patient_id}?tab=coding`);
    }
    } catch (e) {
      toast.error('Failed to save encounter. Please try again.');
      setSaving(false);
    }
  };

  const handleClose = () => {
    stopRecording();
    onClose();
  };

  return (
    <Dialog open={open} onOpenChange={handleClose}>
      <DialogContent className="max-w-5xl max-h-[95vh] overflow-y-auto p-0">
        {/* Header */}
        <div className="sticky top-0 z-10 bg-background border-b px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
              <Mic className="w-4 h-4 text-primary" />
            </div>
            <div>
              <p className="text-sm font-bold">Talking Mode — {appointment?.patient_name || 'Unknown Patient'}</p>
              <p className="text-xs text-muted-foreground">{appointment?.reason || 'Clinical Encounter'}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant={phase === 'recording' ? 'default' : phase === 'analyzing' ? 'secondary' : 'outline'}>
              {phase === 'recording' ? (isRecording ? '🔴 Recording' : 'Ready') : phase === 'analyzing' ? 'AI Analyzing...' : 'Review'}
            </Badge>
            <Button variant="ghost" size="icon" onClick={handleClose}><X className="w-4 h-4" /></Button>
          </div>
        </div>

        <div className="p-6 space-y-5">
          {/* Recording Panel */}
          {phase === 'recording' && (
            <Card className="p-5 border-0 shadow-sm">
              <div className="flex items-center justify-between mb-3">
                <div>
                  <p className="text-sm font-semibold">Doctor–Patient Conversation</p>
                  <p className="text-xs text-muted-foreground mt-0.5">Click "Start Recording" and speak. The mic will stay on continuously.</p>
                </div>
                <Button
                  variant={isRecording ? 'destructive' : 'default'}
                  size="sm"
                  className="gap-2"
                  onClick={isRecording ? stopRecording : startRecording}
                >
                  {isRecording ? <><MicOff className="w-4 h-4" /> Stop Recording</> : <><Mic className="w-4 h-4" /> Start Recording</>}
                </Button>
              </div>
              {isRecording && (
                <div className="flex items-center gap-2 mb-3 text-sm text-destructive">
                  <span className="w-2 h-2 rounded-full bg-destructive animate-pulse" />
                  Recording — speak clearly. Transcription appears below in real-time.
                </div>
              )}
              <Textarea
                value={transcription}
                onChange={e => { setTranscription(e.target.value); transcriptRef.current = e.target.value; }}
                placeholder="Click 'Start Recording' and speak — or type manually here..."
                className="min-h-[200px] text-sm leading-relaxed"
              />
              <div className="flex gap-2 mt-4">
                <Button
                  className="gap-2"
                  onClick={analyzeAndGenerate}
                  disabled={!transcription.trim()}
                >
                  <Sparkles className="w-4 h-4" /> Generate Full Encounter with AI
                </Button>
                {isRecording && (
                  <p className="text-xs text-muted-foreground self-center">Stop recording first or click Generate directly</p>
                )}
              </div>
            </Card>
          )}

          {/* Analyzing */}
          {phase === 'analyzing' && (
            <div className="flex flex-col items-center justify-center py-16 gap-4">
              <Loader2 className="w-10 h-10 animate-spin text-primary" />
              <p className="text-sm font-semibold">Murava AI is generating the full encounter...</p>
              <p className="text-xs text-muted-foreground">SOAP notes, medications, labs, ICD/CPT codes, referral</p>
            </div>
          )}

          {/* Review Phase — OpenMRS 3-Column Layout */}
           {phase === 'review' && aiSuggestions && (
             <>
               {/* Title */}
               <div className="mb-2">
                 <h3 className="text-sm font-bold text-primary uppercase tracking-wider">Generated Encounter Review</h3>
                 <p className="text-xs text-muted-foreground">Review and edit the AI-generated encounter details below</p>
               </div>

               {/* 3-Column OpenMRS Layout */}
               <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
                 {/* LEFT COLUMN */}
                 <div className="space-y-4">
                   {/* 1. Chief Complaint */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">1</span>
                       Chief Complaint
                     </div>
                     <p className="text-sm">{aiSuggestions.chief_complaint || '—'}</p>
                   </Card>

                   {/* 3. Subjective */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">3</span>
                       Subjective (History)
                     </div>
                     <Textarea value={soap.subjective} onChange={e => setSoap(prev => ({ ...prev, subjective: e.target.value }))} className="min-h-[100px] text-sm" />
                   </Card>

                   {/* 9. Clinical Notes */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">9</span>
                       Notes
                     </div>
                     <p className="text-sm text-muted-foreground">{aiSuggestions.clinical_notes || 'No additional notes'}</p>
                   </Card>
                 </div>

                 {/* MIDDLE COLUMN */}
                 <div className="space-y-4">
                   {/* 4. Objective (Examination) */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">4</span>
                       Objective (Exam)
                     </div>
                     <Textarea value={soap.objective} onChange={e => setSoap(prev => ({ ...prev, objective: e.target.value }))} className="min-h-[100px] text-sm" />
                   </Card>

                   {/* 5. Diagnosis */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">5</span>
                       Diagnosis (ICD-10)
                     </div>
                     <div className="space-y-2">
                       {aiSuggestions.icd_codes?.length > 0 ? (
                         aiSuggestions.icd_codes.map((c, i) => (
                           <div key={i} className="flex items-start gap-2 p-2 bg-muted/40 rounded">
                             <Badge className="font-mono text-xs shrink-0 mt-0.5">{c.code}</Badge>
                             <span className="text-xs">{c.description}</span>
                           </div>
                         ))
                       ) : (
                         <p className="text-xs text-muted-foreground">No diagnoses</p>
                       )}
                     </div>
                   </Card>

                   {/* 10. Disposition */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">10</span>
                       Disposition
                     </div>
                     <p className="text-sm text-muted-foreground">{aiSuggestions.disposition || 'Standard discharge'}</p>
                   </Card>
                 </div>

                 {/* RIGHT COLUMN */}
                 <div className="space-y-4">
                   {/* 2. Assessment */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">2</span>
                       Assessment / Impression
                     </div>
                     <Textarea value={soap.assessment} onChange={e => setSoap(prev => ({ ...prev, assessment: e.target.value }))} className="min-h-[100px] text-sm" />
                   </Card>

                   {/* 6. Orders / Tests */}
                   {aiSuggestions.lab_tests?.length > 0 && (
                     <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                       <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                         <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">6</span>
                         Lab Orders
                       </div>
                       <div className="space-y-2">
                         {aiSuggestions.lab_tests.map((l, i) => (
                           <div key={i} className="p-2 bg-muted/40 rounded">
                             <p className="text-xs font-semibold">{l.test}</p>
                             <p className="text-xs text-muted-foreground">{l.reason}</p>
                           </div>
                         ))}
                       </div>
                     </Card>
                   )}

                   {/* 7. Medications */}
                   {aiSuggestions.medications?.length > 0 && (
                     <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                       <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                         <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">7</span>
                         Medications
                       </div>
                       <div className="space-y-2">
                         {aiSuggestions.medications.map((m, i) => (
                           <div key={i} className="p-2 bg-muted/40 rounded">
                             <p className="text-xs font-semibold">{m.name}</p>
                             <p className="text-xs text-primary">{m.dose} — {m.frequency}</p>
                           </div>
                         ))}
                       </div>
                     </Card>
                   )}

                   {/* 8. Plan */}
                   <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
                     <div className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
                       <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">8</span>
                       Plan of Care
                     </div>
                     <Textarea value={soap.plan} onChange={e => setSoap(prev => ({ ...prev, plan: e.target.value }))} className="min-h-[100px] text-sm" />
                   </Card>
                 </div>
               </div>

               {/* Action Buttons */}
               <Card className="p-4 border-0 shadow-sm bg-accent/5 mt-4">
                 <div className="flex items-center gap-2 mb-3">
                   <AlertTriangle className="w-4 h-4 text-accent" />
                   <p className="text-sm font-semibold text-accent">Physician Review Required</p>
                 </div>
                 <div className="flex gap-2 flex-wrap">
                   <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => saveEncounter('Doctor Approved')} disabled={saving}>
                     {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <CheckCircle2 className="w-4 h-4" />}
                     Approve & Save to Patient Chart
                   </Button>
                   <Button variant="outline" className="gap-2" onClick={() => saveEncounter('Draft')} disabled={saving}>
                     <Save className="w-4 h-4" /> Save as Draft
                   </Button>
                   <Button variant="ghost" className="gap-2" onClick={() => { setPhase('recording'); setAiSuggestions(null); setSoap({ subjective: '', objective: '', assessment: '', plan: '' }); }}>
                     <RotateCcw className="w-4 h-4" /> Rewrite
                   </Button>
                 </div>
               </Card>
             </>
           )}
        </div>
      </DialogContent>
    </Dialog>
  );
}