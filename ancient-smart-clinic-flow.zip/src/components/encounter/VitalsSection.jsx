import React, { useState } from 'react';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Sparkles, Loader2 } from 'lucide-react';
import { base44 } from '@/api/base44Client';
import { toast } from 'sonner';

const VITAL_FIELDS = [
  { key: 'temperature', label: 'Temperature (°C)', placeholder: '37.0', normal: '36.5–37.5' },
  { key: 'blood_pressure', label: 'Blood Pressure (mmHg)', placeholder: '120/80', normal: '<120/80' },
  { key: 'pulse', label: 'Pulse (bpm)', placeholder: '72', normal: '60–100' },
  { key: 'respiratory_rate', label: 'Respiratory Rate (br/min)', placeholder: '16', normal: '12–20' },
  { key: 'weight', label: 'Weight (kg)', placeholder: '70', normal: '' },
  { key: 'height', label: 'Height (cm)', placeholder: '170', normal: '' },
  { key: 'bmi', label: 'BMI (kg/m²)', placeholder: 'Auto', normal: '18.5–24.9', readOnly: true },
  { key: 'oxygen_saturation', label: 'SpO₂ (%)', placeholder: '98', normal: '95–100' },
];

export default function VitalsSection({ vitals, onChange, aiContext }) {
  const [aiInput, setAiInput] = useState('');
  const [loading, setLoading] = useState(false);

  // Auto-calculate BMI
  const handleChange = (key, value) => {
    const updated = { ...vitals, [key]: value };
    if ((key === 'weight' || key === 'height') && updated.weight && updated.height) {
      const w = parseFloat(updated.weight);
      const h = parseFloat(updated.height) / 100;
      if (w > 0 && h > 0) updated.bmi = (w / (h * h)).toFixed(1);
    }
    onChange(updated);
  };

  const runAISuggest = async () => {
    const ctx = aiInput || aiContext || '';
    if (!ctx.trim()) { toast.error('Provide some clinical context first'); return; }
    setLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a clinical AI. Based on this clinical context, suggest expected vital signs values for this patient. Only suggest values that can be reasonably inferred. Context: "${ctx}"`,
        response_json_schema: {
          type: 'object',
          properties: {
            temperature: { type: 'string' },
            blood_pressure: { type: 'string' },
            pulse: { type: 'string' },
            respiratory_rate: { type: 'string' },
            weight: { type: 'string' },
            height: { type: 'string' },
            oxygen_saturation: { type: 'string' },
            notes: { type: 'string' },
          }
        }
      });
      const updated = { ...vitals };
      Object.keys(result).forEach(k => { if (result[k] && k !== 'notes' && k !== 'bmi') updated[k] = result[k]; });
      if (updated.weight && updated.height) {
        const w = parseFloat(updated.weight);
        const h = parseFloat(updated.height) / 100;
        if (w > 0 && h > 0) updated.bmi = (w / (h * h)).toFixed(1);
      }
      onChange(updated);
      if (result.notes) toast.info(result.notes);
      toast.success('AI vitals suggested');
    } catch {
      toast.error('AI suggestion failed');
    } finally {
      setLoading(false);
    }
  };

  const isAbnormal = (key, val) => {
    if (!val) return false;
    const v = parseFloat(val);
    if (key === 'temperature') return v < 36 || v > 38;
    if (key === 'pulse') return v < 60 || v > 100;
    if (key === 'respiratory_rate') return v < 12 || v > 20;
    if (key === 'oxygen_saturation') return v < 95;
    if (key === 'bmi') return v < 18.5 || v > 24.9;
    return false;
  };

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        {VITAL_FIELDS.map(f => (
          <div key={f.key}>
            <Label className="text-xs text-muted-foreground">{f.label}</Label>
            <Input
              className={`mt-1 h-8 text-sm font-medium ${isAbnormal(f.key, vitals[f.key]) ? 'border-destructive text-destructive ring-1 ring-destructive/30' : ''}`}
              placeholder={f.placeholder}
              value={vitals[f.key] || ''}
              readOnly={f.readOnly}
              onChange={e => !f.readOnly && handleChange(f.key, e.target.value)}
            />
            {f.normal && <p className="text-xs text-muted-foreground mt-0.5">Normal: {f.normal}</p>}
            {isAbnormal(f.key, vitals[f.key]) && <p className="text-xs text-destructive font-medium">⚠ Abnormal</p>}
          </div>
        ))}
      </div>
      <div className="flex gap-2 mt-2">
        <Input
          className="h-8 text-xs flex-1"
          placeholder="Describe symptoms for AI vital suggestions (e.g. 'fever for 3 days, headache')..."
          value={aiInput}
          onChange={e => setAiInput(e.target.value)}
        />
        <Button size="sm" className="gap-1.5 h-8 text-xs" onClick={runAISuggest} disabled={loading}>
          {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
          AI Suggest
        </Button>
      </div>
    </div>
  );
}