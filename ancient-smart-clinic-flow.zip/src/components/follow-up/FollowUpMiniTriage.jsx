import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Sparkles, AlertTriangle, TrendingUp, TrendingDown } from 'lucide-react';
import { toast } from 'sonner';

const MINI_QUESTIONS = [
  { key: 'feeling_better', label: 'Is patient feeling better than last contact?' },
  { key: 'feeling_worse', label: 'Is patient feeling worse?' },
  { key: 'new_symptoms', label: 'Any new symptoms since last contact?' },
  { key: 'fever', label: 'Current fever present?' },
  { key: 'breathing_issues', label: 'Any difficulty breathing?' },
  { key: 'hospitalized', label: 'Has patient been hospitalized since last call?' },
];

export default function FollowUpMiniTriage({ call, onEscalate }) {
  const [answers, setAnswers] = useState({});
  const [running, setRunning] = useState(false);
  const [result, setResult] = useState(null);

  const runMiniTriage = async () => {
    setRunning(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda healthcare AI follow-up triage system.
        
Patient: ${call.patient_name}
Follow-up mini-triage answers:
- Feeling better: ${answers.feeling_better || 'unknown'}
- Feeling worse: ${answers.feeling_worse || 'unknown'}
- New symptoms: ${answers.new_symptoms || 'unknown'}
- Fever present: ${answers.fever || 'unknown'}
- Breathing issues: ${answers.breathing_issues || 'unknown'}
- Hospitalized since last call: ${answers.hospitalized || 'unknown'}

Based on these answers, determine if the patient's condition is improving, stable, or worsening.
If worsening, recommend escalation level: CHW → Doctor or Doctor → Hospital.
Keep escalation_needed=false unless there are clear warning signs.`,
        response_json_schema: {
          type: 'object',
          properties: {
            status: { type: 'string' }, // 'improving' | 'stable' | 'worsening'
            escalation_needed: { type: 'boolean' },
            escalation_level: { type: 'string' }, // 'chw_to_doctor' | 'doctor_to_hospital' | 'none'
            reason: { type: 'string' },
            risk_score: { type: 'number' },
          }
        }
      });
      setResult(res);
    } catch {
      toast.error('Mini-triage failed. Please try again.');
    } finally {
      setRunning(false);
    }
  };

  const STATUS_STYLES = {
    improving: 'bg-accent/10 text-accent border-accent/20',
    stable: 'bg-primary/10 text-primary border-primary/20',
    worsening: 'bg-destructive/10 text-destructive border-destructive/20',
  };

  return (
    <div className="space-y-3">
      <p className="text-xs font-bold text-primary uppercase tracking-wider flex items-center gap-1">
        <Sparkles className="w-3 h-3" /> Mini Triage — Follow-Up Assessment
      </p>

      <div className="grid grid-cols-1 gap-2">
        {MINI_QUESTIONS.map(q => (
          <div key={q.key} className="flex items-center justify-between gap-3">
            <Label className="text-xs flex-1">{q.label}</Label>
            <Select value={answers[q.key] || ''} onValueChange={v => setAnswers(a => ({ ...a, [q.key]: v }))}>
              <SelectTrigger className="w-28 h-7 text-xs"><SelectValue placeholder="Select" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="yes">Yes</SelectItem>
                <SelectItem value="no">No</SelectItem>
                <SelectItem value="unknown">Unknown</SelectItem>
              </SelectContent>
            </Select>
          </div>
        ))}
      </div>

      {!result ? (
        <Button size="sm" variant="outline" className="gap-1 text-xs w-full" onClick={runMiniTriage} disabled={running || Object.keys(answers).length < 3}>
          {running ? <><Loader2 className="w-3 h-3 animate-spin" /> Analyzing...</> : <><Sparkles className="w-3 h-3" /> Run Mini Triage</>}
        </Button>
      ) : (
        <div className={`p-3 rounded-lg border text-xs space-y-2 ${STATUS_STYLES[result.status] || 'bg-muted/40'}`}>
          <div className="flex items-center gap-2">
            {result.status === 'worsening' ? <TrendingDown className="w-4 h-4" /> : <TrendingUp className="w-4 h-4" />}
            <span className="font-bold capitalize">{result.status} — Risk Score: {result.risk_score ?? 'N/A'}</span>
          </div>
          <p>{result.reason}</p>

          {result.escalation_needed && (
            <div className="pt-1">
              <div className="flex items-center gap-1 mb-2">
                <AlertTriangle className="w-3.5 h-3.5" />
                <span className="font-semibold">
                  Escalation Required: {result.escalation_level === 'chw_to_doctor' ? 'CHW → Doctor' : 'Doctor → Hospital'}
                </span>
              </div>
              <Button
                size="sm"
                className="gap-1 text-xs bg-destructive hover:bg-destructive/90 text-white"
                onClick={() => onEscalate(result)}
              >
                <AlertTriangle className="w-3 h-3" /> Escalate Now
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}