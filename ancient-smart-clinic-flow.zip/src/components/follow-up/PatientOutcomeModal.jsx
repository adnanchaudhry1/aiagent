import React from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Badge } from '@/components/ui/badge';
import { format } from 'date-fns';
import { User, Calendar, Stethoscope, FlaskConical, Pill, FileText, Phone, CheckCircle2, XCircle, PhoneOff, AlertTriangle } from 'lucide-react';

const RESPONSE_CONFIG = {
  Recovered: { color: 'bg-accent/10 text-accent border-accent/20', icon: CheckCircle2, iconColor: 'text-accent' },
  'Not Recovered': { color: 'bg-destructive/10 text-destructive border-destructive/20', icon: XCircle, iconColor: 'text-destructive' },
  'No Answer': { color: 'bg-muted text-muted-foreground border-border', icon: PhoneOff, iconColor: 'text-muted-foreground' },
};

function Section({ icon: Icon, title, children }) {
  return (
    <div className="border border-border rounded-lg overflow-hidden">
      <div className="flex items-center gap-2 px-4 py-2.5 bg-muted/40 border-b border-border">
        <Icon className="w-4 h-4 text-primary" />
        <p className="text-xs font-semibold text-foreground uppercase tracking-wider">{title}</p>
      </div>
      <div className="px-4 py-3 text-sm text-foreground/80 leading-relaxed">{children}</div>
    </div>
  );
}

function parseJson(str) {
  if (!str) return null;
  try { return typeof str === 'string' ? JSON.parse(str) : str; } catch { return null; }
}

export default function PatientOutcomeModal({ followUp, appointment, onClose }) {
  const open = !!followUp;

  // Fetch patient record
  const { data: patient } = useQuery({
    queryKey: ['patient-outcome-modal', followUp?.patient_id],
    queryFn: () => base44.entities.Patient.filter({ id: followUp.patient_id }).then(r => r[0]),
    enabled: !!followUp?.patient_id,
  });

  // Fetch encounter(s) linked to the appointment
  const { data: encounters = [] } = useQuery({
    queryKey: ['encounter-outcome-modal', followUp?.encounter_id],
    queryFn: () => base44.entities.Encounter.filter({ patient_id: followUp.patient_id }),
    enabled: !!followUp?.patient_id,
  });

  // Use most recent encounter
  const encounter = encounters.sort((a, b) => new Date(b.encounter_date || b.created_date) - new Date(a.encounter_date || a.created_date))[0];

  const cfg = RESPONSE_CONFIG[followUp?.patient_response] || RESPONSE_CONFIG['No Answer'];
  const ResponseIcon = cfg.icon;

  const medications = parseJson(encounter?.medications);
  const labOrders = parseJson(encounter?.lab_orders);
  const icdCodes = parseJson(encounter?.icd_codes);

  // Patient MRN — use patient national_id as MRN, fallback to first 8 chars of patient id
  const mrn = patient?.national_id || (patient?.id ? `MRN-${patient.id.slice(0, 8).toUpperCase()}` : '');

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2 text-base">
            <User className="w-5 h-5 text-primary" />
            Patient Outcome Summary
          </DialogTitle>
        </DialogHeader>

        {/* Patient Header */}
        <div className="flex items-start justify-between p-4 bg-muted/30 rounded-xl border border-border">
          <div className="flex items-start gap-3">
            <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="font-bold text-foreground">{followUp?.patient_name}</p>
              {mrn && <p className="text-xs text-muted-foreground font-mono mt-0.5">{mrn}</p>}
              <div className="flex flex-wrap gap-x-4 gap-y-0.5 mt-1">
                {patient?.gender && <p className="text-xs text-muted-foreground">{patient.gender}</p>}
                {patient?.date_of_birth && (
                  <p className="text-xs text-muted-foreground">
                    DOB: {format(new Date(patient.date_of_birth), 'MMM d, yyyy')}
                  </p>
                )}
                {followUp?.phone && (
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Phone className="w-3 h-3" /> {followUp.phone}
                  </p>
                )}
              </div>
              {patient?.insurance_type && patient.insurance_type !== 'None' && (
                <p className="text-xs text-muted-foreground mt-0.5">
                  Insurance: <span className="font-medium">{patient.insurance_type}</span>
                  {patient.insurance_id ? ` — ${patient.insurance_id}` : ''}
                </p>
              )}
            </div>
          </div>

          {/* Follow-up outcome badge */}
          <div className="flex flex-col items-end gap-1">
            <Badge className={`text-xs flex items-center gap-1 ${cfg.color}`}>
              <ResponseIcon className="w-3 h-3" />
              {followUp?.patient_response}
            </Badge>
            {followUp?.re_escalated && (
              <Badge className="text-xs bg-orange-50 text-orange-600 border-orange-200 flex items-center gap-1">
                <AlertTriangle className="w-3 h-3" /> Re-Escalated
              </Badge>
            )}
            {followUp?.call_date && (
              <p className="text-xs text-muted-foreground mt-1">
                Called: {format(new Date(followUp.call_date), 'MMM d, yyyy')}
              </p>
            )}
          </div>
        </div>

        <div className="space-y-3">

          {/* Visit Info */}
          {appointment && (
            <Section icon={Calendar} title="Last Visit">
              <div className="space-y-1">
                <p><span className="text-muted-foreground">Date:</span> {appointment.appointment_date ? format(new Date(appointment.appointment_date), 'MMM d, yyyy HH:mm') : 'N/A'}</p>
                {appointment.reason && <p><span className="text-muted-foreground">Reason:</span> {appointment.reason}</p>}
                {appointment.doctor_name && <p><span className="text-muted-foreground">Doctor:</span> {appointment.doctor_name}</p>}
                {appointment.appointment_number && <p><span className="text-muted-foreground">Appointment #:</span> <span className="font-mono text-xs">{appointment.appointment_number}</span></p>}
              </div>
            </Section>
          )}

          {/* AI Call Notes from appointment */}
          {appointment?.ai_call_notes && (
            <Section icon={Phone} title="AI Intake Notes">
              <p>{appointment.ai_call_notes}</p>
            </Section>
          )}

          {/* Encounter SOAP */}
          {encounter && (
            <>
              {encounter.chief_complaint && (
                <Section icon={Stethoscope} title="Chief Complaint">
                  <p>{encounter.chief_complaint}</p>
                </Section>
              )}

              {(encounter.subjective || encounter.objective || encounter.assessment || encounter.plan) && (
                <Section icon={FileText} title="Clinical Notes (SOAP)">
                  <div className="space-y-2">
                    {encounter.subjective && (
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase mb-0.5">Subjective</p>
                        <p>{encounter.subjective}</p>
                      </div>
                    )}
                    {encounter.objective && (
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase mb-0.5">Objective</p>
                        <p>{encounter.objective}</p>
                      </div>
                    )}
                    {encounter.assessment && (
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase mb-0.5">Assessment / Diagnosis</p>
                        <p>{encounter.assessment}</p>
                      </div>
                    )}
                    {encounter.plan && (
                      <div>
                        <p className="text-xs font-semibold text-muted-foreground uppercase mb-0.5">Plan</p>
                        <p>{encounter.plan}</p>
                      </div>
                    )}
                  </div>
                </Section>
              )}

              {/* ICD Codes */}
              {icdCodes && (
                <Section icon={FileText} title="Diagnosis Codes (ICD-10)">
                  {Array.isArray(icdCodes) ? (
                    <div className="flex flex-wrap gap-2">
                      {icdCodes.map((c, i) => (
                        <Badge key={i} variant="outline" className="text-xs font-mono">
                          {c.code || c} {c.description ? `— ${c.description}` : ''}
                        </Badge>
                      ))}
                    </div>
                  ) : (
                    <p>{JSON.stringify(icdCodes)}</p>
                  )}
                </Section>
              )}

              {/* Medications */}
              {medications && (
                <Section icon={Pill} title="Medications Prescribed">
                  {Array.isArray(medications) ? (
                    <ul className="space-y-1">
                      {medications.map((m, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-primary mt-0.5">•</span>
                          <span>
                            <span className="font-medium">{m.name || m.medication || m}</span>
                            {m.dosage && <span className="text-muted-foreground"> — {m.dosage}</span>}
                            {m.frequency && <span className="text-muted-foreground"> ({m.frequency})</span>}
                          </span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p>{JSON.stringify(medications)}</p>
                  )}
                </Section>
              )}

              {/* Lab Orders */}
              {labOrders && (
                <Section icon={FlaskConical} title="Lab Orders">
                  {Array.isArray(labOrders) ? (
                    <ul className="space-y-1">
                      {labOrders.map((l, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span className="text-primary mt-0.5">•</span>
                          <span>
                            <span className="font-medium">{l.test || l.name || l}</span>
                            {l.status && <span className="text-muted-foreground"> — {l.status}</span>}
                          </span>
                        </li>
                      ))}
                    </ul>
                  ) : (
                    <p>{JSON.stringify(labOrders)}</p>
                  )}
                </Section>
              )}
            </>
          )}

          {/* AI Follow-Up Notes */}
          {followUp?.ai_notes && (
            <Section icon={FileText} title="Follow-Up Call Notes">
              <p className="italic">{followUp.ai_notes}</p>
            </Section>
          )}

          {/* No encounter fallback */}
          {!encounter && (
            <div className="text-center py-6 text-sm text-muted-foreground">
              No encounter record found for this patient's last visit.
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}