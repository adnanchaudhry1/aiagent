import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Loader2, Sparkles, AlertTriangle, CheckCircle2, XCircle, Clock, TrendingUp, TrendingDown, DollarSign, FileWarning } from 'lucide-react';

export default function RCMAuditModal({ open, onClose, claims }) {
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [auditing, setAuditing] = useState(false);
  const [auditResult, setAuditResult] = useState(null);

  const runAudit = async () => {
    setAuditing(true);

    const filtered = claims.filter(c => {
      if (!dateFrom && !dateTo) return true;
      const d = new Date(c.created_date);
      const from = dateFrom ? new Date(dateFrom) : null;
      const to = dateTo ? new Date(dateTo + 'T23:59:59') : null;
      return (!from || d >= from) && (!to || d <= to);
    });

    const totalCharged = filtered.reduce((s, c) => s + (c.charged_amount || 0), 0);
    const totalAllowed = filtered.reduce((s, c) => s + (c.allowed_amount || 0), 0);
    const approved = filtered.filter(c => c.status === 'Approved');
    const denied = filtered.filter(c => c.status === 'Denied');
    const pending = filtered.filter(c => c.status === 'Submitted' || c.status === 'Under Review');
    const draft = filtered.filter(c => c.status === 'Draft');

    const summary = filtered.map(c => ({
      patient: c.patient_name,
      status: c.status,
      insurance: c.insurance_type,
      charged: c.charged_amount,
      allowed: c.allowed_amount,
      approval_pct: c.approval_probability,
      risk_flags: c.risk_flags,
    }));

    try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a Revenue Cycle Management (RCM) audit AI for Rwanda's healthcare system.

Analyze these insurance claims data and generate a comprehensive RCM audit report:

Date Range: ${dateFrom || 'All time'} to ${dateTo || 'Present'}
Total Claims: ${filtered.length}
Total Charged: ${totalCharged} RWF
Total Allowed: ${totalAllowed} RWF
Approved: ${approved.length}
Denied: ${denied.length}
Pending: ${pending.length}
Draft: ${draft.length}

Claims Summary:
${JSON.stringify(summary, null, 2)}

Rwanda payers context: RSSB (RAMA), MMI, Mutuelle de Santé, Private.

Generate a full RCM audit report including:
1. Overall collection rate and revenue analysis
2. Why claims got rejected (root cause analysis)
3. Discrepancies found (billing vs allowed amounts)
4. Pending claims analysis and risks
5. Paid claims analysis (how much collected vs charged)
6. Key denial reasons by payer
7. Recommendations to improve approval rate
8. Compliance issues specific to Rwanda healthcare billing rules`,
      response_json_schema: {
        type: 'object',
        properties: {
          collection_rate: { type: 'number' },
          total_collected: { type: 'number' },
          total_outstanding: { type: 'number' },
          denial_rate: { type: 'number' },
          denial_root_causes: { type: 'array', items: { type: 'string' } },
          discrepancies: { type: 'array', items: { type: 'object', properties: { issue: { type: 'string' }, impact: { type: 'string' }, severity: { type: 'string' } } } },
          pending_risk_summary: { type: 'string' },
          paid_claims_summary: { type: 'string' },
          denial_reasons_by_payer: { type: 'array', items: { type: 'object', properties: { payer: { type: 'string' }, reason: { type: 'string' }, count: { type: 'number' } } } },
          recommendations: { type: 'array', items: { type: 'string' } },
          compliance_issues: { type: 'array', items: { type: 'string' } },
          overall_health_score: { type: 'number' },
          audit_summary: { type: 'string' },
        }
      }
    });

    setAuditResult({
      ...result,
      stats: { total: filtered.length, approved: approved.length, denied: denied.length, pending: pending.length, draft: draft.length, totalCharged, totalAllowed },
      dateRange: { from: dateFrom, to: dateTo },
    });
    } catch (e) {
      alert('Audit failed. Please try again.');
    } finally {
      setAuditing(false);
    }
  };

  const reset = () => {
    setAuditResult(null);
    setDateFrom('');
    setDateTo('');
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-primary" />
            RCM Practice Audit
          </DialogTitle>
        </DialogHeader>

        {!auditResult ? (
          <div className="space-y-6 mt-2">
            <p className="text-sm text-muted-foreground">
              Select a date range to audit all insurance claims in that period. The AI will analyze denials, discrepancies, pending claims, and payments — full Rwanda RCM report.
            </p>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label className="text-xs">From Date</Label>
                <Input type="date" className="mt-1" value={dateFrom} onChange={e => setDateFrom(e.target.value)} />
              </div>
              <div>
                <Label className="text-xs">To Date</Label>
                <Input type="date" className="mt-1" value={dateTo} onChange={e => setDateTo(e.target.value)} />
              </div>
            </div>
            <p className="text-xs text-muted-foreground">Leave blank to audit all claims</p>
            <div className="flex gap-3">
              <Button onClick={runAudit} disabled={auditing} className="gap-2">
                {auditing ? <><Loader2 className="w-4 h-4 animate-spin" /> Running Audit...</> : <><Sparkles className="w-4 h-4" /> Run Full Audit</>}
              </Button>
              <Button variant="outline" onClick={onClose}>Cancel</Button>
            </div>
          </div>
        ) : (
          <div className="space-y-5 mt-2">
            {/* Header stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-primary/5 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-primary">{auditResult.stats.total}</p>
                <p className="text-xs text-muted-foreground">Total Claims</p>
              </div>
              <div className="bg-accent/5 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-accent">{auditResult.stats.approved}</p>
                <p className="text-xs text-muted-foreground">Approved</p>
              </div>
              <div className="bg-destructive/5 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-destructive">{auditResult.stats.denied}</p>
                <p className="text-xs text-muted-foreground">Denied</p>
              </div>
              <div className="bg-orange-50 rounded-xl p-3 text-center">
                <p className="text-2xl font-bold text-orange-600">{auditResult.stats.pending}</p>
                <p className="text-xs text-muted-foreground">Pending</p>
              </div>
            </div>

            {/* Health Score & Collection Rate */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="p-4 border-0 shadow-sm">
                <p className="text-xs font-semibold text-muted-foreground mb-2">Practice Health Score</p>
                <div className="flex items-center gap-3">
                  <p className="text-3xl font-bold text-primary">{auditResult.overall_health_score}%</p>
                  <Progress value={auditResult.overall_health_score} className="flex-1 h-3" />
                </div>
              </Card>
              <Card className="p-4 border-0 shadow-sm">
                <p className="text-xs font-semibold text-muted-foreground mb-2">Collection Rate</p>
                <div className="flex items-center gap-3">
                  <p className="text-3xl font-bold text-accent">{auditResult.collection_rate}%</p>
                  <div className="text-xs text-muted-foreground">
                    <p>Collected: {(auditResult.total_collected || 0).toLocaleString()} RWF</p>
                    <p>Outstanding: {(auditResult.total_outstanding || 0).toLocaleString()} RWF</p>
                  </div>
                </div>
              </Card>
            </div>

            {/* Audit Summary */}
            <Card className="p-4 border-0 shadow-sm bg-muted/30">
              <p className="text-xs font-semibold mb-2">Audit Summary</p>
              <p className="text-sm text-muted-foreground leading-relaxed">{auditResult.audit_summary}</p>
            </Card>

            {/* Denial Root Causes */}
            {auditResult.denial_root_causes?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <XCircle className="w-4 h-4 text-destructive" />
                  <p className="text-sm font-semibold">Denial Root Causes</p>
                </div>
                <ul className="space-y-1.5">
                  {auditResult.denial_root_causes.map((r, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                      <span className="text-destructive mt-0.5">•</span> {r}
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {/* Discrepancies */}
            {auditResult.discrepancies?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <FileWarning className="w-4 h-4 text-orange-500" />
                  <p className="text-sm font-semibold">Billing Discrepancies</p>
                </div>
                <div className="space-y-2">
                  {auditResult.discrepancies.map((d, i) => (
                    <div key={i} className="flex items-start justify-between gap-3 p-2.5 rounded-lg bg-orange-50">
                      <div>
                        <p className="text-xs font-medium">{d.issue}</p>
                        <p className="text-xs text-muted-foreground">{d.impact}</p>
                      </div>
                      <Badge className={`text-xs shrink-0 ${d.severity === 'High' ? 'bg-destructive/10 text-destructive' : d.severity === 'Medium' ? 'bg-orange-50 text-orange-600 border border-orange-200' : 'bg-muted text-muted-foreground'}`}>
                        {d.severity}
                      </Badge>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Pending & Paid summary */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <Clock className="w-4 h-4 text-primary" />
                  <p className="text-sm font-semibold">Pending Claims</p>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{auditResult.pending_risk_summary}</p>
              </Card>
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-2">
                  <DollarSign className="w-4 h-4 text-accent" />
                  <p className="text-sm font-semibold">Paid Claims</p>
                </div>
                <p className="text-xs text-muted-foreground leading-relaxed">{auditResult.paid_claims_summary}</p>
              </Card>
            </div>

            {/* Denial by Payer */}
            {auditResult.denial_reasons_by_payer?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <p className="text-sm font-semibold mb-3">Denials by Payer</p>
                <div className="space-y-2">
                  {auditResult.denial_reasons_by_payer.map((d, i) => (
                    <div key={i} className="flex items-center justify-between p-2.5 bg-muted/40 rounded-lg">
                      <div>
                        <span className="text-xs font-semibold text-primary">{d.payer}</span>
                        <p className="text-xs text-muted-foreground">{d.reason}</p>
                      </div>
                      <Badge variant="secondary" className="text-xs">{d.count} claims</Badge>
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {/* Recommendations */}
            {auditResult.recommendations?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-accent" />
                  <p className="text-sm font-semibold">Recommendations</p>
                </div>
                <ul className="space-y-1.5">
                  {auditResult.recommendations.map((r, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex items-start gap-2">
                      <CheckCircle2 className="w-3 h-3 text-accent mt-0.5 shrink-0" /> {r}
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {/* Compliance Issues */}
            {auditResult.compliance_issues?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm border-destructive/20">
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-4 h-4 text-destructive" />
                  <p className="text-sm font-semibold text-destructive">Compliance Issues</p>
                </div>
                <ul className="space-y-1.5">
                  {auditResult.compliance_issues.map((c, i) => (
                    <li key={i} className="text-xs text-destructive flex items-start gap-2">
                      <span className="mt-0.5">•</span> {c}
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            <div className="flex gap-3">
              <Button onClick={reset} variant="outline">Run Another Audit</Button>
              <Button onClick={onClose}>Close</Button>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
}