import React, { useState } from 'react';
import { Outlet, useNavigate, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar';
import MuravaAI from '@/components/ai/MuravaAI';
import { ArrowLeft } from 'lucide-react';

// Pages where back button should NOT show (root-level pages)
const ROOT_PAGES = ['/', '/patients', '/appointments', '/coding', '/insurance', '/pharmacy', '/referrals', '/gis-map', '/audit', '/lab', '/eligibility', '/reports', '/daily', '/encounter'];

export default function AppLayout() {
  const navigate = useNavigate();
  const location = useLocation();
  const [collapsed, setCollapsed] = useState(false);

  const showBack = !ROOT_PAGES.includes(location.pathname);

  return (
    <div className="flex min-h-screen bg-background">
      <Sidebar collapsed={collapsed} onCollapse={setCollapsed} />
      <main
        className="flex-1 max-w-full overflow-x-hidden transition-all duration-300"
        style={{ marginLeft: collapsed ? '68px' : '240px' }}
      >
        {/* Top bar with back button */}
        {showBack && (
          <div className="sticky top-0 z-40 bg-background/95 backdrop-blur border-b border-border px-6 py-2 flex items-center gap-2">
            <button
              onClick={() => navigate(-1)}
              className="flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground transition-colors group"
            >
              <ArrowLeft className="w-4 h-4 group-hover:-translate-x-0.5 transition-transform" />
              Back
            </button>
          </div>
        )}
        <div className="p-6">
          <Outlet />
        </div>
      </main>
      <MuravaAI />
    </div>
  );
}