import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import {
  LayoutDashboard, Users, Calendar, FileCode2,
  ShieldCheck, Pill, GitBranch, Map, Activity, ChevronLeft,
  ChevronRight, LogOut, FlaskConical, BarChart3, CheckSquare, ClipboardList, Stethoscope,
  Phone, UserCheck, PhoneCall, ClipboardCheck
} from 'lucide-react';
import { base44 } from '@/api/base44Client';

const navItems = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: ClipboardList, label: 'Daily Overview', path: '/daily' },
  { icon: Phone, label: 'AI Phone Intake', path: '/phone-intake' },
  { icon: UserCheck, label: 'Community Workers', path: '/community-worker' },
  { icon: Users, label: 'Patients', path: '/patients' },
  { icon: Calendar, label: 'Appointments', path: '/appointments' },
  { icon: Stethoscope, label: 'New Encounter', path: '/encounter' },
  { icon: CheckSquare, label: 'Eligibility Check', path: '/eligibility' },
  { icon: FileCode2, label: 'Medical Coding', path: '/coding' },
  { icon: Pill, label: 'Pharmacy Search', path: '/pharmacy' },
  { icon: FlaskConical, label: 'Lab Search', path: '/lab' },
  { icon: GitBranch, label: 'Referrals', path: '/referrals' },
  { icon: Map, label: 'GIS Disease Map', path: '/gis-map' },
  { icon: ShieldCheck, label: 'Insurance Claims', path: '/insurance' },
  { icon: PhoneCall, label: 'Follow-Up Calls', path: '/follow-up' },
  { icon: ClipboardCheck, label: 'Follow-Up History', path: '/follow-up-history' },
  { icon: BarChart3, label: 'AI Reports', path: '/reports' },
  { icon: Activity, label: 'Audit Log', path: '/audit' },
];

export default function Sidebar({ collapsed = false, onCollapse }) {
  const location = useLocation();

  return (
    <aside className={`fixed left-0 top-0 h-screen bg-sidebar text-sidebar-foreground flex flex-col z-50 transition-all duration-300 ${collapsed ? 'w-[68px]' : 'w-[240px]'}`}>
      <div className="flex items-center gap-3 px-3 h-16 border-b border-sidebar-border">
        <img
          src="https://media.base44.com/images/public/69efb42e89b4b90fee6e0d06/810784b59_MuravalogoCOLOR.png"
          alt="Murava AI"
          className="h-8 w-8 object-contain flex-shrink-0 brightness-0 invert"
        />
        {!collapsed && (
          <div className="overflow-hidden">
            <h1 className="text-sm font-bold tracking-tight text-sidebar-foreground whitespace-nowrap">Murava AI</h1>
          </div>
        )}
      </div>

      <nav className="flex-1 py-3 px-2 space-y-0.5 overflow-y-auto">
        {navItems.map((item) => {
          const isActive = location.pathname === item.path;
          return (
            <Link
              key={item.path}
              to={item.path}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all duration-200 group
                ${isActive
                  ? 'bg-sidebar-primary text-sidebar-primary-foreground shadow-lg shadow-sidebar-primary/20'
                  : 'text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground'
                }`}
            >
              <item.icon className={`w-[18px] h-[18px] flex-shrink-0 ${isActive ? '' : 'group-hover:scale-110 transition-transform'}`} />
              {!collapsed && <span className="whitespace-nowrap">{item.label}</span>}
            </Link>
          );
        })}
      </nav>

      <div className="px-2 pb-3 space-y-1">
        <button
          onClick={() => onCollapse && onCollapse(!collapsed)}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-sidebar-foreground/50 hover:bg-sidebar-accent hover:text-sidebar-foreground w-full transition-colors"
        >
          {collapsed ? <ChevronRight className="w-[18px] h-[18px]" /> : <ChevronLeft className="w-[18px] h-[18px]" />}
          {!collapsed && <span>Collapse</span>}
        </button>
        <button
          onClick={() => base44.auth.logout()}
          className="flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm text-sidebar-foreground/50 hover:bg-destructive/20 hover:text-destructive w-full transition-colors"
        >
          <LogOut className="w-[18px] h-[18px]" />
          {!collapsed && <span>Logout</span>}
        </button>
      </div>
    </aside>
  );
}