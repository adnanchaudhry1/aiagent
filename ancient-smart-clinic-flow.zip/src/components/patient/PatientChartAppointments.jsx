import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Calendar, Mic, Clock, CheckCircle2, Stethoscope, Lock, ArrowRight, Activity, Pill, FlaskConical, GitBranch, Map, ShieldCheck, Phone } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const statusColors = {
  'Scheduled': 'bg-primary/10 text-primary',
  'Checked In': 'bg-accent/10 text-accent',
  'In Progress': 'bg-orange-50 text-orange-600',
  'Completed': 'bg-green-50 text-green-700',
  'Cancelled': 'bg-destructive/10 text-destructive',
};

const WORKFLOW_STEPS = [
  { key: 'encounter', label: 'Encounter', icon: Stethoscope, route: '/encounter' },
  { key: 'coding', label: 'Medical Coding', icon: Activity, route: '/coding' },
  { key: 'pharmacy', label: 'Pharmacy', icon: Pill, route: '/pharmacy' },
  { key: 'lab', label: 'Lab', icon: FlaskConical, route: '/lab' },
  { key: 'referrals', label: 'Referrals', icon: GitBranch, route: '/referrals' },
  { key: 'gis-map', label: 'GIS Map', icon: Map, route: '/gis-map' },
  { key: 'insurance', label: 'Claims', icon: ShieldCheck, route: '/insurance' },
  { key: 'follow-up', label: 'Follow-Up', icon: Phone, route: '/follow-up' },
];

export default function PatientChartAppointments({ appointments, patient, onStartAppointment }) {
  const queryClient = useQueryClient();
  const navigate = useNavigate();
  const [showWorkflow, setShowWorkflow] = useState(null); // appointment id

  // Fetch encounters to check if an encounter exists for an appointment
  const { data: encounters = [] } = useQuery({
    queryKey: ['patient-encounters', patient?.id],
    queryFn: () => base44.entities.Encounter.filter({ patient_id: patient?.id }, '-created_date'),
    enabled: !!patient?.id,
  });

  const checkIn = async (apt) => {
    await base44.entities.Appointment.update(apt.id, { status: 'Checked In' });
    queryClient.invalidateQueries({ queryKey: ['patient-appointments', patient?.id] });
    queryClient.invalidateQueries({ queryKey: ['appointments'] });
    toast.success('Patient checked in');
  };

  const getLinkedEncounter = (apt) => {
    // Find encounter linked to this appointment
    if (apt.encounter_id) return encounters.find(e => e.id === apt.encounter_id);
    // Also try matching by appointment_id in doctor_actions_log
    return encounters.find(e => {
      try {
        const log = JSON.parse(e.doctor_actions_log || '{}');
        return log.appointment_id === apt.id;
      } catch { return false; }
    });
  };

  const startDoctorWorkflow = (apt, step) => {
    const enc = getLinkedEncounter(apt);
    const params = new URLSearchParams();
    params.set('patientId', patient?.id || '');
    params.set('patientName', encodeURIComponent(patient?.full_name || ''));
    params.set('appointmentId', apt.id);
    if (apt.appointment_number) params.set('appointmentNumber', apt.appointment_number);
    if (enc?.id) params.set('encounterId', enc.id);
    params.set('reason', encodeURIComponent(apt.reason || ''));

    const stepDef = WORKFLOW_STEPS.find(s => s.key === step);
    if (stepDef) navigate(`${stepDef.route}?${params.toString()}`);
    setShowWorkflow(null);
  };

  // Full Workflow: go directly to Encounter step (no dialog)
  const startFullWorkflow = (apt) => {
    const enc = getLinkedEncounter(apt);
    const params = new URLSearchParams();
    params.set('patientId', patient?.id || '');
    params.set('patientName', encodeURIComponent(patient?.full_name || ''));
    params.set('appointmentId', apt.id);
    if (apt.appointment_number) params.set('appointmentNumber', apt.appointment_number);
    if (enc?.id) params.set('encounterId', enc.id);
    params.set('reason', encodeURIComponent(apt.reason || ''));
    params.set('workflow', 'true');
    navigate(`/encounter?${params.toString()}`);
  };

  if (appointments.length === 0) {
    return <Card className="p-10 border-0 shadow-sm text-center text-muted-foreground">No appointments yet for this patient.</Card>;
  }

  return (
    <div className="space-y-3">
      {appointments.map(apt => {
        const isLocked = apt.is_locked || apt.status === 'Completed';
        const linkedEncounter = getLinkedEncounter(apt);

        return (
          <Card key={apt.id} className={`p-4 border-0 shadow-sm ${isLocked ? 'opacity-80' : ''}`}>
            <div className="flex items-start justify-between gap-3">
              <div className="flex items-center gap-3 flex-1">
                <div className={`w-9 h-9 rounded-xl flex items-center justify-center shrink-0 ${isLocked ? 'bg-muted' : 'bg-accent/10'}`}>
                  {isLocked ? <Lock className="w-4 h-4 text-muted-foreground" /> : <Calendar className="w-4 h-4 text-accent" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap">
                    <p className="text-sm font-semibold">{apt.reason || 'General Visit'}</p>
                    {apt.appointment_number && <span className="text-xs font-mono text-muted-foreground">#{apt.appointment_number}</span>}
                  </div>
                  <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                    <Clock className="w-3 h-3" />
                    {apt.appointment_date ? format(new Date(apt.appointment_date), 'MMM d, yyyy HH:mm') : 'No date'}
                  </p>
                  {apt.doctor_name && <p className="text-xs text-muted-foreground mt-0.5">Dr. {apt.doctor_name}</p>}

                  {/* LOCKED AI Call Notes — visible but not editable */}
                  {apt.ai_call_notes && (
                    <div className="mt-2 p-2 bg-primary/5 rounded border border-primary/20 flex items-start gap-1.5">
                      <Lock className="w-3 h-3 text-primary shrink-0 mt-0.5" />
                      <p className="text-xs text-foreground/70 line-clamp-2">{apt.ai_call_notes}</p>
                    </div>
                  )}

                  {apt.ai_summary && (
                    <div className="mt-2 p-2 bg-muted/40 rounded text-xs text-muted-foreground line-clamp-2">{apt.ai_summary}</div>
                  )}

                  {linkedEncounter && (
                    <p className="text-xs text-accent mt-1">Linked Encounter: {linkedEncounter.encounter_number || linkedEncounter.id?.slice(-8)}</p>
                  )}
                </div>
              </div>

              <div className="flex flex-col items-end gap-2 shrink-0">
                <Badge className={`text-xs ${statusColors[apt.status] || ''}`}>{apt.status}</Badge>

                {isLocked ? (
                  <Badge className="text-xs bg-green-50 text-green-700"><Lock className="w-3 h-3 mr-1" />Completed & Locked</Badge>
                ) : (
                  <>
                    {apt.status === 'Scheduled' && (
                      <Button size="sm" variant="outline" className="text-xs h-7 gap-1" onClick={() => checkIn(apt)}>
                        <CheckCircle2 className="w-3 h-3" /> Check In
                      </Button>
                    )}
                    {(apt.status === 'Scheduled' || apt.status === 'Checked In' || apt.status === 'In Progress') && (
                      <>
                        <Button size="sm" className="text-xs h-7 gap-1 bg-accent hover:bg-accent/90 text-white" onClick={() => onStartAppointment(apt)}>
                          <Mic className="w-3 h-3" /> AI Encounter
                        </Button>
                        <Button size="sm" variant="outline" className="text-xs h-7 gap-1" onClick={() => startFullWorkflow(apt)}>
                          <Stethoscope className="w-3 h-3" /> Full Workflow
                        </Button>
                      </>
                    )}
                  </>
                )}
              </div>
            </div>

            {/* Workflow step selector dialog */}
            {showWorkflow === apt.id && (
              <Dialog open={true} onOpenChange={() => setShowWorkflow(null)}>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle className="flex items-center gap-2 text-sm">
                      <Stethoscope className="w-4 h-4" />
                      Doctor Workflow — {apt.appointment_number || apt.reason || 'Appointment'}
                    </DialogTitle>
                  </DialogHeader>
                  <p className="text-xs text-muted-foreground mb-3">All steps are linked to this appointment. Select the step to continue:</p>
                  <div className="space-y-2">
                    {WORKFLOW_STEPS.map((step, idx) => {
                      const Icon = step.icon;
                      const hasEncounter = !!linkedEncounter;
                      const isEncounterStep = step.key === 'encounter';
                      const needsEncounter = !isEncounterStep && !hasEncounter;
                      return (
                        <button
                          key={step.key}
                          onClick={() => !needsEncounter && startDoctorWorkflow(apt, step.key)}
                          disabled={needsEncounter}
                          className={`w-full flex items-center gap-3 p-3 rounded-lg border text-left transition-all ${
                            needsEncounter
                              ? 'opacity-40 cursor-not-allowed border-border bg-muted/30'
                              : 'hover:bg-primary/5 hover:border-primary/30 border-border'
                          }`}
                        >
                          <div className="w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                            <span className="text-xs font-bold text-primary">{idx + 1}</span>
                          </div>
                          <Icon className="w-4 h-4 text-muted-foreground shrink-0" />
                          <span className="text-sm font-medium">{step.label}</span>
                          {needsEncounter && <span className="text-xs text-muted-foreground ml-auto">Start encounter first</span>}
                          {!needsEncounter && <ArrowRight className="w-3.5 h-3.5 text-muted-foreground ml-auto" />}
                        </button>
                      );
                    })}
                  </div>
                </DialogContent>
              </Dialog>
            )}
          </Card>
        );
      })}
    </div>
  );
}