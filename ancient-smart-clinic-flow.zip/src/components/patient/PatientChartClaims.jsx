import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { ShieldCheck, CheckCircle2, XCircle, Clock, AlertTriangle, ChevronDown, ChevronUp, Sparkles, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { toast } from 'sonner';

const statusColors = {
  Draft: 'bg-muted text-muted-foreground',
  Submitted: 'bg-primary/10 text-primary',
  Approved: 'bg-accent/10 text-accent',
  Denied: 'bg-destructive/10 text-destructive',
  'Under Review': 'bg-orange-50 text-orange-600',
  Paid: 'bg-green-50 text-green-700',
};

const statusIcons = {
  Approved: CheckCircle2,
  Paid: CheckCircle2,
  Denied: XCircle,
  'Under Review': Clock,
  Submitted: Clock,
  Draft: ShieldCheck,
};

export default function PatientChartClaims({ claims, patient, encounters = [] }) {
  const [expanded, setExpanded] = useState({});
  const [simulating, setSimulating] = useState(null);
  const queryClient = useQueryClient();

  const toggle = (id) => setExpanded(prev => ({ ...prev, [id]: !prev[id] }));

  const simulateInsurerResponse = async (claim) => {
    setSimulating(claim.id);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are the ${claim.insurance_type} (Rwanda insurance) system responding to a submitted claim.

Claim Number: ${claim.claim_number || claim.id}
Patient: ${claim.patient_name}
Insurance: ${claim.insurance_type}
Charged Amount: ${claim.charged_amount || 0} RWF
ICD-10 Codes: ${claim.icd_codes || 'N/A'}
CPT Codes: ${claim.cpt_codes || 'N/A'}

Generate a realistic insurance response as if from Rwanda's ${claim.insurance_type} portal. Include approval/denial decision, reason, approved amount, and next steps per Rwanda's health insurance system.`,
        response_json_schema: {
          type: 'object',
          properties: {
            decision: { type: 'string', description: 'Approved, Denied, or Under Review' },
            approved_amount: { type: 'number' },
            reason: { type: 'string' },
            remarks: { type: 'string' },
            next_steps: { type: 'string' },
            reference_number: { type: 'string' },
          }
        }
      });
      const newStatus = result.decision === 'Approved' ? 'Approved' : result.decision === 'Denied' ? 'Denied' : 'Under Review';
      await base44.entities.InsuranceClaim.update(claim.id, {
        status: newStatus,
        insurer_response: JSON.stringify(result),
        response_date: new Date().toISOString(),
      });
      // Lock the encounter if approved
      if (newStatus === 'Approved' && claim.encounter_id) {
        await base44.entities.Encounter.update(claim.encounter_id, { is_locked: true, status: 'Finalized' });
      }
      queryClient.invalidateQueries({ queryKey: ['patient-claims', patient.id] });
      queryClient.invalidateQueries({ queryKey: ['patient-encounters', patient.id] });
      toast.success(`Insurer response received: ${result.decision}`);
    } catch (e) {
      toast.error('Failed to get insurer response');
    } finally {
      setSimulating(null);
    }
  };

  const submitClaim = async (claim) => {
    const claimNum = `CLM-${Date.now().toString().slice(-8)}`;
    await base44.entities.InsuranceClaim.update(claim.id, {
      status: 'Submitted',
      claim_number: claim.claim_number || claimNum,
      submitted_date: new Date().toISOString(),
    });
    // Lock encounter
    if (claim.encounter_id) {
      await base44.entities.Encounter.update(claim.encounter_id, { is_locked: true, status: 'Finalized' });
    }
    queryClient.invalidateQueries({ queryKey: ['patient-claims', patient.id] });
    queryClient.invalidateQueries({ queryKey: ['patient-encounters', patient.id] });
    toast.success('Claim submitted. Encounter is now locked.');
  };

  if (claims.length === 0) {
    return <Card className="p-10 border-0 shadow-sm text-center text-muted-foreground">No insurance claims yet.</Card>;
  }

  return (
    <div className="space-y-3">
      {claims.map(c => {
        const Icon = statusIcons[c.status] || ShieldCheck;
        const isExpanded = expanded[c.id];
        let insurerResponse = null;
        try { insurerResponse = c.insurer_response ? JSON.parse(c.insurer_response) : null; } catch {}

        return (
          <Card key={c.id} className="border-0 shadow-sm overflow-hidden">
            <div className="p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="flex items-center gap-3">
                  <div className={`w-9 h-9 rounded-lg flex items-center justify-center shrink-0 ${c.status === 'Approved' || c.status === 'Paid' ? 'bg-accent/10' : c.status === 'Denied' ? 'bg-destructive/10' : 'bg-primary/10'}`}>
                    <Icon className={`w-4 h-4 ${c.status === 'Approved' || c.status === 'Paid' ? 'text-accent' : c.status === 'Denied' ? 'text-destructive' : 'text-primary'}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold">{c.insurance_type}</p>
                      {c.claim_number && <Badge variant="outline" className="text-xs font-mono">{c.claim_number}</Badge>}
                    </div>
                    {c.encounter_number && <p className="text-xs text-muted-foreground">Encounter: {c.encounter_number}</p>}
                    <p className="text-xs text-muted-foreground">
                      {c.charged_amount ? `${Number(c.charged_amount).toLocaleString()} RWF charged` : ''}
                      {c.created_date ? ` • ${format(new Date(c.created_date), 'MMM d, yyyy')}` : ''}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <Badge className={`text-xs ${statusColors[c.status] || ''}`}>{c.status}</Badge>
                  {c.approval_probability > 0 && (
                    <div className="flex items-center gap-1">
                      <Progress value={c.approval_probability} className="w-12 h-1.5" />
                      <span className="text-xs">{c.approval_probability}%</span>
                    </div>
                  )}
                  <Button variant="ghost" size="icon" className="w-7 h-7" onClick={() => toggle(c.id)}>
                    {isExpanded ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="flex gap-2 mt-3">
                {c.status === 'Draft' && (
                  <Button size="sm" variant="outline" className="text-xs h-7 gap-1" onClick={() => submitClaim(c)}>
                    <ShieldCheck className="w-3 h-3" /> Submit to {c.insurance_type}
                  </Button>
                )}
                {c.status === 'Submitted' && (
                  <Button size="sm" className="text-xs h-7 gap-1 bg-primary/10 text-primary hover:bg-primary hover:text-white"
                    onClick={() => simulateInsurerResponse(c)} disabled={simulating === c.id}>
                    {simulating === c.id ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                    Get Insurer Response
                  </Button>
                )}
              </div>
            </div>

            {/* Expanded details */}
            {isExpanded && (
              <div className="border-t bg-muted/30 p-4 space-y-3">
                {insurerResponse && (
                  <div className={`p-3 rounded-lg ${insurerResponse.decision === 'Approved' ? 'bg-accent/10' : insurerResponse.decision === 'Denied' ? 'bg-destructive/10' : 'bg-orange-50'}`}>
                    <div className="flex items-center gap-2 mb-2">
                      {insurerResponse.decision === 'Approved'
                        ? <CheckCircle2 className="w-4 h-4 text-accent" />
                        : insurerResponse.decision === 'Denied'
                        ? <XCircle className="w-4 h-4 text-destructive" />
                        : <Clock className="w-4 h-4 text-orange-500" />}
                      <p className="text-xs font-semibold">Insurer Decision: {insurerResponse.decision}</p>
                      {insurerResponse.reference_number && (
                        <Badge variant="outline" className="text-xs ml-auto">{insurerResponse.reference_number}</Badge>
                      )}
                    </div>
                    {insurerResponse.approved_amount > 0 && (
                      <p className="text-xs">Approved Amount: <span className="font-semibold">{Number(insurerResponse.approved_amount).toLocaleString()} RWF</span></p>
                    )}
                    {insurerResponse.reason && <p className="text-xs text-muted-foreground mt-1">Reason: {insurerResponse.reason}</p>}
                    {insurerResponse.remarks && <p className="text-xs text-muted-foreground mt-0.5">Remarks: {insurerResponse.remarks}</p>}
                    {insurerResponse.next_steps && (
                      <div className="mt-2 p-2 bg-white/50 rounded text-xs">
                        <span className="font-semibold">Next Steps: </span>{insurerResponse.next_steps}
                      </div>
                    )}
                  </div>
                )}
                {c.risk_flags && c.risk_flags !== '[]' && (
                  <div className="flex items-center gap-2">
                    <AlertTriangle className="w-3.5 h-3.5 text-orange-500" />
                    <p className="text-xs text-orange-600">Risk Flags: {typeof c.risk_flags === 'string' ? c.risk_flags : JSON.stringify(c.risk_flags)}</p>
                  </div>
                )}
                {c.response_date && (
                  <p className="text-xs text-muted-foreground">Response Date: {format(new Date(c.response_date), 'MMM d, yyyy HH:mm')}</p>
                )}
              </div>
            )}
          </Card>
        );
      })}
    </div>
  );
}