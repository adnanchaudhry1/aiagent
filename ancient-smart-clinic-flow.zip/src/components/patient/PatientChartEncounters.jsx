import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Stethoscope, Lock, FileText, Edit, ShieldCheck } from 'lucide-react';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

const statusColors = {
  'Draft': 'bg-muted text-muted-foreground',
  'In Progress': 'bg-orange-50 text-orange-600',
  'AI Review': 'bg-primary/10 text-primary',
  'Doctor Approved': 'bg-accent/10 text-accent',
  'Finalized': 'bg-green-50 text-green-700',
};

export default function PatientChartEncounters({ encounters, patient, claims = [] }) {
  const navigate = useNavigate();

  if (encounters.length === 0) {
    return <Card className="p-10 border-0 shadow-sm text-center text-muted-foreground">No encounters recorded yet. Start an appointment to create an encounter.</Card>;
  }

  return (
    <div className="space-y-3">
      {encounters.map(enc => {
        let medications = [];
        let labs = [];
        let icdCodes = [];
        try { medications = JSON.parse(enc.medications || '[]'); } catch {}
        try { labs = JSON.parse(enc.lab_orders || '[]'); } catch {}
        try { icdCodes = JSON.parse(enc.icd_codes || '[]'); } catch {}

        const linkedClaim = claims.find(c => c.encounter_id === enc.id);
        const isLocked = enc.is_locked || (linkedClaim && linkedClaim.status !== 'Draft');

        return (
          <Card key={enc.id} className={`border-0 shadow-sm overflow-hidden ${isLocked ? 'ring-1 ring-orange-200' : ''}`}>
            <div className="p-5">
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-primary/10 flex items-center justify-center">
                    <Stethoscope className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold">{enc.chief_complaint || 'Clinical Encounter'}</p>
                      {enc.encounter_number && (
                        <Badge variant="outline" className="text-xs font-mono">{enc.encounter_number}</Badge>
                      )}
                      {isLocked && (
                        <Badge className="text-xs bg-orange-50 text-orange-600 gap-1">
                          <Lock className="w-3 h-3" />Locked
                        </Badge>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {enc.encounter_date ? format(new Date(enc.encounter_date), 'MMM d, yyyy HH:mm') : 'No date'}
                    </p>
                    {linkedClaim && (
                      <p className="text-xs text-primary mt-0.5">
                        Claim: {linkedClaim.claim_number || 'Draft'} — {linkedClaim.status}
                      </p>
                    )}
                  </div>
                </div>
                <Badge className={`text-xs ${statusColors[enc.status] || 'bg-muted text-muted-foreground'}`}>{enc.status}</Badge>
              </div>

              {/* SOAP Summary */}
              <div className="grid grid-cols-2 gap-3 mb-3">
                {enc.subjective && (
                  <div className="bg-muted/40 rounded-lg p-3">
                    <p className="text-xs font-semibold text-muted-foreground mb-1">Subjective</p>
                    <p className="text-xs line-clamp-2">{enc.subjective}</p>
                  </div>
                )}
                {enc.assessment && (
                  <div className="bg-muted/40 rounded-lg p-3">
                    <p className="text-xs font-semibold text-muted-foreground mb-1">Assessment / Diagnosis</p>
                    <p className="text-xs line-clamp-2">{enc.assessment}</p>
                  </div>
                )}
                {enc.plan && (
                  <div className="bg-muted/40 rounded-lg p-3 col-span-2">
                    <p className="text-xs font-semibold text-muted-foreground mb-1">Plan of Care</p>
                    <p className="text-xs line-clamp-2">{enc.plan}</p>
                  </div>
                )}
              </div>

              <div className="flex gap-2 flex-wrap items-center">
                {medications.length > 0 && (
                  <Badge variant="secondary" className="text-xs">{medications.length} medication{medications.length > 1 ? 's' : ''}</Badge>
                )}
                {labs.length > 0 && (
                  <Badge variant="secondary" className="text-xs">{labs.length} lab order{labs.length > 1 ? 's' : ''}</Badge>
                )}
                {icdCodes.length > 0 && (
                  <Badge variant="outline" className="text-xs font-mono">{icdCodes.length} ICD-10 code{icdCodes.length > 1 ? 's' : ''}</Badge>
                )}
                {isLocked && (
                  <Badge className="text-xs bg-orange-50 text-orange-700">Claim Submitted — No Edits Allowed</Badge>
                )}
                <div className="ml-auto flex gap-1.5">
                  {!isLocked && (
                    <Button size="sm" variant="outline" className="text-xs h-7 gap-1"
                      onClick={() => navigate(`/encounter?encounterId=${enc.id}`)}>
                      <Edit className="w-3 h-3" /> Edit Encounter
                    </Button>
                  )}
                  <Button size="sm" variant="outline" className="text-xs h-7 gap-1"
                    onClick={() => navigate(`/coding?encounterId=${enc.id}`)}>
                    <ShieldCheck className="w-3 h-3" /> Code & Claim
                  </Button>
                </div>
              </div>
            </div>
          </Card>
        );
      })}
    </div>
  );
}