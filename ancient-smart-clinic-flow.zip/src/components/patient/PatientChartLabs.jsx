import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { FlaskConical, Sparkles, Loader2, AlertTriangle, CheckCircle2, GitBranch, Pill } from 'lucide-react';
import { format } from 'date-fns';

export default function PatientChartLabs({ encounters, patient }) {
  const [analyzing, setAnalyzing] = useState(null);
  const [suggestions, setSuggestions] = useState({});

  const allLabs = [];
  encounters.forEach(enc => {
    try {
      const labs = JSON.parse(enc.lab_orders || '[]');
      labs.forEach(l => allLabs.push({ ...l, encounter_date: enc.encounter_date, enc_id: enc.id, assessment: enc.assessment }));
    } catch {}
  });

  const analyzeLabResult = async (lab, index) => {
    setAnalyzing(index);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda clinical AI assistant analyzing lab results. Based on this ordered lab test and patient context, provide clinical AI suggestions.

Patient: ${patient?.full_name || 'N/A'}
Lab Test: ${lab.test || lab.test_name}
Clinical Context/Diagnosis: ${lab.assessment || 'N/A'}
Urgency: ${lab.urgency || 'Routine'}
Patient Insurance: ${patient?.insurance_type || 'N/A'}
Patient Chronic Conditions: ${patient?.chronic_conditions || 'None known'}
Patient Allergies: ${patient?.allergies || 'None known'}

Based on this lab test, provide AI clinical suggestions: what results might indicate, possible next steps (surgery, referral, medication change, follow-up), and Rwanda-specific guidance.`,
        response_json_schema: {
          type: 'object',
          properties: {
            clinical_significance: { type: 'string' },
            possible_findings: { type: 'array', items: { type: 'string' } },
            if_abnormal_suggest: { type: 'array', items: { type: 'string' } },
            surgery_indicated: { type: 'boolean' },
            referral_suggested: { type: 'boolean' },
            referral_specialty: { type: 'string' },
            medication_adjustments: { type: 'array', items: { type: 'string' } },
            follow_up_tests: { type: 'array', items: { type: 'string' } },
            urgency_note: { type: 'string' },
            rwanda_note: { type: 'string' },
          }
        }
      });
      setSuggestions(prev => ({ ...prev, [index]: result }));
    } catch (e) {
      alert('AI analysis failed');
    } finally {
      setAnalyzing(null);
    }
  };

  if (allLabs.length === 0) {
    return <Card className="p-10 border-0 shadow-sm text-center text-muted-foreground">No lab orders recorded. They will appear here after an AI encounter is created.</Card>;
  }

  return (
    <div className="space-y-3">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
        {allLabs.map((l, i) => {
          const sg = suggestions[i];
          return (
            <Card key={i} className="p-4 border-0 shadow-sm">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
                  <FlaskConical className="w-4 h-4 text-accent" />
                </div>
                <div className="flex-1">
                  <div className="flex items-start justify-between">
                    <p className="text-sm font-semibold">{l.test || l.test_name}</p>
                    {l.urgency && (
                      <Badge className={`text-xs ${l.urgency === 'Urgent' ? 'bg-destructive/10 text-destructive' : 'bg-muted text-muted-foreground'}`}>
                        {l.urgency}
                      </Badge>
                    )}
                  </div>
                  {l.preferred_lab && <p className="text-xs text-accent mt-0.5">Lab: {l.preferred_lab}</p>}
                  {l.reason && <p className="text-xs text-muted-foreground mt-0.5">{l.reason}</p>}
                  <p className="text-xs text-muted-foreground mt-1">
                    Ordered: {l.encounter_date ? format(new Date(l.encounter_date), 'MMM d, yyyy') : 'Unknown'}
                  </p>

                  <Button size="sm" variant="outline" className="gap-1 mt-2 text-xs h-7"
                    onClick={() => analyzeLabResult(l, i)} disabled={analyzing === i}>
                    {analyzing === i ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                    AI Clinical Suggestion
                  </Button>
                </div>
              </div>

              {sg && (
                <div className="mt-3 pt-3 border-t space-y-2">
                  <p className="text-xs font-semibold text-primary">AI Clinical Analysis</p>
                  {sg.clinical_significance && (
                    <p className="text-xs text-muted-foreground">{sg.clinical_significance}</p>
                  )}
                  {(sg.surgery_indicated || sg.referral_suggested) && (
                    <div className="flex gap-2 flex-wrap">
                      {sg.surgery_indicated && <Badge className="text-xs bg-destructive/10 text-destructive"><AlertTriangle className="w-3 h-3 mr-1" />Surgery May Be Indicated</Badge>}
                      {sg.referral_suggested && <Badge className="text-xs bg-orange-50 text-orange-600"><GitBranch className="w-3 h-3 mr-1" />Referral: {sg.referral_specialty}</Badge>}
                    </div>
                  )}
                  {sg.if_abnormal_suggest?.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold mb-1">If Abnormal — Suggested Actions:</p>
                      {sg.if_abnormal_suggest.map((s, j) => (
                        <div key={j} className="flex items-start gap-1 text-xs text-muted-foreground">
                          <CheckCircle2 className="w-3 h-3 text-accent shrink-0 mt-0.5" />{s}
                        </div>
                      ))}
                    </div>
                  )}
                  {sg.medication_adjustments?.length > 0 && (
                    <div>
                      <p className="text-xs font-semibold mb-1"><Pill className="w-3 h-3 inline mr-1" />Medication Adjustments:</p>
                      {sg.medication_adjustments.map((m, j) => (
                        <p key={j} className="text-xs text-muted-foreground ml-4">• {m}</p>
                      ))}
                    </div>
                  )}
                  {sg.urgency_note && (
                    <p className="text-xs text-orange-600 bg-orange-50 rounded p-1.5">{sg.urgency_note}</p>
                  )}
                  {sg.rwanda_note && (
                    <p className="text-xs text-primary bg-primary/5 rounded p-1.5">{sg.rwanda_note}</p>
                  )}
                </div>
              )}
            </Card>
          );
        })}
      </div>
    </div>
  );
}