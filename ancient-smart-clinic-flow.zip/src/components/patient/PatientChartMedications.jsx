import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Pill, Sparkles, Loader2, AlertTriangle, CheckCircle2, Plus, Trash2 } from 'lucide-react';
import { format } from 'date-fns';
import { useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';

export default function PatientChartMedications({ encounters, patient }) {
   const [analyzing, setAnalyzing] = useState(null);
   const [suggestions, setSuggestions] = useState({});
   const [prescribing, setPrescribing] = useState(false);
   const [newMed, setNewMed] = useState({ name: '', dose: '', frequency: '', rationale: '' });
   const [savedMeds, setSavedMeds] = useState([]);
   const queryClient = useQueryClient();

   const latestEncounter = encounters?.length > 0 ? encounters[0] : null;

   useEffect(() => {
     if (latestEncounter?.medications) {
       try { setSavedMeds(JSON.parse(latestEncounter.medications)); } catch {}
     }
   }, [latestEncounter]);

  const allMeds = [];
  encounters.forEach(enc => {
    try {
      const meds = JSON.parse(enc.medications || '[]');
      meds.forEach(m => allMeds.push({ ...m, encounter_date: enc.encounter_date, encounter_id: enc.id }));
    } catch {}
  });

  const analyzeMed = async (med, index) => {
    setAnalyzing(index);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda clinical pharmacist AI. Analyze this medication for a patient and provide AI suggestions.

Patient: ${patient?.full_name || 'N/A'}
Allergies: ${patient?.allergies || 'None known'}
Chronic Conditions: ${patient?.chronic_conditions || 'None'}
Insurance: ${patient?.insurance_type || 'N/A'}

Medication: ${med.name}
Dose: ${med.dose || 'N/A'}
Frequency: ${med.frequency || 'N/A'}
Rationale: ${med.rationale || 'N/A'}

All current medications: ${allMeds.map(m => m.name).join(', ')}

Provide AI suggestions: drug interactions, alternatives, dose appropriateness, Rwanda formulary notes, monitoring required, and patient education points.`,
        response_json_schema: {
          type: 'object',
          properties: {
            appropriateness: { type: 'string' },
            drug_interactions: { type: 'array', items: { type: 'string' } },
            allergy_alert: { type: 'string' },
            alternatives: { type: 'array', items: { type: 'string' } },
            monitoring_required: { type: 'array', items: { type: 'string' } },
            patient_education: { type: 'array', items: { type: 'string' } },
            rwanda_formulary_note: { type: 'string' },
            rssb_covered: { type: 'boolean' },
            mutuelle_covered: { type: 'boolean' },
          }
        }
      });
      setSuggestions(prev => ({ ...prev, [index]: result }));
    } catch (e) {
      alert('AI analysis failed');
    } finally {
      setAnalyzing(null);
    }
  };

  const addMedication = async () => {
    if (!newMed.name || !newMed.dose || !newMed.frequency) {
      toast.error('Please fill name, dose, and frequency');
      return;
    }
    if (!latestEncounter) { toast.error('No active encounter'); return; }

    const updated = [...savedMeds, newMed];
    setSavedMeds(updated);
    await base44.entities.Encounter.update(latestEncounter.id, {
      medications: JSON.stringify(updated),
    });
    queryClient.invalidateQueries({ queryKey: ['patient-encounters', patient.id] });
    setNewMed({ name: '', dose: '', frequency: '', rationale: '' });
    toast.success('Medication added');
  };

  const removeMedication = async (idx) => {
    const updated = savedMeds.filter((_, i) => i !== idx);
    setSavedMeds(updated);
    if (latestEncounter) {
      await base44.entities.Encounter.update(latestEncounter.id, { medications: JSON.stringify(updated) });
      queryClient.invalidateQueries({ queryKey: ['patient-encounters', patient.id] });
    }
  };

  return (
    <div className="space-y-4">
      {/* Add Medication Section */}
      {prescribing && latestEncounter && (
        <Card className="p-5 border-0 shadow-sm bg-primary/5">
          <p className="text-sm font-semibold mb-3">Add Medication to Latest Encounter</p>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 mb-3">
            <div>
              <Label className="text-xs">Drug Name *</Label>
              <Input placeholder="e.g. Amoxicillin" value={newMed.name} onChange={e => setNewMed(prev => ({...prev, name: e.target.value}))} className="mt-1 h-8" />
            </div>
            <div>
              <Label className="text-xs">Dose *</Label>
              <Input placeholder="e.g. 500mg" value={newMed.dose} onChange={e => setNewMed(prev => ({...prev, dose: e.target.value}))} className="mt-1 h-8" />
            </div>
            <div>
              <Label className="text-xs">Frequency *</Label>
              <Input placeholder="e.g. 3x daily" value={newMed.frequency} onChange={e => setNewMed(prev => ({...prev, frequency: e.target.value}))} className="mt-1 h-8" />
            </div>
            <div>
              <Label className="text-xs">Rationale</Label>
              <Input placeholder="e.g. Respiratory infection" value={newMed.rationale} onChange={e => setNewMed(prev => ({...prev, rationale: e.target.value}))} className="mt-1 h-8" />
            </div>
          </div>
          <div className="flex gap-2">
            <Button size="sm" className="gap-2" onClick={addMedication}>
              <Plus className="w-3 h-3" /> Add Medication
            </Button>
            <Button size="sm" variant="outline" onClick={() => setPrescribing(false)}>Cancel</Button>
          </div>
        </Card>
      )}

      {/* Saved Medications from Latest Encounter */}
      {latestEncounter && savedMeds.length > 0 && (
        <Card className="p-4 border-0 shadow-sm bg-accent/5">
          <p className="text-sm font-semibold mb-3">Medications in Latest Encounter</p>
          <div className="space-y-2">
            {savedMeds.map((m, idx) => (
              <div key={idx} className="flex items-center justify-between p-3 bg-white rounded border border-border/50">
                <div>
                  <p className="text-sm font-semibold">{m.name}</p>
                  <p className="text-xs text-primary">{m.dose} — {m.frequency}</p>
                  {m.rationale && <p className="text-xs text-muted-foreground">{m.rationale}</p>}
                </div>
                <Button size="icon" variant="ghost" className="h-7 w-7 text-destructive" onClick={() => removeMedication(idx)}>
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            ))}
          </div>
          {!prescribing && (
            <Button size="sm" className="mt-3 gap-2 w-full bg-accent hover:bg-accent/90" onClick={() => setPrescribing(true)}>
              <Plus className="w-3 h-3" /> Add More Medications
            </Button>
          )}
        </Card>
      )}

      {!latestEncounter && (
        <Card className="p-10 border-0 shadow-sm text-center text-muted-foreground">
          Create an encounter first to prescribe medications.
        </Card>
      )}

      {latestEncounter && savedMeds.length === 0 && !prescribing && (
        <Card className="p-10 border-0 shadow-sm text-center">
          <p className="text-muted-foreground mb-3">No medications prescribed yet</p>
          <Button size="sm" className="gap-2 bg-accent hover:bg-accent/90" onClick={() => setPrescribing(true)}>
            <Plus className="w-3 h-3" /> Prescribe Medication
          </Button>
        </Card>
      )}

      {/* Historical Medications */}
      {allMeds.length > 0 && (
        <>
          <div>
            <p className="text-sm font-semibold mb-3">Medication History</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {allMeds.map((m, i) => {
        const sg = suggestions[i];
        return (
          <Card key={i} className="p-4 border-0 shadow-sm">
            <div className="flex items-start gap-3">
              <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center shrink-0">
                <Pill className="w-4 h-4 text-primary" />
              </div>
              <div className="flex-1">
                <div className="flex items-start justify-between">
                  <p className="text-sm font-semibold">{m.name}</p>
                  {m.refill_date && <Badge variant="secondary" className="text-xs">Refill: {format(new Date(m.refill_date), 'MMM d')}</Badge>}
                </div>
                <p className="text-xs text-primary mt-0.5">{m.dose} {m.frequency && `— ${m.frequency}`}</p>
                {m.duration && <p className="text-xs text-muted-foreground">{m.duration}</p>}
                {m.rationale && <p className="text-xs text-muted-foreground mt-1 italic">{m.rationale}</p>}
                <p className="text-xs text-muted-foreground mt-1">
                  Prescribed: {m.encounter_date ? format(new Date(m.encounter_date), 'MMM d, yyyy') : 'Unknown'}
                </p>

                <Button size="sm" variant="outline" className="gap-1 mt-2 text-xs h-7"
                  onClick={() => analyzeMed(m, i)} disabled={analyzing === i}>
                  {analyzing === i ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
                  AI Medication Analysis
                </Button>
              </div>
            </div>

            {sg && (
              <div className="mt-3 pt-3 border-t space-y-2">
                <div className="flex items-center gap-2">
                  <p className="text-xs font-semibold text-primary">AI Pharmacist Suggestions</p>
                  <Badge variant={sg.rssb_covered ? 'default' : 'outline'} className="text-xs">
                    {sg.rssb_covered ? 'RSSB ✓' : 'RSSB: Check'}
                  </Badge>
                  <Badge variant={sg.mutuelle_covered ? 'default' : 'outline'} className="text-xs">
                    {sg.mutuelle_covered ? 'Mutuelle ✓' : 'Mutuelle: Check'}
                  </Badge>
                </div>
                {sg.appropriateness && <p className="text-xs text-muted-foreground">{sg.appropriateness}</p>}
                {sg.allergy_alert && sg.allergy_alert !== 'None' && (
                  <div className="flex items-center gap-2 p-2 bg-destructive/10 rounded text-xs text-destructive">
                    <AlertTriangle className="w-3 h-3 shrink-0" />{sg.allergy_alert}
                  </div>
                )}
                {sg.drug_interactions?.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-orange-600 mb-1">Drug Interactions:</p>
                    {sg.drug_interactions.map((d, j) => (
                      <p key={j} className="text-xs text-orange-600 ml-2">⚠ {d}</p>
                    ))}
                  </div>
                )}
                {sg.monitoring_required?.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold mb-1">Monitoring Required:</p>
                    {sg.monitoring_required.map((mo, j) => (
                      <div key={j} className="flex items-start gap-1 text-xs text-muted-foreground">
                        <CheckCircle2 className="w-3 h-3 text-accent shrink-0 mt-0.5" />{mo}
                      </div>
                    ))}
                  </div>
                )}
                {sg.rwanda_formulary_note && (
                  <p className="text-xs text-primary bg-primary/5 rounded p-1.5">{sg.rwanda_formulary_note}</p>
                )}
              </div>
            )}
          </Card>
          );
          })}
          </div>
          </>
          )}
          </div>
          );
          }