import React from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { GitBranch } from 'lucide-react';
import { format } from 'date-fns';

export default function PatientChartReferrals({ encounters }) {
  const referrals = encounters.filter(e => {
    try {
      const log = JSON.parse(e.ai_suggestions_log || '{}');
      return log.referral_needed || e.plan?.toLowerCase().includes('refer');
    } catch { return false; }
  });

  if (referrals.length === 0) {
    return <Card className="p-10 border-0 shadow-sm text-center text-muted-foreground">No referrals recorded.</Card>;
  }

  return (
    <div className="space-y-3">
      {referrals.map((enc, i) => (
        <Card key={i} className="p-4 border-0 shadow-sm">
          <div className="flex items-start gap-3">
            <div className="w-8 h-8 rounded-lg bg-orange-50 flex items-center justify-center shrink-0">
              <GitBranch className="w-4 h-4 text-orange-500" />
            </div>
            <div>
              <p className="text-sm font-semibold">{enc.chief_complaint || 'Referral'}</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                {enc.encounter_date ? format(new Date(enc.encounter_date), 'MMM d, yyyy') : ''}
              </p>
              {enc.plan && <p className="text-xs text-muted-foreground mt-1 line-clamp-2">{enc.plan}</p>}
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}