import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, CheckCircle2, XCircle, AlertTriangle, ShieldCheck } from 'lucide-react';

const RWANDA_INSURERS = {
  'RSSB (RAMA)': { color: 'bg-blue-50 text-blue-700', org: 'Rwanda Social Security Board' },
  'MMI': { color: 'bg-purple-50 text-purple-700', org: 'Military Medical Insurance' },
  'Mutuelle de Santé': { color: 'bg-green-50 text-green-700', org: 'Community Health Insurance' },
  'Private': { color: 'bg-orange-50 text-orange-700', org: 'Private Insurance' },
};

export default function PatientEligibility({ patient }) {
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState(null);

  const checkEligibility = async () => {
    if (!patient.insurance_type || patient.insurance_type === 'None') return;
    setChecking(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda insurance eligibility verification system. Check eligibility for this patient:

Patient: ${patient.full_name}
National ID: ${patient.national_id || 'N/A'}
Insurance: ${patient.insurance_type}
Insurance ID: ${patient.insurance_id || 'N/A'}
District: ${patient.district || 'N/A'}
Date of Birth: ${patient.date_of_birth || 'N/A'}

Rwanda insurance providers: RSSB (RAMA), MMI, Mutuelle de Santé, Private.

Simulate a real-time eligibility check response as if querying the ${patient.insurance_type} system. Include coverage details, co-payment, active status, benefit limits, and any prior authorizations required per Rwanda health standards.`,
        response_json_schema: {
          type: 'object',
          properties: {
            is_eligible: { type: 'boolean' },
            status: { type: 'string' },
            coverage_start: { type: 'string' },
            coverage_end: { type: 'string' },
            plan_name: { type: 'string' },
            co_payment_percentage: { type: 'number' },
            co_payment_amount_rwf: { type: 'string' },
            deductible_met: { type: 'boolean' },
            benefit_limits: { type: 'array', items: { type: 'string' } },
            covered_services: { type: 'array', items: { type: 'string' } },
            excluded_services: { type: 'array', items: { type: 'string' } },
            prior_auth_required: { type: 'array', items: { type: 'string' } },
            notes: { type: 'string' },
            fraud_risk_flag: { type: 'string' },
          }
        }
      });
      setResult(res);
    } catch (e) {
      alert('Eligibility check failed. Please try again.');
    } finally {
      setChecking(false);
    }
  };

  const insurerInfo = RWANDA_INSURERS[patient.insurance_type] || {};

  return (
    <div className="space-y-4">
      <Card className="p-5 border-0 shadow-sm">
        <div className="flex items-center justify-between">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <ShieldCheck className="w-5 h-5 text-primary" />
              <p className="text-sm font-semibold">Insurance Eligibility Verification</p>
            </div>
            <p className="text-xs text-muted-foreground">Real-time check against Rwanda's insurance systems</p>
          </div>
          <Button className="gap-2" onClick={checkEligibility} disabled={checking || !patient.insurance_type || patient.insurance_type === 'None'}>
            {checking ? <><Loader2 className="w-4 h-4 animate-spin" /> Verifying...</> : <><Sparkles className="w-4 h-4" /> Verify Eligibility</>}
          </Button>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4">
          <div className="p-3 bg-muted/40 rounded-lg">
            <p className="text-xs text-muted-foreground">Insurance Provider</p>
            <p className="text-sm font-semibold mt-0.5">{patient.insurance_type || 'None'}</p>
            {insurerInfo.org && <p className="text-xs text-muted-foreground">{insurerInfo.org}</p>}
          </div>
          <div className="p-3 bg-muted/40 rounded-lg">
            <p className="text-xs text-muted-foreground">Insurance ID</p>
            <p className="text-sm font-semibold mt-0.5">{patient.insurance_id || '—'}</p>
          </div>
          <div className="p-3 bg-muted/40 rounded-lg">
            <p className="text-xs text-muted-foreground">National ID</p>
            <p className="text-sm font-semibold mt-0.5">{patient.national_id || '—'}</p>
          </div>
          <div className="p-3 bg-muted/40 rounded-lg">
            <p className="text-xs text-muted-foreground">District</p>
            <p className="text-sm font-semibold mt-0.5">{patient.district || '—'}</p>
          </div>
        </div>
      </Card>

      {result && (
        <div className="space-y-4">
          {/* Status Banner */}
          <Card className={`p-5 border-0 shadow-sm ${result.is_eligible ? 'bg-accent/5 border-l-4 border-l-accent' : 'bg-destructive/5 border-l-4 border-l-destructive'}`}>
            <div className="flex items-center gap-3">
              {result.is_eligible
                ? <CheckCircle2 className="w-8 h-8 text-accent" />
                : <XCircle className="w-8 h-8 text-destructive" />}
              <div>
                <p className="text-lg font-bold">{result.is_eligible ? 'ELIGIBLE' : 'NOT ELIGIBLE'}</p>
                <p className="text-sm text-muted-foreground">{result.status}</p>
                {result.plan_name && <Badge className="mt-1 text-xs bg-primary/10 text-primary">{result.plan_name}</Badge>}
              </div>
              {result.fraud_risk_flag && result.fraud_risk_flag !== 'None' && result.fraud_risk_flag !== 'Low' && (
                <div className="ml-auto">
                  <Badge className="text-xs bg-orange-50 text-orange-600">
                    <AlertTriangle className="w-3 h-3 mr-1" />Fraud Risk: {result.fraud_risk_flag}
                  </Badge>
                </div>
              )}
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="p-4 border-0 shadow-sm">
              <p className="text-xs font-semibold mb-2">Coverage Period</p>
              <p className="text-xs text-muted-foreground">From: <span className="font-medium text-foreground">{result.coverage_start || 'N/A'}</span></p>
              <p className="text-xs text-muted-foreground mt-1">To: <span className="font-medium text-foreground">{result.coverage_end || 'N/A'}</span></p>
              <div className="mt-3 pt-3 border-t">
                <p className="text-xs font-semibold">Co-Payment</p>
                <p className="text-lg font-bold text-primary">{result.co_payment_percentage}%</p>
                {result.co_payment_amount_rwf && <p className="text-xs text-muted-foreground">≈ {result.co_payment_amount_rwf} RWF</p>}
              </div>
            </Card>

            {result.covered_services?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <p className="text-xs font-semibold mb-2 text-accent">Covered Services</p>
                <div className="space-y-1">
                  {result.covered_services.map((s, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-xs">
                      <CheckCircle2 className="w-3 h-3 text-accent shrink-0" /> {s}
                    </div>
                  ))}
                </div>
              </Card>
            )}

            {result.excluded_services?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <p className="text-xs font-semibold mb-2 text-destructive">Excluded Services</p>
                <div className="space-y-1">
                  {result.excluded_services.map((s, i) => (
                    <div key={i} className="flex items-center gap-1.5 text-xs">
                      <XCircle className="w-3 h-3 text-destructive shrink-0" /> {s}
                    </div>
                  ))}
                </div>
              </Card>
            )}
          </div>

          {result.prior_auth_required?.length > 0 && (
            <Card className="p-4 border-0 shadow-sm bg-orange-50/50">
              <div className="flex items-center gap-2 mb-2">
                <AlertTriangle className="w-4 h-4 text-orange-500" />
                <p className="text-xs font-semibold text-orange-600">Prior Authorization Required</p>
              </div>
              <div className="flex flex-wrap gap-2">
                {result.prior_auth_required.map((a, i) => (
                  <Badge key={i} className="text-xs bg-orange-100 text-orange-700">{a}</Badge>
                ))}
              </div>
            </Card>
          )}

          {result.notes && (
            <Card className="p-4 border-0 shadow-sm">
              <p className="text-xs font-semibold mb-1">Verification Notes</p>
              <p className="text-xs text-muted-foreground">{result.notes}</p>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}