import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Sparkles, MapPin, AlertTriangle, Globe, TrendingUp, BookOpen } from 'lucide-react';
import { MapContainer, TileLayer, CircleMarker, Tooltip } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';

const DISTRICTS = [
  { name: 'Gasabo', lat: -1.9403, lng: 30.0587 },
  { name: 'Kicukiro', lat: -1.9831, lng: 30.1083 },
  { name: 'Nyarugenge', lat: -1.9537, lng: 30.0442 },
  { name: 'Musanze', lat: -1.4993, lng: 29.6346 },
  { name: 'Huye', lat: -2.5962, lng: 29.7394 },
  { name: 'Rubavu', lat: -1.6832, lng: 29.2534 },
  { name: 'Kayonza', lat: -1.8608, lng: 30.6498 },
  { name: 'Bugesera', lat: -2.2136, lng: 30.2313 },
];

export default function PatientGISPanel({ patient, latestEncounter }) {
  const [loading, setLoading] = useState(false);
  const [intelligence, setIntelligence] = useState(null);

  const diagnosis = latestEncounter?.assessment || '';

  const runGISAnalysis = async () => {
    if (!diagnosis) return;
    setLoading(true);
    try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a global disease intelligence AI for Rwanda healthcare. The patient has this diagnosis: "${diagnosis}". Patient district: ${patient.district || 'Kigali'}.

Provide comprehensive disease intelligence including:
1. Origin of this disease globally and in Rwanda
2. How the disease spreads (food, activity, vector, contact etc.)
3. Countries/cities that controlled it and HOW they controlled it
4. Current status globally (ongoing or resolved)
5. Prediction: what happens to this patient if untreated (timeline)
6. Rwanda-specific district risk analysis
7. Treatment recommendations that worked globally`,
      model: 'gemini_3_flash',
      add_context_from_internet: true,
      response_json_schema: {
        type: 'object',
        properties: {
          disease_name: { type: 'string' },
          global_origin: { type: 'string' },
          origin_country: { type: 'string' },
          how_disease_occurs: { type: 'string' },
          transmission_routes: { type: 'array', items: { type: 'string' } },
          countries_controlled: { type: 'array', items: { type: 'object', properties: { country: { type: 'string' }, method: { type: 'string' }, outcome: { type: 'string' } } } },
          global_status: { type: 'string' },
          rwanda_risk_level: { type: 'string' },
          high_risk_districts: { type: 'array', items: { type: 'string' } },
          untreated_prediction: { type: 'string' },
          timeline_if_untreated: { type: 'string' },
          recommended_treatment: { type: 'string' },
          prevention_measures: { type: 'array', items: { type: 'string' } },
        }
      }
    });
    setIntelligence(result);
    } catch (e) {
      alert('GIS analysis failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  if (!diagnosis) {
    return (
      <Card className="p-10 border-0 shadow-sm text-center">
        <MapPin className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
        <p className="text-muted-foreground">No diagnosis found. Complete an encounter first to see the GIS disease intelligence.</p>
      </Card>
    );
  }

  return (
    <div className="space-y-4">
      <Card className="p-4 border-0 shadow-sm bg-primary/5">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold">Disease Intelligence for: <span className="text-primary">{diagnosis}</span></p>
            <p className="text-xs text-muted-foreground mt-0.5">Patient district: {patient.district || 'Not specified'}</p>
          </div>
          <Button className="gap-2" onClick={runGISAnalysis} disabled={loading}>
            {loading ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Sparkles className="w-4 h-4" /> Run GIS Analysis</>}
          </Button>
        </div>
      </Card>

      {intelligence && (
        <>
          {/* Map */}
          <Card className="border-0 shadow-sm overflow-hidden rounded-xl">
            <div className="p-3 border-b flex items-center justify-between">
              <p className="text-sm font-semibold">Rwanda District Risk Map — {intelligence.disease_name}</p>
              <Badge className={`text-xs ${intelligence.rwanda_risk_level === 'High' ? 'bg-destructive/10 text-destructive' : intelligence.rwanda_risk_level === 'Medium' ? 'bg-orange-50 text-orange-600' : 'bg-accent/10 text-accent'}`}>
                {intelligence.rwanda_risk_level} National Risk
              </Badge>
            </div>
            <div style={{ height: '260px' }}>
              <MapContainer center={[-1.9403, 29.8739]} zoom={8} style={{ height: '100%', width: '100%' }} scrollWheelZoom={false} zoomControl={false}>
                <TileLayer url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png" attribution="" />
                {DISTRICTS.map(d => {
                  const isHighRisk = intelligence.high_risk_districts?.some(r => r.toLowerCase().includes(d.name.toLowerCase()));
                  return (
                    <CircleMarker
                      key={d.name}
                      center={[d.lat, d.lng]}
                      radius={isHighRisk ? 18 : 8}
                      pathOptions={{ fillColor: isHighRisk ? '#e74c3c' : '#3498db', fillOpacity: isHighRisk ? 0.7 : 0.4, color: 'white', weight: 1 }}
                    >
                      <Tooltip>{d.name}{isHighRisk ? ' ⚠ High Risk' : ''}</Tooltip>
                    </CircleMarker>
                  );
                })}
              </MapContainer>
            </div>
          </Card>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* Origin */}
            <Card className="p-4 border-0 shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <Globe className="w-4 h-4 text-primary" />
                <p className="text-sm font-semibold">Disease Origin</p>
                {intelligence.origin_country && <Badge variant="secondary" className="text-xs">{intelligence.origin_country}</Badge>}
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">{intelligence.global_origin}</p>
            </Card>

            {/* How it occurs */}
            <Card className="p-4 border-0 shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <BookOpen className="w-4 h-4 text-accent" />
                <p className="text-sm font-semibold">How It Occurs</p>
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed mb-2">{intelligence.how_disease_occurs}</p>
              <div className="flex flex-wrap gap-1.5">
                {intelligence.transmission_routes?.map((r, i) => (
                  <Badge key={i} variant="outline" className="text-xs">{r}</Badge>
                ))}
              </div>
            </Card>

            {/* Untreated prediction */}
            <Card className="p-4 border-0 shadow-sm border-destructive/20 bg-destructive/5">
              <div className="flex items-center gap-2 mb-3">
                <AlertTriangle className="w-4 h-4 text-destructive" />
                <p className="text-sm font-semibold text-destructive">If Untreated</p>
              </div>
              <p className="text-xs leading-relaxed mb-1">{intelligence.untreated_prediction}</p>
              {intelligence.timeline_if_untreated && (
                <p className="text-xs text-destructive font-medium mt-2">Timeline: {intelligence.timeline_if_untreated}</p>
              )}
            </Card>

            {/* Global control */}
            <Card className="p-4 border-0 shadow-sm">
              <div className="flex items-center gap-2 mb-3">
                <TrendingUp className="w-4 h-4 text-accent" />
                <p className="text-sm font-semibold">How Countries Controlled It</p>
              </div>
              <div className="space-y-2">
                {intelligence.countries_controlled?.map((c, i) => (
                  <div key={i} className="p-2.5 bg-muted/40 rounded-lg">
                    <p className="text-xs font-semibold">{c.country}</p>
                    <p className="text-xs text-muted-foreground">{c.method}</p>
                    <p className="text-xs text-accent">{c.outcome}</p>
                  </div>
                ))}
              </div>
            </Card>
          </div>

          {/* Global Status + Prevention */}
          <Card className="p-4 border-0 shadow-sm">
            <p className="text-xs font-semibold mb-2">Global Status: <span className="text-primary">{intelligence.global_status}</span></p>
            <p className="text-xs text-muted-foreground mb-3">Recommended Treatment: {intelligence.recommended_treatment}</p>
            {intelligence.prevention_measures?.length > 0 && (
              <div>
                <p className="text-xs font-semibold mb-2">Prevention Measures:</p>
                <div className="flex flex-wrap gap-2">
                  {intelligence.prevention_measures.map((p, i) => (
                    <Badge key={i} variant="secondary" className="text-xs">{p}</Badge>
                  ))}
                </div>
              </div>
            )}
          </Card>
        </>
      )}
    </div>
  );
}