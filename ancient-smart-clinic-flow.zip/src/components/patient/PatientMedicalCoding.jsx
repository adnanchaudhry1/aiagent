import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useQueryClient } from '@tanstack/react-query';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Sparkles, Loader2, Plus, X, CheckCircle2, AlertTriangle, Lock } from 'lucide-react';
import { toast } from 'sonner';

export default function PatientMedicalCoding({ encounters, patient }) {
   const navigate = useNavigate();
   const [searchParams] = useSearchParams();
   const [selectedEncId, setSelectedEncId] = useState('');
  const [encounterText, setEncounterText] = useState('');
  const [icdCodes, setIcdCodes] = useState([]);
  const [cptCodes, setCptCodes] = useState([]);
  const [modifiers, setModifiers] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [saved, setSaved] = useState(false);
  const [manualIcd, setManualIcd] = useState({ code: '', description: '' });
  const [manualCpt, setManualCpt] = useState({ code: '', description: '' });
  const queryClient = useQueryClient();

  const selectedEncounter = encounters.find(e => e.id === selectedEncId);
  const isLocked = selectedEncounter && (selectedEncounter.status === 'Finalized' || selectedEncounter.status === 'Doctor Approved');

  useEffect(() => {
    if (encounters.length > 0 && !selectedEncId) {
      const approved = encounters.find(e => e.status === 'Doctor Approved');
      if (approved) loadEncounter(approved.id);
    }
  }, [encounters]);

  const loadEncounter = (encId) => {
    setSelectedEncId(encId);
    const enc = encounters.find(e => e.id === encId);
    if (enc) {
      setEncounterText(`Assessment: ${enc.assessment || ''}\nPlan: ${enc.plan || ''}\nSubjective: ${enc.subjective || ''}\nChief Complaint: ${enc.chief_complaint || ''}`);
      setSaved(false);
      try { setIcdCodes(enc.icd_codes ? JSON.parse(enc.icd_codes) : []); } catch { setIcdCodes([]); }
      try { setCptCodes(enc.cpt_codes ? JSON.parse(enc.cpt_codes) : []); } catch { setCptCodes([]); }
      try { setModifiers(enc.modifiers ? JSON.parse(enc.modifiers) : []); } catch { setModifiers([]); }
    }
  };

  const getCodeSuggestions = async () => {
    if (!encounterText.trim()) { toast.error('Load an encounter first'); return; }
    setGenerating(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda medical coding AI expert using ICD-10 (Rwanda uses ICD-10, NOT ICD-11). Based on this clinical encounter, suggest ICD-10 diagnostic codes, CPT procedure codes, and billing modifiers.

Patient: ${patient.full_name}
Insurance: ${patient.insurance_type || 'N/A'}

Encounter:
"${encounterText}"

IMPORTANT: Use ICD-10 codes only. Consider Rwanda insurance payers (RSSB/RAMA, MMI, Mutuelle de Santé).
Also flag any fraud risk if diagnoses don't match procedures.`,
        response_json_schema: {
          type: 'object',
          properties: {
            icd_codes: { type: 'array', items: { type: 'object', properties: { code: { type: 'string' }, description: { type: 'string' }, confidence: { type: 'number' } } } },
            cpt_codes: { type: 'array', items: { type: 'object', properties: { code: { type: 'string' }, description: { type: 'string' }, confidence: { type: 'number' } } } },
            modifiers: { type: 'array', items: { type: 'object', properties: { code: { type: 'string' }, description: { type: 'string' }, confidence: { type: 'number' } } } },
            fraud_risk: { type: 'string' },
            fraud_notes: { type: 'string' },
          }
        }
      });
      setIcdCodes(result.icd_codes || []);
      setCptCodes(result.cpt_codes || []);
      setModifiers(result.modifiers || []);
      if (result.fraud_risk && result.fraud_risk !== 'Low' && result.fraud_risk !== 'None') {
        toast.error(`⚠ Fraud Risk: ${result.fraud_risk} — ${result.fraud_notes}`);
      } else {
        toast.success('ICD-10 code suggestions generated');
      }
    } catch (e) {
      toast.error('Code generation failed');
    } finally {
      setGenerating(false);
    }
  };

  const saveToEncounter = async () => {
    if (!selectedEncounter || isLocked) return;
    await base44.entities.Encounter.update(selectedEncounter.id, {
      icd_codes: JSON.stringify(icdCodes),
      cpt_codes: JSON.stringify(cptCodes),
      modifiers: JSON.stringify(modifiers),
    });
    queryClient.invalidateQueries({ queryKey: ['patient-encounters', patient.id] });
    setSaved(true);
    toast.success('Codes saved. Moving to medications...');
    setTimeout(() => navigate(`?tab=medications`), 800);
  };

  const removeCode = (type, idx) => {
    if (isLocked) return;
    if (type === 'icd') setIcdCodes(prev => prev.filter((_, i) => i !== idx));
    if (type === 'cpt') setCptCodes(prev => prev.filter((_, i) => i !== idx));
    if (type === 'mod') setModifiers(prev => prev.filter((_, i) => i !== idx));
  };

  const CodeTable = ({ title, codes, type, manual, setManual, colorClass }) => (
    <Card className="p-4 border-0 shadow-sm">
      <div className="flex items-center justify-between mb-2">
        <p className={`text-xs font-semibold ${colorClass}`}>{title}</p>
        <Badge variant="secondary" className="text-xs">{codes.length} codes</Badge>
      </div>
      {codes.length > 0 && (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-xs">Code</TableHead>
              <TableHead className="text-xs">Description</TableHead>
              <TableHead className="text-xs">Confidence</TableHead>
              {!isLocked && <TableHead className="text-xs w-12"></TableHead>}
            </TableRow>
          </TableHeader>
          <TableBody>
            {codes.map((c, idx) => (
              <TableRow key={idx}>
                <TableCell className="font-mono text-sm font-semibold text-primary">{c.code}</TableCell>
                <TableCell className="text-xs">{c.description}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-1">
                    <div className="w-12 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div className={`h-full rounded-full ${c.confidence >= 80 ? 'bg-accent' : c.confidence >= 60 ? 'bg-orange-400' : 'bg-destructive'}`} style={{ width: `${c.confidence}%` }} />
                    </div>
                    <span className="text-xs">{c.confidence}%</span>
                  </div>
                </TableCell>
                {!isLocked && (
                  <TableCell><Button variant="ghost" size="sm" onClick={() => removeCode(type, idx)}><X className="w-3 h-3" /></Button></TableCell>
                )}
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
      {!isLocked && (
        <div className="flex gap-2 mt-2">
          <Input placeholder="Code" value={manual.code} onChange={e => setManual({ ...manual, code: e.target.value })} className="w-28 text-sm" />
          <Input placeholder="Description" value={manual.description} onChange={e => setManual({ ...manual, description: e.target.value })} className="flex-1 text-sm" />
          <Button variant="outline" size="sm" onClick={() => {
            if (manual.code) {
              if (type === 'icd') setIcdCodes(prev => [...prev, { ...manual, confidence: 100 }]);
              if (type === 'cpt') setCptCodes(prev => [...prev, { ...manual, confidence: 100 }]);
              setManual({ code: '', description: '' });
            }
          }} className="gap-1"><Plus className="w-3 h-3" />Add</Button>
        </div>
      )}
    </Card>
  );

  return (
    <div className="space-y-4">
      {isLocked && (
        <Card className="p-4 border-0 shadow-sm bg-orange-50/50 border-orange-200">
          <div className="flex items-center gap-2">
            <Lock className="w-4 h-4 text-orange-500" />
            <p className="text-sm font-semibold text-orange-600">Encounter Locked — Claim Submitted</p>
            <p className="text-xs text-muted-foreground">This encounter has been finalized and cannot be modified.</p>
          </div>
        </Card>
      )}

      <Card className="p-5 border-0 shadow-sm">
        <div className="flex gap-4 items-end flex-wrap">
          <div className="flex-1 min-w-48">
            <Label className="text-xs">Select Encounter</Label>
            <Select value={selectedEncId} onValueChange={loadEncounter}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select encounter..." /></SelectTrigger>
              <SelectContent>
                {encounters.map(e => (
                  <SelectItem key={e.id} value={e.id}>
                    {e.encounter_number ? `#${e.encounter_number} — ` : ''}{e.status} — {new Date(e.created_date).toLocaleDateString()}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <Button onClick={getCodeSuggestions} disabled={generating || isLocked || !encounterText.trim()} className="gap-2">
            {generating ? <><Loader2 className="w-4 h-4 animate-spin" />Generating...</> : <><Sparkles className="w-4 h-4" />Get ICD-10 Codes</>}
          </Button>
        </div>
        <Textarea value={encounterText} onChange={e => !isLocked && setEncounterText(e.target.value)} readOnly={isLocked}
          className="mt-3 min-h-[80px] text-sm" placeholder="Load an encounter to see the clinical text..." />
      </Card>

      <CodeTable title="ICD-10 Diagnostic Codes (Rwanda Standard)" codes={icdCodes} type="icd" manual={manualIcd} setManual={setManualIcd} colorClass="text-blue-700" />
      <CodeTable title="CPT Procedure Codes" codes={cptCodes} type="cpt" manual={manualCpt} setManual={setManualCpt} colorClass="text-purple-700" />

      {!isLocked && selectedEncounter && (icdCodes.length > 0 || cptCodes.length > 0) && (
        <Button className="gap-2" onClick={saveToEncounter}>
          <CheckCircle2 className="w-4 h-4" /> Save Codes to Encounter
        </Button>
      )}
    </div>
  );
}