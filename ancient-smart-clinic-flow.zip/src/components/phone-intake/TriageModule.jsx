import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Loader2, Sparkles, AlertTriangle, ShieldAlert, Activity, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';

const RISK_COLORS = {
  LOW: 'bg-accent/10 text-accent border-accent/20',
  MODERATE: 'bg-orange-100 text-orange-700 border-orange-200',
  HIGH: 'bg-destructive/10 text-destructive border-destructive/20',
  CRITICAL: 'bg-destructive text-white border-destructive',
};

const COMPLAINT_CATEGORIES = [
  { value: 'fever', label: '🌡️ Fever' },
  { value: 'cough_breathing', label: '🫁 Cough / Breathing' },
  { value: 'pain', label: '💢 Pain' },
  { value: 'pregnancy', label: '🤰 Pregnancy' },
  { value: 'child_illness', label: '👶 Child Illness' },
  { value: 'diarrhea_vomiting', label: '🤢 Diarrhea / Vomiting' },
  { value: 'injury', label: '🩹 Injury' },
  { value: 'skin', label: '🩺 Skin Issue' },
  { value: 'mental_health', label: '🧠 Mental Health' },
  { value: 'medication_refill', label: '💊 Medication Refill' },
  { value: 'chronic_followup', label: '📋 Chronic Disease Follow-up' },
  { value: 'vaccination', label: '💉 Vaccination' },
  { value: 'other', label: '❓ Other' },
];

const CHRONIC_OPTIONS = [
  'Diabetes', 'Hypertension', 'HIV', 'Asthma',
  'Heart disease', 'Kidney disease', 'Cancer', 'Epilepsy', 'Other',
];

const EMERGENCY_QUESTIONS = [
  'Are you having severe difficulty breathing?',
  'Do you have severe chest pain?',
  'Are you bleeding heavily?',
  'Have you fainted or become unconscious?',
  'Are you confused or unable to respond normally?',
  'Are you having seizures?',
  'Did you experience a serious injury or accident?',
  'Are you unable to move one side of your body?',
  'Are you vomiting blood?',
  'Are you unable to drink or eat?',
  'Are your lips or face turning blue?',
  'Are you pregnant with severe pain or bleeding?',
  'Is a child unable to feed, wake, or breathe normally?',
];

function calcRiskScore(data) {
  let score = 0;
  const age = parseInt(data.patient_age) || 0;
  if (age > 65) score += 15;
  if (age < 5) score += 15;
  if (data.pregnancy_status === 'yes') score += 10;
  if (data.chronic_conditions?.length > 0) score += 10;
  if (data.emergency_flags?.includes('difficulty_breathing')) score += 40;
  if (data.emergency_flags?.includes('chest_pain')) score += 40;
  if (data.emergency_flags?.includes('heavy_bleeding')) score += 50;
  if (data.emergency_flags?.includes('confused')) score += 50;
  if (data.emergency_flags?.includes('cannot_drink')) score += 25;
  if (data.emergency_flags?.includes('seizure')) score += 50;
  if (data.emergency_flags?.includes('vomiting_blood')) score += 50;
  if (data.emergency_flags?.includes('severe_injury')) score += 50;
  if (data.emergency_flags?.includes('mental_health_crisis')) score += 50;
  if (data.fever_days && parseInt(data.fever_days) > 5) score += 15;
  return score;
}

function getRiskLevel(score) {
  if (score >= 85) return 'CRITICAL';
  if (score >= 60) return 'HIGH';
  if (score >= 30) return 'MODERATE';
  return 'LOW';
}

function getRouteFromLevel(level) {
  if (level === 'CRITICAL') return { priority: 'IMMEDIATE', route: 'HOSPITAL', routeType: 'hospital' };
  if (level === 'HIGH') return { priority: 'SAME DAY', route: 'DOCTOR / CLINIC', routeType: 'hospital' };
  if (level === 'MODERATE') return { priority: 'WITHIN 24 HOURS', route: 'CHW URGENT VISIT', routeType: 'chw' };
  return { priority: 'ROUTINE', route: 'CHW STANDARD', routeType: 'chw' };
}

export default function TriageModule({ intakeData, onTriageComplete }) {
  const [triageStep, setTriageStep] = useState('demographics'); // demographics | emergency | complaint | category_questions | result
  const [triageData, setTriageData] = useState({
    patient_age: '',
    patient_sex: '',
    location: '',
    pregnancy_status: 'no',
    chronic_conditions: [],
    emergency_answers: Array(EMERGENCY_QUESTIONS.length).fill(false),
    complaint_category: '',
    category_answers: {},
    emergency_flags: [],
  });
  const [running, setRunning] = useState(false);
  const [triageResult, setTriageResult] = useState(null);

  const toggleChronic = (condition) => {
    setTriageData(d => ({
      ...d,
      chronic_conditions: d.chronic_conditions.includes(condition)
        ? d.chronic_conditions.filter(c => c !== condition)
        : [...d.chronic_conditions, condition],
    }));
  };

  const checkEmergencyFlags = () => {
    const flags = [];
    const answers = triageData.emergency_answers;
    if (answers[0]) flags.push('difficulty_breathing');
    if (answers[1]) flags.push('chest_pain');
    if (answers[2]) flags.push('heavy_bleeding');
    if (answers[3]) flags.push('fainted');
    if (answers[4]) flags.push('confused');
    if (answers[5]) flags.push('seizure');
    if (answers[6]) flags.push('severe_injury');
    if (answers[7]) flags.push('cannot_move');
    if (answers[8]) flags.push('vomiting_blood');
    if (answers[9]) flags.push('cannot_drink');
    if (answers[10]) flags.push('blue_lips');
    if (answers[11]) flags.push('pregnant_severe');
    if (answers[12]) flags.push('child_critical');
    return flags;
  };

  const proceedFromEmergency = () => {
    const flags = checkEmergencyFlags();
    const updatedData = { ...triageData, emergency_flags: flags };
    setTriageData(updatedData);
    if (flags.length > 0) {
      runAITriage(updatedData, true);
    } else {
      setTriageStep('complaint');
    }
  };

  const runAITriage = async (data, emergencyOnly = false) => {
    setRunning(true);
    try {
      const score = calcRiskScore(data);
      const level = getRiskLevel(score);
      const routing = getRouteFromLevel(level);

      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda healthcare AI triage system. Analyze this patient and generate a structured triage output.

Patient Info:
- Name: ${intakeData.patient_name || 'Unknown'}
- Age: ${data.patient_age || 'Unknown'}
- Sex: ${data.patient_sex || 'Unknown'}
- Location: ${data.location || 'Unknown'}
- Pregnancy: ${data.pregnancy_status}
- Chronic Conditions: ${data.chronic_conditions.join(', ') || 'None'}
- Problem Description: ${intakeData.problem_description || 'See emergency flags'}
- Emergency Flags: ${data.emergency_flags.join(', ') || 'None'}
- Complaint Category: ${data.complaint_category || 'Not categorized'}
- Category Answers: ${JSON.stringify(data.category_answers)}
- Calculated Risk Score: ${score}
- Calculated Risk Level: ${level}

Generate a structured clinical triage output. Red flags should list specific clinical warning signs present. Confidence should be 0.0-1.0.
Summary should be suitable for OpenMRS clinical notes (2-3 sentences, clinical language).`,
        response_json_schema: {
          type: 'object',
          properties: {
            risk_level: { type: 'string' },
            risk_score: { type: 'number' },
            priority: { type: 'string' },
            route: { type: 'string' },
            red_flags: { type: 'array', items: { type: 'string' } },
            confidence: { type: 'number' },
            reason: { type: 'string' },
            summary: { type: 'string' },
          }
        }
      });

      const result = {
        ...res,
        risk_level: level,
        risk_score: score,
        priority: routing.priority,
        route: routing.route,
        routeType: routing.routeType,
        emergency_flags: data.emergency_flags,
        is_emergency: emergencyOnly || level === 'CRITICAL',
      };

      setTriageResult(result);
      setTriageStep('result');
    } catch {
      toast.error('Triage analysis failed. Please try again.');
    } finally {
      setRunning(false);
    }
  };

  const proceedFromComplaint = () => {
    if (!triageData.complaint_category) { toast.error('Please select a complaint category'); return; }
    setTriageStep('category_questions');
  };

  const finalizeTriage = () => {
    if (triageResult) onTriageComplete(triageResult);
  };

  const getCategoryQuestions = () => {
    const cat = triageData.complaint_category;
    const questions = {
      fever: ['How many days has the fever lasted?', 'Temperature (if known)?', 'Any vomiting?', 'Any rash?', 'Difficulty breathing?', 'Able to eat/drink?', 'Is patient under age 5?'],
      cough_breathing: ['How long has the cough lasted?', 'Difficulty breathing (yes/no)?', 'Any chest pain?', 'Any wheezing?', 'Any fever?', 'History of asthma?'],
      pain: ['Where is the pain?', 'Severity (1–10)?', 'Duration?', 'Sudden or gradual onset?', 'Any associated symptoms?'],
      diarrhea_vomiting: ['How many days?', 'Any blood in stool?', 'Vomiting (yes/no)?', 'Can drink fluids (yes/no)?', 'Any fever?'],
      pregnancy: ['Weeks pregnant?', 'Any bleeding?', 'Any pain?', 'Normal fetal movement?', 'History of high BP?'],
      child_illness: ['Age of child?', 'Fever present?', 'Feeding normally?', 'Active/responsive?', 'Breathing normally?'],
      injury: ['When did injury occur?', 'Active bleeding?', 'Suspected broken bone?', 'Head injury (yes/no)?', 'Conscious and responsive?'],
      mental_health: ['Feeling hopeless (yes/no)?', 'Thoughts of self-harm (yes/no)?', 'Sleeping normally?', 'Eating normally?', 'Any confusion?'],
    };
    return questions[cat] || ['Please describe your main symptoms in detail.'];
  };

  // ─── STEP: DEMOGRAPHICS ─────────────────────────────────────────────────
  if (triageStep === 'demographics') {
    return (
      <Card className="p-6 border-0 shadow-sm border-l-4 border-l-primary">
        <p className="text-xs font-bold text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs">T1</span>
          TRIAGE — Step 1: Patient Demographics
        </p>
        <p className="text-xs text-muted-foreground italic mb-4">"I need to ask a few quick questions before we continue..."</p>

        <div className="grid grid-cols-2 gap-4 mb-4">
          <div>
            <Label className="text-xs">Age *</Label>
            <input className="mt-1 w-full border border-input rounded-md px-3 py-1.5 text-sm bg-background"
              type="number" placeholder="Years old"
              value={triageData.patient_age}
              onChange={e => setTriageData(d => ({ ...d, patient_age: e.target.value }))} />
          </div>
          <div>
            <Label className="text-xs">Sex *</Label>
            <Select value={triageData.patient_sex} onValueChange={v => setTriageData(d => ({ ...d, patient_sex: v }))}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select sex" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Male">Male</SelectItem>
                <SelectItem value="Female">Female</SelectItem>
                <SelectItem value="Other">Other</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">District / Village</Label>
            <input className="mt-1 w-full border border-input rounded-md px-3 py-1.5 text-sm bg-background"
              placeholder="e.g. Gasabo, Kigali"
              value={triageData.location}
              onChange={e => setTriageData(d => ({ ...d, location: e.target.value }))} />
          </div>
          <div>
            <Label className="text-xs">Pregnancy Status</Label>
            <Select value={triageData.pregnancy_status} onValueChange={v => setTriageData(d => ({ ...d, pregnancy_status: v }))}>
              <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="no">Not Pregnant / N/A</SelectItem>
                <SelectItem value="yes">Currently Pregnant</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="mb-4">
          <Label className="text-xs mb-2 block">Chronic Conditions (select all that apply)</Label>
          <div className="flex flex-wrap gap-2">
            {CHRONIC_OPTIONS.map(c => (
              <label key={c} className="flex items-center gap-1.5 cursor-pointer text-xs bg-muted/50 px-2.5 py-1.5 rounded-lg border border-border hover:bg-muted transition-colors">
                <Checkbox
                  checked={triageData.chronic_conditions.includes(c)}
                  onCheckedChange={() => toggleChronic(c)}
                  className="w-3 h-3"
                />
                {c}
              </label>
            ))}
          </div>
        </div>

        <Button className="gap-2" onClick={() => setTriageStep('emergency')} disabled={!triageData.patient_age || !triageData.patient_sex}>
          Next: Emergency Screening <ArrowRight className="w-4 h-4" />
        </Button>
      </Card>
    );
  }

  // ─── STEP: EMERGENCY SCREENING ──────────────────────────────────────────
  if (triageStep === 'emergency') {
    return (
      <Card className="p-6 border-0 shadow-sm border-l-4 border-l-destructive">
        <p className="text-xs font-bold text-destructive uppercase tracking-wider mb-2 flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-destructive text-white flex items-center justify-center text-xs">T2</span>
          TRIAGE — Step 2: Emergency Screening
        </p>
        <p className="text-xs text-muted-foreground italic mb-4">"I need to ask a few urgent questions to understand if you need immediate care."</p>

        <div className="space-y-2 mb-5">
          {EMERGENCY_QUESTIONS.map((q, i) => (
            <label key={i} className={`flex items-start gap-3 p-2.5 rounded-lg cursor-pointer transition-colors ${triageData.emergency_answers[i] ? 'bg-destructive/10 border border-destructive/20' : 'bg-muted/30 hover:bg-muted/60'}`}>
              <Checkbox
                checked={triageData.emergency_answers[i]}
                onCheckedChange={(checked) => {
                  const updated = [...triageData.emergency_answers];
                  updated[i] = !!checked;
                  setTriageData(d => ({ ...d, emergency_answers: updated }));
                }}
                className="mt-0.5"
              />
              <span className={`text-xs ${triageData.emergency_answers[i] ? 'text-destructive font-semibold' : 'text-foreground'}`}>{q}</span>
            </label>
          ))}
        </div>

        {triageData.emergency_answers.some(Boolean) && (
          <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg mb-4 flex items-start gap-2">
            <AlertTriangle className="w-4 h-4 text-destructive mt-0.5 shrink-0" />
            <p className="text-xs text-destructive font-semibold">⚠️ One or more emergency flags detected. AI will classify as CRITICAL and route to HOSPITAL.</p>
          </div>
        )}

        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setTriageStep('demographics')}>← Back</Button>
          <Button
            className={`gap-2 ${triageData.emergency_answers.some(Boolean) ? 'bg-destructive hover:bg-destructive/90' : ''}`}
            onClick={proceedFromEmergency}
            disabled={running}
          >
            {running ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : (
              triageData.emergency_answers.some(Boolean)
                ? <><ShieldAlert className="w-4 h-4" /> Run Emergency Triage</>
                : <>Continue to Complaint <ArrowRight className="w-4 h-4" /></>
            )}
          </Button>
        </div>
      </Card>
    );
  }

  // ─── STEP: COMPLAINT CATEGORY ───────────────────────────────────────────
  if (triageStep === 'complaint') {
    return (
      <Card className="p-6 border-0 shadow-sm border-l-4 border-l-primary">
        <p className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs">T3</span>
          TRIAGE — Step 3: Main Complaint
        </p>
        <p className="text-xs text-muted-foreground italic mb-4">"What is your main health problem today?"</p>

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mb-5">
          {COMPLAINT_CATEGORIES.map(c => (
            <button
              key={c.value}
              onClick={() => setTriageData(d => ({ ...d, complaint_category: c.value }))}
              className={`p-2.5 rounded-lg text-xs text-left border-2 transition-all ${triageData.complaint_category === c.value ? 'border-primary bg-primary/10 font-semibold' : 'border-border hover:border-primary/40 bg-muted/30'}`}
            >
              {c.label}
            </button>
          ))}
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setTriageStep('emergency')}>← Back</Button>
          <Button className="gap-2" onClick={proceedFromComplaint} disabled={!triageData.complaint_category}>
            Next: Category Questions <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      </Card>
    );
  }

  // ─── STEP: CATEGORY QUESTIONS ───────────────────────────────────────────
  if (triageStep === 'category_questions') {
    const questions = getCategoryQuestions();
    return (
      <Card className="p-6 border-0 shadow-sm border-l-4 border-l-primary">
        <p className="text-xs font-bold text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs">T4</span>
          TRIAGE — Step 4: {COMPLAINT_CATEGORIES.find(c => c.value === triageData.complaint_category)?.label} Questions
        </p>

        <div className="space-y-3 mb-5">
          {questions.map((q, i) => (
            <div key={i}>
              <Label className="text-xs">{q}</Label>
              <input
                className="mt-1 w-full border border-input rounded-md px-3 py-1.5 text-sm bg-background"
                placeholder="Patient's answer..."
                value={triageData.category_answers[i] || ''}
                onChange={e => setTriageData(d => ({ ...d, category_answers: { ...d.category_answers, [i]: e.target.value } }))}
              />
            </div>
          ))}
        </div>

        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setTriageStep('complaint')}>← Back</Button>
          <Button className="gap-2" onClick={() => runAITriage(triageData)} disabled={running}>
            {running ? <><Loader2 className="w-4 h-4 animate-spin" /> Running AI Triage...</> : <><Sparkles className="w-4 h-4" /> Run AI Triage Analysis</>}
          </Button>
        </div>
      </Card>
    );
  }

  // ─── STEP: RESULT ────────────────────────────────────────────────────────
  if (triageStep === 'result' && triageResult) {
    const level = triageResult.risk_level;
    return (
      <Card className={`p-6 border-0 shadow-sm border-l-4 ${level === 'CRITICAL' || level === 'HIGH' ? 'border-l-destructive' : level === 'MODERATE' ? 'border-l-orange-400' : 'border-l-accent'}`}>
        <p className="text-xs font-bold text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
          <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs">T5</span>
          TRIAGE RESULT — AI Structured Output
        </p>

        {triageResult.is_emergency && (
          <div className="p-3 bg-destructive/10 border border-destructive/20 rounded-lg mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-destructive shrink-0" />
            <p className="text-sm font-bold text-destructive">🚨 EMERGENCY DETECTED — Immediate hospital routing required</p>
          </div>
        )}

        <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 mb-4">
          <div className={`p-3 rounded-lg border text-center ${RISK_COLORS[level] || 'bg-muted/40'}`}>
            <p className="text-xs font-semibold opacity-70">Risk Level</p>
            <p className="text-lg font-black">{level}</p>
          </div>
          <div className="p-3 rounded-lg bg-muted/40 text-center">
            <p className="text-xs font-semibold text-muted-foreground">Risk Score</p>
            <p className="text-lg font-black">{triageResult.risk_score}</p>
          </div>
          <div className="p-3 rounded-lg bg-primary/10 text-center">
            <p className="text-xs font-semibold text-primary">Priority</p>
            <p className="text-sm font-bold text-primary">{triageResult.priority}</p>
          </div>
          <div className="p-3 rounded-lg bg-muted/40 col-span-2">
            <p className="text-xs font-semibold text-muted-foreground">Recommended Route</p>
            <p className="text-sm font-bold">{triageResult.route}</p>
          </div>
          <div className="p-3 rounded-lg bg-muted/40 text-center">
            <p className="text-xs font-semibold text-muted-foreground">AI Confidence</p>
            <p className="text-sm font-bold">{triageResult.confidence ? `${Math.round(triageResult.confidence * 100)}%` : 'N/A'}</p>
          </div>
        </div>

        {triageResult.red_flags?.length > 0 && (
          <div className="mb-3">
            <p className="text-xs font-semibold text-destructive mb-1 flex items-center gap-1"><AlertTriangle className="w-3 h-3" />Red Flags</p>
            <div className="flex flex-wrap gap-1">
              {triageResult.red_flags.map((f, i) => (
                <Badge key={i} className="bg-destructive/10 text-destructive text-xs">{f}</Badge>
              ))}
            </div>
          </div>
        )}

        <div className="p-3 bg-muted/40 rounded-lg mb-4">
          <p className="text-xs font-semibold text-muted-foreground mb-1 flex items-center gap-1"><Activity className="w-3 h-3" />OpenMRS Summary</p>
          <p className="text-xs text-foreground">{triageResult.summary || triageResult.reason}</p>
        </div>

        <Button className="w-full gap-2" onClick={finalizeTriage}>
          <ArrowRight className="w-4 h-4" /> Proceed to Routing →
        </Button>
      </Card>
    );
  }

  return null;
}