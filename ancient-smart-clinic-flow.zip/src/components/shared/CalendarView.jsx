import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { format, startOfMonth, endOfMonth, startOfWeek, endOfWeek, addDays, isSameMonth, isSameDay, addMonths, subMonths } from 'date-fns';

/**
 * Generic calendar view.
 * items: array of records
 * getDate: fn(item) => Date
 * getLabel: fn(item) => string (short label for cell)
 * getBadgeClass: fn(item) => string (tailwind classes for badge color)
 * onItemClick: fn(item) => void
 */
export default function CalendarView({ items = [], getDate, getLabel, getBadgeClass, onItemClick }) {
  const [currentMonth, setCurrentMonth] = useState(new Date());

  const monthStart = startOfMonth(currentMonth);
  const monthEnd = endOfMonth(currentMonth);
  const calStart = startOfWeek(monthStart, { weekStartsOn: 1 });
  const calEnd = endOfWeek(monthEnd, { weekStartsOn: 1 });

  const days = [];
  let day = calStart;
  while (day <= calEnd) {
    days.push(day);
    day = addDays(day, 1);
  }

  const getItemsForDay = (d) =>
    items.filter(item => {
      try {
        const itemDate = getDate(item);
        return itemDate && isSameDay(new Date(itemDate), d);
      } catch { return false; }
    });

  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  return (
    <div className="bg-card rounded-xl border border-border shadow-sm overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-3 border-b border-border">
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(subMonths(currentMonth, 1))}>
          <ChevronLeft className="w-4 h-4" />
        </Button>
        <p className="text-sm font-semibold">{format(currentMonth, 'MMMM yyyy')}</p>
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setCurrentMonth(addMonths(currentMonth, 1))}>
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Day headers */}
      <div className="grid grid-cols-7 border-b border-border">
        {weekDays.map(d => (
          <div key={d} className="text-center py-2 text-xs font-semibold text-muted-foreground">
            {d}
          </div>
        ))}
      </div>

      {/* Calendar grid */}
      <div className="grid grid-cols-7">
        {days.map((d, idx) => {
          const dayItems = getItemsForDay(d);
          const isToday = isSameDay(d, new Date());
          const isCurrentMonth = isSameMonth(d, currentMonth);

          return (
            <div
              key={idx}
              className={`min-h-[80px] p-1.5 border-b border-r border-border/50 ${!isCurrentMonth ? 'bg-muted/30' : ''}`}
            >
              <p className={`text-xs font-medium mb-1 w-5 h-5 flex items-center justify-center rounded-full
                ${isToday ? 'bg-primary text-primary-foreground' : isCurrentMonth ? 'text-foreground' : 'text-muted-foreground'}`}>
                {format(d, 'd')}
              </p>
              <div className="space-y-0.5">
                {dayItems.slice(0, 3).map((item, i) => (
                  <div
                    key={i}
                    onClick={() => onItemClick && onItemClick(item)}
                    className={`text-[10px] leading-tight px-1.5 py-0.5 rounded cursor-pointer hover:opacity-80 truncate ${getBadgeClass ? getBadgeClass(item) : 'bg-primary/10 text-primary'}`}
                  >
                    {getLabel(item)}
                  </div>
                ))}
                {dayItems.length > 3 && (
                  <p className="text-[10px] text-muted-foreground px-1">+{dayItems.length - 3} more</p>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}