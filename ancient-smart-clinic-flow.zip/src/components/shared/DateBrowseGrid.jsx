import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ChevronLeft, ChevronRight, Calendar } from 'lucide-react';
import { format, isSameDay, addDays, subDays } from 'date-fns';

/**
 * Generic date-browse grid.
 * items: all records
 * getDate: fn(item) => date string
 * renderCard: fn(item) => JSX
 * emptyMessage: string
 */
export default function DateBrowseGrid({ items = [], getDate, renderCard, emptyMessage = 'No records for this date.', gridCols = null }) {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [showPicker, setShowPicker] = useState(false);

  const dayItems = items.filter(item => {
    const d = getDate(item);
    if (!d) return false;
    try { return isSameDay(new Date(d), selectedDate); } catch { return false; }
  });

  const isToday = isSameDay(selectedDate, new Date());

  return (
    <div className="space-y-4">
      {/* Date Navigator */}
      <div className="flex items-center gap-2 bg-card border border-border rounded-xl px-4 py-3 shadow-sm">
        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedDate(subDays(selectedDate, 1))}>
          <ChevronLeft className="w-4 h-4" />
        </Button>

        <div className="flex-1 flex items-center justify-center gap-3">
          <p className="text-sm font-semibold">
            {isToday ? 'Today' : format(selectedDate, 'EEEE, MMMM d, yyyy')}
          </p>
          {!isToday && (
            <Button variant="outline" size="sm" className="h-7 text-xs" onClick={() => setSelectedDate(new Date())}>
              Today
            </Button>
          )}
          <div className="relative">
            <Button
              variant="outline"
              size="sm"
              className="h-7 text-xs gap-1.5"
              onClick={() => setShowPicker(v => !v)}
            >
              <Calendar className="w-3.5 h-3.5" /> Pick Date
            </Button>
            {showPicker && (
              <div className="absolute top-8 left-0 z-50 bg-card border border-border rounded-lg shadow-lg p-2">
                <Input
                  type="date"
                  className="h-8 text-xs"
                  value={format(selectedDate, 'yyyy-MM-dd')}
                  onChange={e => {
                    if (e.target.value) {
                      setSelectedDate(new Date(e.target.value + 'T00:00:00'));
                      setShowPicker(false);
                    }
                  }}
                />
              </div>
            )}
          </div>
        </div>

        <Button variant="ghost" size="icon" className="h-8 w-8" onClick={() => setSelectedDate(addDays(selectedDate, 1))}>
          <ChevronRight className="w-4 h-4" />
        </Button>
      </div>

      {/* Count */}
      <p className="text-sm font-medium text-primary">
        {dayItems.length} record{dayItems.length !== 1 ? 's' : ''} on {isToday ? 'today' : format(selectedDate, 'MMM d, yyyy')}
      </p>

      {/* Cards */}
      {dayItems.length === 0 ? (
        <p className="text-center py-12 text-muted-foreground text-sm">{emptyMessage}</p>
      ) : gridCols ? (
        <div className={`grid gap-4 ${gridCols}`}>
          {dayItems.map((item, i) => (
            <div key={item.id || i}>{renderCard(item)}</div>
          ))}
        </div>
      ) : (
        <div className="space-y-3">
          {dayItems.map((item, i) => (
            <div key={item.id || i}>{renderCard(item)}</div>
          ))}
        </div>
      )}
    </div>
  );
}