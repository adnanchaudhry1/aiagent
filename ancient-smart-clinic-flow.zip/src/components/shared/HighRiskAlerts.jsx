import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, ChevronDown, ChevronUp, ArrowRight } from 'lucide-react';
import { useNavigate } from 'react-router-dom';

export default function HighRiskAlerts({ riskPatients }) {
  const [expanded, setExpanded] = useState(true);
  const navigate = useNavigate();

  if (!riskPatients || riskPatients.length === 0) return null;

  const criticalCount = riskPatients.filter(p => p.severity === 'critical').length;

  const goToPatient = (patientId) => {
    if (patientId) navigate(`/patients/${patientId}`);
  };

  return (
    <Card className="border-0 shadow-sm border-l-4 border-l-destructive bg-destructive/5">
      <div
        className="flex items-center justify-between p-4 cursor-pointer select-none"
        onClick={() => setExpanded(e => !e)}
      >
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-destructive/15 flex items-center justify-center">
            <AlertTriangle className="w-4 h-4 text-destructive animate-pulse" />
          </div>
          <div>
            <p className="text-sm font-bold text-destructive">
              High-Risk Patient Alerts — {riskPatients.length} patient{riskPatients.length > 1 ? 's' : ''} flagged
            </p>
            <p className="text-xs text-muted-foreground">
              {criticalCount > 0 && <span className="text-destructive font-semibold">{criticalCount} critical · </span>}
              Based on ICD-10 codes, lab results and clinical assessments
            </p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge className="bg-destructive text-white text-xs">{riskPatients.length}</Badge>
          {expanded ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
        </div>
      </div>

      {expanded && (
        <div className="px-4 pb-4 space-y-2">
          {riskPatients.slice(0, 5).map(p => (
            <div
              key={p.patientId}
              className={`flex items-start justify-between p-3 rounded-lg border transition-colors ${
                p.severity === 'critical'
                  ? 'bg-destructive/10 border-destructive/20 hover:bg-destructive/15'
                  : 'bg-orange-50 border-orange-200 hover:bg-orange-100'
              }`}
            >
              <div className="flex items-start gap-3 flex-1 min-w-0">
                <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${
                  p.severity === 'critical' ? 'bg-destructive/20' : 'bg-orange-100'
                }`}>
                  <span className={`text-sm font-bold ${p.severity === 'critical' ? 'text-destructive' : 'text-orange-600'}`}>
                    {p.patientName?.[0]?.toUpperCase() || '?'}
                  </span>
                </div>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    {/* Name — clickable separately */}
                    <button
                      className={`text-sm font-semibold hover:underline text-left ${
                        p.severity === 'critical' ? 'text-destructive' : 'text-orange-800'
                      }`}
                      onClick={() => goToPatient(p.patientId)}
                    >
                      {p.patientName}
                    </button>
                    <Badge className={`text-xs ${
                      p.severity === 'critical'
                        ? 'bg-destructive/15 text-destructive border-0'
                        : 'bg-orange-100 text-orange-700 border-0'
                    }`}>
                      {p.severity === 'critical' ? '🔴 Critical' : '🟠 High Risk'}
                    </Badge>
                    {p.district && <span className="text-xs text-muted-foreground">{p.district}</span>}
                  </div>
                  <div className="flex flex-wrap gap-1.5 mt-1.5">
                    {p.flags.slice(0, 3).map((f, i) => (
                      <Badge
                        key={i}
                        variant="outline"
                        className={`text-xs ${
                          f.severity === 'critical'
                            ? 'border-destructive/40 text-destructive bg-destructive/5'
                            : 'border-orange-300 text-orange-700 bg-orange-50'
                        }`}
                      >
                        {f.type === 'ICD-10'
                          ? <><span className="font-mono">{f.code}</span> · {f.description}</>
                          : f.description
                        }
                      </Badge>
                    ))}
                    {p.flags.length > 3 && (
                      <Badge variant="secondary" className="text-xs">+{p.flags.length - 3} more</Badge>
                    )}
                  </div>
                </div>
              </div>
              <Button
                size="sm"
                variant="outline"
                className="text-xs h-8 px-3 gap-1 shrink-0 ml-3 font-semibold"
                onClick={() => goToPatient(p.patientId)}
              >
                View <ArrowRight className="w-3 h-3" />
              </Button>
            </div>
          ))}

          {riskPatients.length > 5 && (
            <Button
              variant="ghost"
              size="sm"
              className="w-full text-xs text-destructive hover:bg-destructive/5 gap-1 mt-1"
              onClick={() => navigate('/flagged-patients')}
            >
              View all {riskPatients.length} flagged patients <ArrowRight className="w-3 h-3" />
            </Button>
          )}
        </div>
      )}
    </Card>
  );
}