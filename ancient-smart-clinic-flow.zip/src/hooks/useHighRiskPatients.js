import { useMemo } from 'react';

// Serious ICD-10 code prefixes that indicate critical/high-risk conditions
const HIGH_RISK_ICD_PREFIXES = [
  'I21', 'I22', // Acute myocardial infarction
  'I60', 'I61', 'I62', 'I63', 'I64', // Stroke / cerebral hemorrhage
  'I50', // Heart failure
  'J96', // Respiratory failure
  'N17', 'N18', // Acute / chronic kidney failure
  'K72', // Hepatic failure
  'C', // All cancers
  'A90', 'A91', // Dengue hemorrhagic fever
  'B50', 'B51', 'B52', 'B53', 'B54', // Malaria (severe)
  'A15', 'A16', 'A17', 'A18', 'A19', // Tuberculosis
  'B20', 'B21', 'B22', 'B23', 'B24', // HIV disease
  'A00', // Cholera
  'A01', // Typhoid
  'J12', 'J18', // Severe pneumonia
  'E10', 'E11', // Diabetes (Type 1/2)
  'O15', // Eclampsia
  'P07', // Extremely preterm / low birth weight
  'S06', // Intracranial injuries
  'T71', // Asphyxiation
  'J45', // Asthma
];

// Lab keywords in assessment/plan that indicate critical results
const HIGH_RISK_LAB_KEYWORDS = [
  'sepsis', 'septicemia', 'shock', 'critical', 'emergency',
  'hemorrhage', 'hemorrhagic', 'acute kidney', 'renal failure', 'liver failure',
  'respiratory failure', 'cardiac arrest', 'heart failure', 'myocardial',
  'stroke', 'cerebral', 'eclampsia', 'severe malaria', 'meningitis',
  'encephalitis', 'hiv', 'tuberculosis', 'cancer', 'tumor', 'malignant',
  'leukemia', 'lymphoma', 'severe anemia', 'severe hypoglycemia', 'severe hyperglycemia',
  'pancreatitis', 'peritonitis', 'pulmonary embolism', 'cholera', 'typhoid',
];

function getRiskFlags(encounter) {
  const flags = [];

  // 1. Check ICD-10 codes first (most reliable)
  if (encounter.icd_codes) {
    try {
      const codes = JSON.parse(encounter.icd_codes);
      if (Array.isArray(codes)) {
        codes.forEach(c => {
          const code = (c.code || c).toUpperCase().trim();
          const matched = HIGH_RISK_ICD_PREFIXES.find(prefix => code.startsWith(prefix));
          if (matched) {
            flags.push({
              type: 'ICD-10',
              code: c.code || c,
              description: c.description || code,
              severity: 'critical',
            });
          }
        });
      }
    } catch {}
  }

  // 2. Check clinical text for keywords (only if no ICD flags yet, to reduce noise)
  if (flags.length === 0) {
    const clinicalText = `${encounter.assessment || ''} ${encounter.plan || ''} ${encounter.chief_complaint || ''} ${encounter.subjective || ''}`.toLowerCase();
    HIGH_RISK_LAB_KEYWORDS.forEach(kw => {
      if (clinicalText.includes(kw)) {
        flags.push({
          type: 'Clinical',
          code: kw,
          description: kw.charAt(0).toUpperCase() + kw.slice(1),
          severity: 'high',
        });
      }
    });
  }

  // 3. Check lab_orders for STAT urgency
  if (encounter.lab_orders) {
    try {
      const labs = JSON.parse(encounter.lab_orders);
      if (Array.isArray(labs)) {
        labs.forEach(l => {
          const urgency = l.urgency || '';
          if (urgency === 'STAT') {
            const existing = flags.some(f => f.code === (l.test || l.test_name));
            if (!existing) {
              flags.push({
                type: 'Lab',
                code: l.test || l.test_name || 'STAT Lab',
                description: `STAT: ${l.test || l.test_name || 'Lab'}`,
                severity: 'high',
              });
            }
          }
        });
      }
    } catch {}
  }

  return flags;
}

/**
 * Given all encounters and patients list,
 * returns a deduplicated list of high-risk patient records with their flags.
 */
export function useHighRiskPatients(encounters = [], patients = []) {
  return useMemo(() => {
    const riskMap = {};

    encounters.forEach(enc => {
      const pid = enc.patient_id;
      if (!pid) return; // skip encounters with no patient_id

      const flags = getRiskFlags(enc);
      if (flags.length === 0) return;

      // Always resolve name from patients list first, then enc.patient_name
      const patient = patients.find(p => p.id === pid);
      const resolvedName = patient?.full_name || enc.patient_name || null;

      // Skip if we still can't resolve a name (data not loaded yet)
      if (!resolvedName) return;

      if (!riskMap[pid]) {
        riskMap[pid] = {
          patientId: pid,
          patientName: resolvedName,
          district: patient?.district || '',
          insurance: patient?.insurance_type || '',
          flags: [],
          latestEncounterId: enc.id,
          encounterDate: enc.encounter_date || enc.created_date,
          severity: 'high',
        };
      }

      // Merge flags, deduplicate by code
      flags.forEach(f => {
        if (!riskMap[pid].flags.some(existing => existing.code === f.code)) {
          riskMap[pid].flags.push(f);
        }
      });

      // Upgrade severity if any ICD flag is critical
      if (flags.some(f => f.severity === 'critical')) {
        riskMap[pid].severity = 'critical';
      }
    });

    return Object.values(riskMap).sort((a, b) => {
      if (a.severity === 'critical' && b.severity !== 'critical') return -1;
      if (b.severity === 'critical' && a.severity !== 'critical') return 1;
      return new Date(b.encounterDate) - new Date(a.encounterDate);
    });
  }, [encounters, patients]);
}

/**
 * For a single patient — returns their risk flags from all their encounters.
 */
export function usePatientRiskFlags(encounters = []) {
  return useMemo(() => {
    const allFlags = [];
    encounters.forEach(enc => {
      const flags = getRiskFlags(enc);
      flags.forEach(f => {
        if (!allFlags.some(existing => existing.code === f.code)) {
          allFlags.push({ ...f, encounterId: enc.id, encounterDate: enc.encounter_date || enc.created_date });
        }
      });
    });
    const hasCritical = allFlags.some(f => f.severity === 'critical');
    return {
      flags: allFlags,
      severity: hasCritical ? 'critical' : allFlags.length > 0 ? 'high' : null,
    };
  }, [encounters]);
}