import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';
import { Loader2, Sparkles, BarChart3, TrendingUp, ShieldCheck, Users, Stethoscope, AlertTriangle, CheckCircle2, FileText } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import StatCard from '@/components/shared/StatCard';

const COLORS = ['hsl(168,70%,42%)', 'hsl(199,89%,38%)', 'hsl(0,72%,51%)', 'hsl(24,95%,53%)', 'hsl(262,52%,47%)'];

export default function AIReports() {
  const [reportType, setReportType] = useState('');
  const [generating, setGenerating] = useState(false);
  const [report, setReport] = useState(null);

  const { data: patients = [] } = useQuery({ queryKey: ['patients'], queryFn: () => base44.entities.Patient.list() });
  const { data: appointments = [] } = useQuery({ queryKey: ['appointments'], queryFn: () => base44.entities.Appointment.list() });
  const { data: encounters = [] } = useQuery({ queryKey: ['encounters'], queryFn: () => base44.entities.Encounter.list() });
  const { data: claims = [] } = useQuery({ queryKey: ['claims'], queryFn: () => base44.entities.InsuranceClaim.list() });

  const generateReport = async () => {
    if (!reportType) return;
    setGenerating(true);
    setReport(null);
    try {
      const claimStats = {
        total: claims.length,
        approved: claims.filter(c => c.status === 'Approved').length,
        denied: claims.filter(c => c.status === 'Denied').length,
        pending: claims.filter(c => c.status === 'Submitted' || c.status === 'Under Review').length,
        draft: claims.filter(c => c.status === 'Draft').length,
        totalCharged: claims.reduce((s, c) => s + (c.charged_amount || 0), 0),
      };

      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are an AI reporting system for Rwanda's Murava AI clinical platform. Generate a comprehensive ${reportType} report.

System Data:
- Total Patients: ${patients.length}
- Total Appointments: ${appointments.length} (Scheduled: ${appointments.filter(a=>a.status==='Scheduled').length}, Completed: ${appointments.filter(a=>a.status==='Completed').length})
- Total Encounters: ${encounters.length} (Active: ${encounters.filter(e=>e.status==='In Progress').length}, Finalized: ${encounters.filter(e=>e.status==='Finalized'||e.status==='Doctor Approved').length})
- Insurance Claims: ${JSON.stringify(claimStats)}
- Insurance Types: ${[...new Set(patients.map(p=>p.insurance_type).filter(Boolean))].join(', ')}
- Districts Covered: ${[...new Set(patients.map(p=>p.district).filter(Boolean))].join(', ')}

Rwanda Healthcare Context: RSSB (RAMA), MMI, Mutuelle de Santé. Use Rwanda MOH reporting standards.

Generate a full ${reportType} report with insights, trends, recommendations, fraud risk analysis, and compliance status per Rwanda's health regulations.`,
        response_json_schema: {
          type: 'object',
          properties: {
            report_title: { type: 'string' },
            period: { type: 'string' },
            executive_summary: { type: 'string' },
            key_metrics: { type: 'array', items: { type: 'object', properties: { label: { type: 'string' }, value: { type: 'string' }, trend: { type: 'string' }, status: { type: 'string' } } } },
            insights: { type: 'array', items: { type: 'string' } },
            fraud_risk_findings: { type: 'array', items: { type: 'string' } },
            recommendations: { type: 'array', items: { type: 'string' } },
            compliance_status: { type: 'string' },
            compliance_notes: { type: 'array', items: { type: 'string' } },
            action_items: { type: 'array', items: { type: 'object', properties: { priority: { type: 'string' }, action: { type: 'string' } } } },
          }
        }
      });
      // Build chart data based on report type
      const chartData = buildChartData(reportType);
      setReport({ ...result, chartData, reportType });
    } catch (e) {
      alert('Report generation failed. Please try again.');
    } finally {
      setGenerating(false);
    }
  };

  const buildChartData = (type) => {
    if (type.includes('Claims') || type.includes('Revenue') || type.includes('Fraud')) {
      return {
        type: 'pie',
        title: 'Claim Status Breakdown',
        data: [
          { name: 'Approved', value: claims.filter(c=>c.status==='Approved').length, color: '#22c55e' },
          { name: 'Denied', value: claims.filter(c=>c.status==='Denied').length, color: '#ef4444' },
          { name: 'Pending', value: claims.filter(c=>c.status==='Submitted'||c.status==='Under Review').length, color: '#f59e0b' },
          { name: 'Draft', value: claims.filter(c=>c.status==='Draft').length, color: '#94a3b8' },
        ].filter(d=>d.value>0),
        bar: {
          title: 'Charged Amount by Insurer',
          data: ['RSSB (RAMA)','MMI','Mutuelle de Santé','Private','None'].map(ins => ({
            name: ins.split(' ')[0],
            value: claims.filter(c=>c.insurance_type===ins).reduce((s,c)=>s+(c.charged_amount||0),0)
          })).filter(d=>d.value>0),
          color: '#0ea5e9',
        }
      };
    }
    if (type.includes('Demographics') || type.includes('Patient')) {
      const districts = [...new Set(patients.map(p=>p.district).filter(Boolean))];
      return {
        type: 'bar',
        title: 'Patients by District',
        data: districts.map(d => ({ name: d, value: patients.filter(p=>p.district===d).length, color: COLORS[districts.indexOf(d)%COLORS.length] })),
        pie: {
          title: 'Insurance Distribution',
          data: ['RSSB (RAMA)','MMI','Mutuelle de Santé','Private','None'].map((ins,i) => ({
            name: ins.split(' ')[0], value: patients.filter(p=>p.insurance_type===ins).length, color: COLORS[i%COLORS.length]
          })).filter(d=>d.value>0)
        }
      };
    }
    if (type.includes('Disease') || type.includes('Surveillance')) {
      const diagMap = {};
      encounters.forEach(e => {
        if (e.icd_codes) { try { JSON.parse(e.icd_codes).forEach(c => { diagMap[c.description||c.code] = (diagMap[c.description||c.code]||0)+1; }); } catch {} }
      });
      const diagData = Object.entries(diagMap).sort((a,b)=>b[1]-a[1]).slice(0,8).map(([name,value],i)=>({name:name.slice(0,20),value,color:COLORS[i%COLORS.length]}));
      return { type: 'bar', title: 'Top Diagnoses', data: diagData, color: '#8b5cf6' };
    }
    // Default — encounter/clinical
    return {
      type: 'multi',
      bar: { title: 'Encounter Status', data: [
        { name: 'In Progress', value: encounters.filter(e=>e.status==='In Progress').length, color: '#f59e0b' },
        { name: 'AI Review', value: encounters.filter(e=>e.status==='AI Review').length, color: '#0ea5e9' },
        { name: 'Approved', value: encounters.filter(e=>e.status==='Doctor Approved').length, color: '#22c55e' },
        { name: 'Finalized', value: encounters.filter(e=>e.status==='Finalized').length, color: '#8b5cf6' },
      ].filter(d=>d.value>0)},
      pie: { title: 'Appointment Status', data: [
        { name: 'Scheduled', value: appointments.filter(a=>a.status==='Scheduled').length, color: '#0ea5e9' },
        { name: 'Completed', value: appointments.filter(a=>a.status==='Completed').length, color: '#22c55e' },
        { name: 'Cancelled', value: appointments.filter(a=>a.status==='Cancelled').length, color: '#ef4444' },
      ].filter(d=>d.value>0)},
    };
  };

  // Chart data derived from real data
  const claimStatusData = [
    { name: 'Approved', value: claims.filter(c=>c.status==='Approved').length, color: COLORS[0] },
    { name: 'Pending', value: claims.filter(c=>c.status==='Submitted'||c.status==='Under Review').length, color: COLORS[1] },
    { name: 'Denied', value: claims.filter(c=>c.status==='Denied').length, color: COLORS[2] },
    { name: 'Draft', value: claims.filter(c=>c.status==='Draft').length, color: COLORS[3] },
  ].filter(d => d.value > 0);

  const insuranceDistribution = [...new Set(patients.map(p => p.insurance_type).filter(Boolean))].map(ins => ({
    name: ins, value: patients.filter(p => p.insurance_type === ins).length
  }));

  const apptStatusData = [
    { name: 'Scheduled', value: appointments.filter(a=>a.status==='Scheduled').length },
    { name: 'Completed', value: appointments.filter(a=>a.status==='Completed').length },
    { name: 'Cancelled', value: appointments.filter(a=>a.status==='Cancelled').length },
    { name: 'In Progress', value: appointments.filter(a=>a.status==='In Progress').length },
  ].filter(d => d.value > 0);

  return (
    <div className="space-y-6 max-w-7xl">
      <PageHeader title="AI Reports & Analytics" subtitle="Rwanda MOH-aligned reporting with AI insights — Murava AI" />

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <StatCard title="Total Patients" value={patients.length} icon={Users} color="primary" />
        <StatCard title="Total Encounters" value={encounters.length} icon={Stethoscope} color="accent" />
        <StatCard title="Total Claims" value={claims.length} icon={ShieldCheck} color="chart3" />
        <StatCard title="Claim Approval Rate" value={claims.length ? `${Math.round(claims.filter(c=>c.status==='Approved').length/claims.length*100)}%` : '—'} icon={TrendingUp} color="chart4" />
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {claimStatusData.length > 0 && (
          <Card className="p-5 border-0 shadow-sm">
            <p className="text-sm font-semibold mb-3">Claim Status Distribution</p>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie data={claimStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" strokeWidth={0}>
                  {claimStatusData.map((e, i) => <Cell key={i} fill={e.color} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="flex flex-wrap justify-center gap-3 mt-2">
              {claimStatusData.map((d, i) => (
                <div key={i} className="flex items-center gap-1 text-xs text-muted-foreground">
                  <span className="w-2 h-2 rounded-full" style={{background: d.color}} />{d.name} ({d.value})
                </div>
              ))}
            </div>
          </Card>
        )}

        {insuranceDistribution.length > 0 && (
          <Card className="p-5 border-0 shadow-sm">
            <p className="text-sm font-semibold mb-3">Patients by Insurance</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={insuranceDistribution} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis type="number" tick={{fontSize:11}} />
                <YAxis type="category" dataKey="name" tick={{fontSize:10}} width={100} />
                <Tooltip />
                <Bar dataKey="value" fill="hsl(199,89%,38%)" radius={[0,4,4,0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        )}

        {apptStatusData.length > 0 && (
          <Card className="p-5 border-0 shadow-sm">
            <p className="text-sm font-semibold mb-3">Appointment Status</p>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={apptStatusData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" tick={{fontSize:10}} />
                <YAxis tick={{fontSize:11}} />
                <Tooltip />
                <Bar dataKey="value" fill="hsl(168,70%,42%)" radius={[4,4,0,0]} />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        )}
      </div>

      {/* AI Report Generator */}
      <Card className="p-5 border-0 shadow-sm">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-primary" />
          <p className="text-sm font-semibold">AI Report Generator</p>
          <Badge variant="secondary" className="text-xs">Rwanda MOH Standards</Badge>
        </div>
        <div className="flex gap-4 items-end flex-wrap">
          <div className="flex-1 min-w-48">
            <Label className="text-xs">Report Type</Label>
            <Select value={reportType} onValueChange={setReportType}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select report type..." /></SelectTrigger>
              <SelectContent>
                <SelectItem value="Monthly Clinical Summary">Monthly Clinical Summary</SelectItem>
                <SelectItem value="Insurance Claims Analysis">Insurance Claims Analysis</SelectItem>
                <SelectItem value="Revenue Cycle Management (RCM)">Revenue Cycle Management (RCM)</SelectItem>
                <SelectItem value="Fraud Risk Assessment">Fraud Risk Assessment</SelectItem>
                <SelectItem value="Patient Demographics">Patient Demographics</SelectItem>
                <SelectItem value="Encounter Quality Report">Encounter Quality Report</SelectItem>
                <SelectItem value="MOH Rwanda Compliance Report">MOH Rwanda Compliance Report</SelectItem>
                <SelectItem value="Disease Surveillance Report">Disease Surveillance Report</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Button className="gap-2" onClick={generateReport} disabled={generating || !reportType}>
            {generating ? <><Loader2 className="w-4 h-4 animate-spin" />Generating...</> : <><FileText className="w-4 h-4" />Generate AI Report</>}
          </Button>
        </div>
      </Card>

      {report && (
        <div className="space-y-4">
          {/* Dynamic colored charts per report type */}
          {report.chartData && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Left chart */}
              {(report.chartData.type === 'pie' || report.chartData.type === 'multi') && (
                <Card className="p-5 border-0 shadow-sm">
                  <p className="text-sm font-semibold mb-3">{report.chartData.pie?.title || report.chartData.title}</p>
                  <ResponsiveContainer width="100%" height={220}>
                    <PieChart>
                      <Pie data={report.chartData.data || report.chartData.pie?.data} cx="50%" cy="50%" innerRadius={55} outerRadius={85} dataKey="value" strokeWidth={0} label={({name, value}) => `${name}: ${value}`} labelLine={false}>
                        {(report.chartData.data || report.chartData.pie?.data || []).map((e, i) => <Cell key={i} fill={e.color || COLORS[i%COLORS.length]} />)}
                      </Pie>
                      <Tooltip contentStyle={{borderRadius:'8px',border:'none',boxShadow:'0 4px 12px rgba(0,0,0,.1)'}} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="flex flex-wrap justify-center gap-2 mt-1">
                    {(report.chartData.data || report.chartData.pie?.data || []).map((d,i) => (
                      <span key={i} className="flex items-center gap-1 text-xs text-muted-foreground">
                        <span className="w-2.5 h-2.5 rounded-full" style={{background: d.color || COLORS[i%COLORS.length]}} />{d.name} ({d.value})
                      </span>
                    ))}
                  </div>
                </Card>
              )}
              {/* Right chart */}
              {(report.chartData.bar || report.chartData.type === 'bar') && (
                <Card className="p-5 border-0 shadow-sm">
                  <p className="text-sm font-semibold mb-3">{report.chartData.bar?.title || report.chartData.title}</p>
                  <ResponsiveContainer width="100%" height={220}>
                    <BarChart data={report.chartData.bar?.data || report.chartData.data} layout="vertical">
                      <CartesianGrid strokeDasharray="3 3" stroke="#e2e8f0" />
                      <XAxis type="number" tick={{fontSize:11}} />
                      <YAxis type="category" dataKey="name" tick={{fontSize:10}} width={90} />
                      <Tooltip contentStyle={{borderRadius:'8px',border:'none',boxShadow:'0 4px 12px rgba(0,0,0,.1)'}} />
                      <Bar dataKey="value" radius={[0,6,6,0]}>
                        {(report.chartData.bar?.data || report.chartData.data || []).map((e, i) => (
                          <Cell key={i} fill={e.color || report.chartData.bar?.color || report.chartData.color || COLORS[i%COLORS.length]} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </Card>
              )}
            </div>
          )}

          <Card className="p-5 border-0 shadow-sm bg-primary/5">
            <div className="flex items-start justify-between">
              <div>
                <p className="text-base font-bold">{report.report_title}</p>
                <p className="text-xs text-muted-foreground mt-0.5">{report.period}</p>
              </div>
              <Badge className={`text-xs ${report.compliance_status?.includes('Compliant') ? 'bg-accent/10 text-accent' : 'bg-orange-50 text-orange-600'}`}>
                {report.compliance_status}
              </Badge>
            </div>
            <p className="text-sm text-muted-foreground mt-3 leading-relaxed">{report.executive_summary}</p>
          </Card>

          {report.key_metrics?.length > 0 && (
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {report.key_metrics.map((m, i) => (
                <Card key={i} className="p-4 border-0 shadow-sm">
                  <p className="text-xs text-muted-foreground">{m.label}</p>
                  <p className="text-xl font-bold text-primary mt-1">{m.value}</p>
                  {m.trend && <p className={`text-xs mt-1 ${m.status === 'good' ? 'text-accent' : m.status === 'bad' ? 'text-destructive' : 'text-muted-foreground'}`}>{m.trend}</p>}
                </Card>
              ))}
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {report.insights?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  <p className="text-sm font-semibold">Key Insights</p>
                </div>
                <ul className="space-y-2">
                  {report.insights.map((ins, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex gap-2">
                      <span className="text-primary mt-0.5">•</span>{ins}
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {report.fraud_risk_findings?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm border-orange-200 bg-orange-50/50">
                <div className="flex items-center gap-2 mb-3">
                  <AlertTriangle className="w-4 h-4 text-orange-500" />
                  <p className="text-sm font-semibold text-orange-600">Fraud Risk Findings</p>
                </div>
                <ul className="space-y-2">
                  {report.fraud_risk_findings.map((f, i) => (
                    <li key={i} className="text-xs flex gap-2">
                      <span className="text-orange-500 mt-0.5">⚠</span>{f}
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {report.recommendations?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <CheckCircle2 className="w-4 h-4 text-accent" />
                  <p className="text-sm font-semibold">Recommendations</p>
                </div>
                <ul className="space-y-2">
                  {report.recommendations.map((r, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex gap-2">
                      <CheckCircle2 className="w-3 h-3 text-accent shrink-0 mt-0.5" />{r}
                    </li>
                  ))}
                </ul>
              </Card>
            )}

            {report.compliance_notes?.length > 0 && (
              <Card className="p-4 border-0 shadow-sm">
                <div className="flex items-center gap-2 mb-3">
                  <ShieldCheck className="w-4 h-4 text-primary" />
                  <p className="text-sm font-semibold">Rwanda MOH Compliance</p>
                </div>
                <ul className="space-y-2">
                  {report.compliance_notes.map((n, i) => (
                    <li key={i} className="text-xs text-muted-foreground flex gap-2">
                      <span className="text-primary mt-0.5">•</span>{n}
                    </li>
                  ))}
                </ul>
              </Card>
            )}
          </div>

          {report.action_items?.length > 0 && (
            <Card className="p-4 border-0 shadow-sm">
              <p className="text-sm font-semibold mb-3">Action Items</p>
              <div className="space-y-2">
                {report.action_items.map((a, i) => (
                  <div key={i} className="flex items-center gap-3 p-2.5 bg-muted/40 rounded-lg">
                    <Badge className={`text-xs shrink-0 ${a.priority === 'High' ? 'bg-destructive/10 text-destructive' : a.priority === 'Medium' ? 'bg-orange-50 text-orange-600' : 'bg-muted text-muted-foreground'}`}>{a.priority}</Badge>
                    <p className="text-xs">{a.action}</p>
                  </div>
                ))}
              </div>
            </Card>
          )}
        </div>
      )}
    </div>
  );
}