import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Plus, Clock, User, ChevronRight, Mic, PlayCircle, RefreshCw, LayoutGrid, CalendarDays, History } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';
import AppointmentDetailModal from '@/components/appointments/AppointmentDetailModal';
import CalendarView from '@/components/shared/CalendarView';
import DateBrowseGrid from '@/components/shared/DateBrowseGrid';

export default function Appointments() {
  const [showForm, setShowForm] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [viewMode, setViewMode] = useState('grid'); // 'grid' | 'calendar'
   const [formData, setFormData] = useState({ patient_id: '', patient_name: '', appointment_date: '', reason: '', notes: '', status: 'Scheduled' });
   const [selectedAppointment, setSelectedAppointment] = useState(null);
   const queryClient = useQueryClient();
   const navigate = useNavigate();

  const { data: appointments = [], isLoading } = useQuery({
    queryKey: ['appointments'],
    queryFn: () => base44.entities.Appointment.list('-created_date', 100),
    refetchOnMount: true,
    refetchOnWindowFocus: true,
    staleTime: 0,
  });
  const { data: patients = [] } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Appointment.create(data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointments'] });
      setShowForm(false);
      setFormData({ patient_id: '', patient_name: '', appointment_date: '', reason: '', notes: '', status: 'Scheduled' });
    },
  });

  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const upcomingAppointments = appointments.filter(apt => {
    if (!apt.appointment_date) return true;
    return new Date(apt.appointment_date) >= today;
  });

  const pastAppointments = appointments.filter(apt => {
    if (!apt.appointment_date) return false;
    return new Date(apt.appointment_date) < today;
  }).sort((a, b) => new Date(b.appointment_date) - new Date(a.appointment_date));

  const getPatientForApt = (apt) => patients.find(p => p.id === apt.patient_id);

  const handleSummaryUpdated = (updatedApt) => {
    queryClient.invalidateQueries({ queryKey: ['appointments'] });
    setSelectedAppointment(updatedApt);
  };

  const isNew = (item) => {
    if (!item.created_date) return false;
    return (Date.now() - new Date(item.created_date).getTime()) < 24 * 60 * 60 * 1000;
  };

  const statusColors = {
    'Scheduled': 'bg-primary/10 text-primary',
    'Checked In': 'bg-accent/10 text-accent',
    'In Progress': 'bg-orange-50 text-orange-600',
    'Completed': 'bg-green-50 text-green-600',
    'Cancelled': 'bg-destructive/10 text-destructive',
  };

  const getPatient = (apt) => patients.find(p => p.id === apt.patient_id);

  return (
    <div className="space-y-6 max-w-7xl">
      <PageHeader
        title="Appointments"
        subtitle="Click an appointment to view details, AI summary, or create a chart note"
        action={
          <div className="flex gap-2">
            <div className="flex border border-border rounded-lg overflow-hidden">
              <Button variant={viewMode === 'grid' ? 'default' : 'ghost'} size="sm" className="rounded-none gap-1.5 h-9" onClick={() => setViewMode('grid')}>
                <LayoutGrid className="w-4 h-4" /> Grid
              </Button>
              <Button variant={viewMode === 'calendar' ? 'default' : 'ghost'} size="sm" className="rounded-none gap-1.5 h-9 border-l border-border" onClick={() => setViewMode('calendar')}>
                <CalendarDays className="w-4 h-4" /> Calendar
              </Button>
              <Button variant={viewMode === 'past' ? 'default' : 'ghost'} size="sm" className="rounded-none gap-1.5 h-9 border-l border-border" onClick={() => setViewMode('past')}>
                <History className="w-4 h-4" /> Past
              </Button>
            </div>
            <Button variant="outline" className="gap-2" disabled={syncing} onClick={async () => {
              setSyncing(true);
              await base44.functions.invoke('vapiCallSync', {});
              await queryClient.invalidateQueries({ queryKey: ['appointments'] });
              setSyncing(false);
            }}>
              <RefreshCw className={`w-4 h-4 ${syncing ? 'animate-spin' : ''}`} />
              {syncing ? 'Syncing...' : 'Sync Calls'}
            </Button>
            <Button className="gap-2" onClick={() => setShowForm(true)}>
              <Plus className="w-4 h-4" /> New Appointment
            </Button>
          </div>
        }
      />

      {viewMode === 'calendar' && (
        <CalendarView
          items={appointments}
          getDate={(apt) => apt.appointment_date}
          getLabel={(apt) => apt.patient_name}
          getBadgeClass={(apt) => {
            const map = {
              'Scheduled': 'bg-primary/20 text-primary',
              'Checked In': 'bg-accent/20 text-accent',
              'In Progress': 'bg-orange-100 text-orange-700',
              'Completed': 'bg-green-100 text-green-700',
              'Cancelled': 'bg-destructive/10 text-destructive',
            };
            return map[apt.status] || 'bg-primary/10 text-primary';
          }}
          onItemClick={(apt) => setSelectedAppointment(apt)}
        />
      )}

      {viewMode === 'grid' && (
        <DateBrowseGrid
          items={appointments}
          getDate={(apt) => apt.appointment_date}
          emptyMessage="No appointments on this date."
          renderCard={(apt) => (
            <Card
              key={apt.id}
              className="p-5 border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer group"
              onClick={() => setSelectedAppointment(apt)}
            >
              <div className="flex items-start justify-between mb-3">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                    <User className="w-4 h-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">{apt.patient_name}</p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {apt.appointment_date ? format(new Date(apt.appointment_date), 'MMM d, yyyy HH:mm') : 'No date'}
                    </p>
                  </div>
                </div>
                <div className="flex items-center gap-1">
                  {isNew(apt) && <Badge className="text-xs bg-green-100 text-green-700 border-green-200">NEW</Badge>}
                  <Badge className={`text-xs ${statusColors[apt.status] || ''}`}>{apt.status}</Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                </div>
              </div>
              <p className="text-sm text-muted-foreground mb-3 line-clamp-2">{apt.reason || 'No reason specified'}</p>

              {apt.ai_summary && (
                <div className="bg-primary/5 rounded-lg p-2.5 border border-primary/10">
                  <p className="text-xs text-foreground/80 leading-relaxed line-clamp-2">{apt.ai_summary}</p>
                  {apt.risk_flags && (
                    <p className="text-xs text-destructive mt-1 font-medium truncate">⚠ {apt.risk_flags}</p>
                  )}
                </div>
              )}

              <div className="flex items-center justify-between mt-3">
                {apt.status === 'Checked In' ? (
                  <Button
                    size="sm"
                    className="gap-1.5 text-xs h-7 bg-accent hover:bg-accent/90 text-white"
                    onClick={(e) => {
                      e.stopPropagation();
                      navigate(`/patients/${apt.patient_id}?tab=appointments`);
                    }}
                  >
                    <PlayCircle className="w-3.5 h-3.5" /> Start Appointment
                  </Button>
                ) : (
                  <p className="text-xs text-primary font-medium opacity-0 group-hover:opacity-100 transition-opacity">
                    Click to start →
                  </p>
                )}
              </div>
            </Card>
          )}
          gridCols="grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
        />
      )}

      {/* Past Appointments — Date Browse Grid */}
      {viewMode === 'past' && (
        <DateBrowseGrid
          items={appointments}
          getDate={(apt) => apt.appointment_date}
          emptyMessage="No appointments on this date."
          renderCard={(apt) => (
            <Card
              className="p-4 border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer group flex items-start justify-between"
              onClick={() => setSelectedAppointment(apt)}
            >
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-muted flex items-center justify-center">
                  <User className="w-4 h-4 text-muted-foreground" />
                </div>
                <div>
                  <p className="text-sm font-semibold">{apt.patient_name}</p>
                  <p className="text-xs text-muted-foreground flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {apt.appointment_date ? format(new Date(apt.appointment_date), 'h:mm a') : ''}
                  </p>
                  {apt.reason && <p className="text-xs text-muted-foreground mt-0.5">{apt.reason}</p>}
                  {apt.ai_summary && <p className="text-xs text-foreground/70 mt-1 line-clamp-1">{apt.ai_summary}</p>}
                </div>
              </div>
              <Badge className={`text-xs shrink-0 ml-3 ${statusColors[apt.status] || ''}`}>{apt.status}</Badge>
            </Card>
          )}
        />
      )}

      {/* Appointment Detail Modal */}
      <AppointmentDetailModal
        appointment={selectedAppointment}
        patient={selectedAppointment ? getPatient(selectedAppointment) : null}
        onClose={() => setSelectedAppointment(null)}
        onSummaryUpdated={handleSummaryUpdated}
      />

      {/* New Appointment Form */}
      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-md">
          <DialogHeader><DialogTitle>Schedule Appointment</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <div>
              <Label className="text-xs">Patient</Label>
              {patients.length > 0 ? (
                <Select
                  value={formData.patient_id || ''}
                  onValueChange={v => {
                    const p = patients.find(p => p.id === v);
                    setFormData(prev => ({ ...prev, patient_id: v, patient_name: p?.full_name || '' }));
                  }}
                >
                  <SelectTrigger><SelectValue placeholder="Select patient" /></SelectTrigger>
                  <SelectContent>
                    {patients.map(p => <SelectItem key={p.id} value={p.id}>{p.full_name}</SelectItem>)}
                  </SelectContent>
                </Select>
              ) : (
                <Input placeholder="Patient name" value={formData.patient_name} onChange={e => setFormData(prev => ({ ...prev, patient_name: e.target.value }))} />
              )}
            </div>
            <div>
              <Label className="text-xs">Date & Time</Label>
              <Input type="datetime-local" value={formData.appointment_date} onChange={e => setFormData(prev => ({ ...prev, appointment_date: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs">Reason for Visit</Label>
              <Input placeholder="e.g. Follow-up, Chest pain" value={formData.reason} onChange={e => setFormData(prev => ({ ...prev, reason: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs">Notes</Label>
              <Textarea placeholder="Additional notes..." value={formData.notes} onChange={e => setFormData(prev => ({ ...prev, notes: e.target.value }))} />
            </div>
            <Button className="w-full" onClick={() => createMutation.mutate(formData)} disabled={!formData.patient_name || createMutation.isPending}>
              {createMutation.isPending ? 'Scheduling...' : 'Schedule Appointment'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}