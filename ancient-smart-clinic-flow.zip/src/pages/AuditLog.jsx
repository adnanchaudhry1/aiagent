import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Shield, Sparkles, CheckCircle2, Edit3, XCircle, Clock } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import { format } from 'date-fns';

export default function AuditLog() {
  const { data: encounters = [], isLoading } = useQuery({
    queryKey: ['encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date'),
  });

  const statusIcon = {
    'In Progress': Clock,
    'AI Review': Sparkles,
    'Doctor Approved': CheckCircle2,
    'Finalized': Shield,
  };
  const statusColor = {
    'In Progress': 'bg-muted text-muted-foreground',
    'AI Review': 'bg-primary/10 text-primary',
    'Doctor Approved': 'bg-accent/10 text-accent',
    'Finalized': 'bg-purple-50 text-purple-600',
  };

  const parseLog = (logStr) => {
    if (!logStr) return null;
    try { return JSON.parse(logStr); } catch { return null; }
  };

  return (
    <div className="space-y-6 max-w-6xl">
      <PageHeader title="Audit Log" subtitle="Track all AI suggestions and physician decisions for compliance" />

      <Card className="p-5 border-0 shadow-sm">
        <div className="flex items-center gap-3 p-4 rounded-lg bg-primary/5 border border-primary/10 mb-4">
          <Shield className="w-5 h-5 text-primary" />
          <div>
            <p className="text-sm font-semibold">Compliance & Safety</p>
            <p className="text-xs text-muted-foreground">All AI outputs require physician approval. This log tracks every suggestion, decision, and edit for legal accountability.</p>
          </div>
        </div>

        {isLoading ? (
          <p className="text-center py-8 text-muted-foreground">Loading audit log...</p>
        ) : encounters.length === 0 ? (
          <p className="text-center py-8 text-muted-foreground">No encounters yet. Complete an encounter to see audit trails.</p>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Date</TableHead>
                <TableHead>Patient</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>AI Suggestions</TableHead>
                <TableHead>Doctor Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {encounters.map(enc => {
                const aiLog = parseLog(enc.ai_suggestions_log);
                const docLog = parseLog(enc.doctor_actions_log);
                const Icon = statusIcon[enc.status] || Clock;
                return (
                  <TableRow key={enc.id}>
                    <TableCell className="text-xs">
                      {enc.created_date ? format(new Date(enc.created_date), 'MMM d, yyyy HH:mm') : '—'}
                    </TableCell>
                    <TableCell className="text-sm font-medium">{enc.patient_name}</TableCell>
                    <TableCell>
                      <Badge className={`text-xs gap-1 ${statusColor[enc.status] || ''}`}>
                        <Icon className="w-3 h-3" /> {enc.status}
                      </Badge>
                    </TableCell>
                    <TableCell>
                      {aiLog ? (
                        <div className="text-xs space-y-0.5">
                          <p>Generated: {aiLog.generated_at ? format(new Date(aiLog.generated_at), 'HH:mm:ss') : 'Yes'}</p>
                          {aiLog.from_appointment && <p className="text-muted-foreground">From appointment</p>}
                          {aiLog.gis_disease_added && <p className="text-primary">GIS: {aiLog.gis_disease_added}</p>}
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">No AI activity</span>
                      )}
                    </TableCell>
                    <TableCell>
                      {docLog ? (
                        <div className="text-xs space-y-0.5">
                          <p>Action: {docLog.action || docLog.status || '—'}</p>
                          <p className="text-muted-foreground">{docLog.at ? format(new Date(docLog.at), 'HH:mm:ss') : docLog.approved_at ? format(new Date(docLog.approved_at), 'HH:mm:ss') : ''}</p>
                        </div>
                      ) : (
                        <span className="text-xs text-muted-foreground">Pending review</span>
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}