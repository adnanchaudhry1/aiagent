import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ClipboardList, CheckCircle2, AlertTriangle, Stethoscope, Loader2, Sparkles, User, Phone, ChevronRight, Plus, LayoutGrid, CalendarDays, History } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import CalendarView from '@/components/shared/CalendarView';
import DateBrowseGrid from '@/components/shared/DateBrowseGrid';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

const RWANDA_INSURERS = ['RSSB (RAMA)', 'MMI', 'Mutuelle de Santé', 'Private', 'None'];

const PRIORITY_COLORS = {
  Low: 'bg-accent/10 text-accent border-accent/20',
  Medium: 'bg-orange-100 text-orange-700 border-orange-200',
  High: 'bg-destructive/10 text-destructive border-destructive/20',
  Critical: 'bg-destructive text-white border-destructive',
};

const STATUS_COLORS = {
  Assigned: 'bg-primary/10 text-primary',
  Visited: 'bg-accent/10 text-accent',
  Referred: 'bg-orange-100 text-orange-700',
  Managed: 'bg-muted text-muted-foreground',
};

export default function CommunityWorker() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [selectedVisit, setSelectedVisit] = useState(null);
  const [prescreenForm, setPrescreenForm] = useState({
    worker_name: '',
    vitals: '',
    symptoms: '',
    assessment: '',
    needs_doctor: false,
    high_alert: false,
    high_alert_reason: '',
  });
  const [vitalsExpanded, setVitalsExpanded] = useState({
    bp: '', temp: '', pulse: '', weight: '', height: '', spo2: ''
  });
  const [saving, setSaving] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [viewMode, setViewMode] = useState('grid');
  const [showAddPatient, setShowAddPatient] = useState(false);
  const [patientForm, setPatientForm] = useState({ full_name: '', gender: '', date_of_birth: '', phone: '', district: '', national_id: '', insurance_type: '', insurance_id: '', chronic_conditions: '', allergies: '' });
  const [addingPatient, setAddingPatient] = useState(false);

  const { data: visits = [], isLoading } = useQuery({
    queryKey: ['community_visits'],
    queryFn: () => base44.entities.CommunityWorkerVisit.list('-created_date'),
  });

  const openPrescreen = (visit) => {
    setSelectedVisit(visit);
    setPrescreenForm({
      worker_name: visit.worker_name || '',
      vitals: '',
      symptoms: '',
      assessment: '',
      needs_doctor: false,
      high_alert: visit.high_alert || false,
      high_alert_reason: visit.high_alert_reason || '',
    });
    setVitalsExpanded({ bp: '', temp: '', pulse: '', weight: '', height: '', spo2: '' });
  };

  const analyzeWithAI = async () => {
    if (!prescreenForm.symptoms) { toast.error('Enter symptoms first'); return; }
    setAiLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `Community health worker pre-screening assessment for Rwanda. Analyze and advise:

Patient: ${selectedVisit?.patient_name}
Original Problem: ${selectedVisit?.problem_description}
Priority from intake: ${selectedVisit?.priority}
Vitals: BP ${vitalsExpanded.bp}, Temp ${vitalsExpanded.temp}°C, Pulse ${vitalsExpanded.pulse}, Weight ${vitalsExpanded.weight}kg, SpO2 ${vitalsExpanded.spo2}%
Symptoms observed: ${prescreenForm.symptoms}

Determine:
1. Does this patient need to see a doctor (true/false)?
2. Is this a high alert / critical condition?
3. Clinical assessment summary
4. If high alert, what is the reason?`,
        response_json_schema: {
          type: 'object',
          properties: {
            needs_doctor: { type: 'boolean' },
            high_alert: { type: 'boolean' },
            high_alert_reason: { type: 'string' },
            assessment: { type: 'string' },
            clinical_notes: { type: 'string' },
          }
        }
      });
      setPrescreenForm(p => ({
        ...p,
        needs_doctor: res.needs_doctor,
        high_alert: res.high_alert,
        high_alert_reason: res.high_alert_reason || '',
        assessment: res.assessment + (res.clinical_notes ? '\n\n' + res.clinical_notes : ''),
      }));
      toast.success('AI assessment complete');
    } catch {
      toast.error('AI analysis failed');
    } finally {
      setAiLoading(false);
    }
  };

  const savePrescreen = async () => {
    setSaving(true);
    try {
      const vitalsStr = JSON.stringify({
        bp: vitalsExpanded.bp,
        temperature: vitalsExpanded.temp,
        pulse: vitalsExpanded.pulse,
        weight: vitalsExpanded.weight,
        height: vitalsExpanded.height,
        spo2: vitalsExpanded.spo2,
      });

      // Auto-register patient in system if not already present
      let patientId = selectedVisit.patient_id || '';
      if (!patientId && selectedVisit.patient_name) {
        // Check if patient already exists by national_id
        const existingPatients = await base44.entities.Patient.list();
        const existing = selectedVisit.national_id
          ? existingPatients.find(p => p.national_id === selectedVisit.national_id)
          : existingPatients.find(p => p.full_name === selectedVisit.patient_name);

        if (existing) {
          patientId = existing.id;
        } else {
        // Create new patient from community worker visit info
        const newPatient = await base44.entities.Patient.create({
          full_name: selectedVisit.patient_name,
          gender: selectedVisit.gender || 'Other',
          national_id: selectedVisit.national_id || '',
          phone: selectedVisit.phone || '',
          date_of_birth: selectedVisit.date_of_birth || '',
          insurance_id: selectedVisit.insurance_id || '',
          status: 'Active',
        });
        patientId = newPatient.id;
        toast.info(`Patient "${selectedVisit.patient_name}" added to system automatically.`);
        }
      }

      await base44.entities.CommunityWorkerVisit.update(selectedVisit.id, {
        patient_id: patientId,
        worker_name: prescreenForm.worker_name || selectedVisit.worker_name || 'Unassigned',
        vitals: vitalsStr,
        symptoms: prescreenForm.symptoms,
        assessment: prescreenForm.assessment,
        needs_doctor: prescreenForm.needs_doctor,
        high_alert: prescreenForm.high_alert,
        high_alert_reason: prescreenForm.high_alert_reason,
        status: prescreenForm.needs_doctor ? 'Referred' : 'Managed',
        visit_date: new Date().toISOString(),
      });
      queryClient.invalidateQueries({ queryKey: ['community_visits'] });
      queryClient.invalidateQueries({ queryKey: ['patients'] });
      setSelectedVisit(null);
      if (prescreenForm.needs_doctor) {
        toast.success('Patient referred to clinic — navigating to Appointments.');
        navigate('/appointments');
      } else {
        toast.success('Patient managed by community worker — case closed.');
        // Stay on community worker page, dialog closes
      }
    } catch {
      toast.error('Save failed. Please try again.');
    } finally {
      setSaving(false);
    }
  };

  const addPatientToSystem = async () => {
    if (!patientForm.full_name || !patientForm.gender) return;
    setAddingPatient(true);
    try {
      // Check duplicate by national_id
      if (patientForm.national_id) {
        const existing = await base44.entities.Patient.list();
        const dup = existing.find(p => p.national_id === patientForm.national_id);
        if (dup) {
          toast.error(`Patient already exists: ${dup.full_name}`);
          setAddingPatient(false);
          return;
        }
      }
      const created = await base44.entities.Patient.create({ ...patientForm, status: 'Active' });
      queryClient.invalidateQueries({ queryKey: ['patients'] });
      toast.success(`Patient "${patientForm.full_name}" added to system!`);
      setShowAddPatient(false);
      setPatientForm({ full_name: '', gender: '', date_of_birth: '', phone: '', district: '', national_id: '', insurance_type: '', insurance_id: '', chronic_conditions: '', allergies: '' });
      navigate(`/patients/${created.id}`);
    } catch {
      toast.error('Failed to add patient');
    } finally {
      setAddingPatient(false);
    }
  };

  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const isNew = (item) => {
    if (!item.created_date) return false;
    return (Date.now() - new Date(item.created_date).getTime()) < 24 * 60 * 60 * 1000;
  };

  const pending = visits.filter(v => v.status === 'Assigned' && new Date(v.visit_date || v.created_date) >= todayStart);
  const completed = visits.filter(v => v.status !== 'Assigned');

  return (
    <div className="space-y-6 max-w-5xl">
      <PageHeader
        title="Community Worker Cases"
        subtitle="Phase 2 — Pre-screening visits assigned from AI phone intake"
        action={
          <div className="flex gap-2">
            <div className="flex border border-border rounded-lg overflow-hidden">
              <Button variant={viewMode === 'grid' ? 'default' : 'ghost'} size="sm" className="rounded-none gap-1.5 h-9" onClick={() => setViewMode('grid')}>
                <LayoutGrid className="w-4 h-4" /> Grid
              </Button>
              <Button variant={viewMode === 'calendar' ? 'default' : 'ghost'} size="sm" className="rounded-none gap-1.5 h-9 border-l border-border" onClick={() => setViewMode('calendar')}>
                <CalendarDays className="w-4 h-4" /> Calendar
              </Button>
              <Button variant={viewMode === 'past' ? 'default' : 'ghost'} size="sm" className="rounded-none gap-1.5 h-9 border-l border-border" onClick={() => setViewMode('past')}>
                <History className="w-4 h-4" /> Past
              </Button>
            </div>
            <Button variant="outline" className="gap-2" onClick={() => setShowAddPatient(true)}>
              <Plus className="w-4 h-4" /> Add Patient
            </Button>
            <Button className="gap-2" onClick={() => navigate('/phone-intake')}>
              <Phone className="w-4 h-4" /> New AI Phone Intake
            </Button>
          </div>
        }
      />

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Total Assigned', value: pending.length, color: 'text-primary' },
          { label: 'Critical/High', value: visits.filter(v => v.priority === 'Critical' || v.priority === 'High').length, color: 'text-destructive' },
          { label: 'Referred to Clinic', value: visits.filter(v => v.status === 'Referred').length, color: 'text-orange-600' },
          { label: 'Managed', value: visits.filter(v => v.status === 'Managed').length, color: 'text-accent' },
        ].map(s => (
          <Card key={s.label} className="p-4 border-0 shadow-sm text-center">
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </Card>
        ))}
      </div>

      {viewMode === 'calendar' && (
        <CalendarView
          items={visits}
          getDate={(v) => v.visit_date || v.created_date}
          getLabel={(v) => v.patient_name}
          getBadgeClass={(v) => {
            const map = {
              Assigned: 'bg-primary/20 text-primary',
              Visited: 'bg-accent/20 text-accent',
              Referred: 'bg-orange-100 text-orange-700',
              Managed: 'bg-muted text-muted-foreground',
            };
            return (v.high_alert ? 'bg-destructive/20 text-destructive' : map[v.status]) || 'bg-primary/10 text-primary';
          }}
          onItemClick={(v) => openPrescreen(v)}
        />
      )}

      {viewMode === 'grid' && (
        <DateBrowseGrid
          items={visits}
          getDate={(v) => v.visit_date || v.created_date}
          emptyMessage="No cases on this date."
          renderCard={(v) => (
            <Card
              className={`p-4 border shadow-sm cursor-pointer hover:shadow-md transition-shadow ${v.high_alert ? 'border-destructive/40 bg-destructive/5' : 'border-0'}`}
              onClick={() => openPrescreen(v)}
            >
              <div className="flex items-start justify-between">
                <div className="flex items-start gap-3">
                  <div className={`w-10 h-10 rounded-full flex items-center justify-center ${v.priority === 'Critical' ? 'bg-destructive/20' : 'bg-primary/10'}`}>
                    <User className={`w-5 h-5 ${v.priority === 'Critical' ? 'text-destructive' : 'text-primary'}`} />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="text-sm font-semibold">{v.patient_name}</p>
                      {isNew(v) && <Badge className="bg-green-100 text-green-700 border-green-200 text-xs">NEW</Badge>}
                      {v.high_alert && <Badge className="bg-destructive text-white text-xs flex items-center gap-1"><AlertTriangle className="w-3 h-3" /> HIGH ALERT</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground">{v.national_id} · {v.phone}</p>
                    <p className="text-xs mt-1 text-foreground/80">{v.problem_description}</p>
                    <p className="text-xs text-muted-foreground mt-0.5">Assigned to: <span className="font-medium">{v.worker_name}</span></p>
                  </div>
                </div>
                <div className="flex flex-col items-end gap-2">
                  <Badge className={PRIORITY_COLORS[v.priority]}>{v.priority}</Badge>
                  <Badge className={STATUS_COLORS[v.status]}>{v.status}</Badge>
                  <ChevronRight className="w-4 h-4 text-muted-foreground" />
                </div>
              </div>
            </Card>
          )}
        />
      )}

      {/* Past Visits — Date Browse Grid */}
      {viewMode === 'past' && (
        <DateBrowseGrid
          items={visits}
          getDate={(v) => v.visit_date || v.created_date}
          emptyMessage="No visits recorded on this date."
          renderCard={(v) => (
            <Card
              className={`p-4 border shadow-sm cursor-pointer hover:shadow-md transition-shadow flex items-start justify-between ${v.high_alert ? 'border-destructive/30 bg-destructive/5' : 'border-0'}`}
              onClick={() => openPrescreen(v)}
            >
              <div className="flex items-start gap-3">
                <div className={`w-9 h-9 rounded-full flex items-center justify-center ${v.priority === 'Critical' ? 'bg-destructive/20' : 'bg-primary/10'}`}>
                  <User className={`w-4 h-4 ${v.priority === 'Critical' ? 'text-destructive' : 'text-primary'}`} />
                </div>
                <div>
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-semibold">{v.patient_name}</p>
                    {v.high_alert && <Badge className="bg-destructive text-white text-xs">HIGH ALERT</Badge>}
                  </div>
                  <p className="text-xs text-muted-foreground">{v.national_id} · {v.phone}</p>
                  <p className="text-xs mt-0.5 text-foreground/80">{v.problem_description}</p>
                  {v.worker_name && <p className="text-xs text-muted-foreground mt-0.5">Worker: <span className="font-medium">{v.worker_name}</span></p>}
                </div>
              </div>
              <div className="flex flex-col items-end gap-1 ml-3 shrink-0">
                <Badge className={PRIORITY_COLORS[v.priority]}>{v.priority}</Badge>
                <Badge className={STATUS_COLORS[v.status]}>{v.status}</Badge>
              </div>
            </Card>
          )}
        />
      )}

      {viewMode === 'grid' && !isLoading && visits.length === 0 && (
        <div className="text-center py-16">
          <ClipboardList className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">No community worker cases yet.</p>
          <Button className="mt-4 gap-2" onClick={() => navigate('/phone-intake')}>
            <Phone className="w-4 h-4" /> Start AI Phone Intake
          </Button>
        </div>
      )}

      {/* Add Patient Dialog */}
      <Dialog open={showAddPatient} onOpenChange={setShowAddPatient}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <User className="w-5 h-5" /> Add New Patient
            </DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-2 gap-3 mt-2">
            <div className="col-span-2">
              <Label className="text-xs">Full Name *</Label>
              <Input className="mt-1" value={patientForm.full_name} onChange={e => setPatientForm(p => ({ ...p, full_name: e.target.value }))} placeholder="Patient full name" />
            </div>
            <div>
              <Label className="text-xs">Gender *</Label>
              <Select value={patientForm.gender} onValueChange={v => setPatientForm(p => ({ ...p, gender: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select gender" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Date of Birth</Label>
              <Input type="date" className="mt-1" value={patientForm.date_of_birth} onChange={e => setPatientForm(p => ({ ...p, date_of_birth: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs">National ID</Label>
              <Input className="mt-1" value={patientForm.national_id} onChange={e => setPatientForm(p => ({ ...p, national_id: e.target.value }))} placeholder="1XXXXXXXXXXXXXXXXX" />
            </div>
            <div>
              <Label className="text-xs">Phone</Label>
              <Input className="mt-1" value={patientForm.phone} onChange={e => setPatientForm(p => ({ ...p, phone: e.target.value }))} placeholder="+250 7XX XXX XXX" />
            </div>
            <div>
              <Label className="text-xs">District</Label>
              <Input className="mt-1" value={patientForm.district} onChange={e => setPatientForm(p => ({ ...p, district: e.target.value }))} placeholder="e.g. Gasabo" />
            </div>
            <div>
              <Label className="text-xs">Insurance Type</Label>
              <Select value={patientForm.insurance_type} onValueChange={v => setPatientForm(p => ({ ...p, insurance_type: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select insurer" /></SelectTrigger>
                <SelectContent>
                  {RWANDA_INSURERS.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Insurance Member ID</Label>
              <Input className="mt-1" value={patientForm.insurance_id} onChange={e => setPatientForm(p => ({ ...p, insurance_id: e.target.value }))} placeholder="Member ID" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Chronic Conditions</Label>
              <Input className="mt-1" value={patientForm.chronic_conditions} onChange={e => setPatientForm(p => ({ ...p, chronic_conditions: e.target.value }))} placeholder="e.g. Hypertension, Diabetes" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Allergies</Label>
              <Input className="mt-1" value={patientForm.allergies} onChange={e => setPatientForm(p => ({ ...p, allergies: e.target.value }))} placeholder="e.g. Penicillin, Sulfa drugs" />
            </div>
            <div className="col-span-2 flex gap-2 mt-2">
              <Button className="flex-1" onClick={addPatientToSystem} disabled={addingPatient || !patientForm.full_name || !patientForm.gender}>
                {addingPatient ? <><Loader2 className="w-4 h-4 animate-spin mr-2" />Saving...</> : 'Add Patient & Open Chart'}
              </Button>
              <Button variant="outline" onClick={() => setShowAddPatient(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Pre-screening Dialog */}
      <Dialog open={!!selectedVisit} onOpenChange={() => setSelectedVisit(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Stethoscope className="w-5 h-5" />
              Pre-Screening: {selectedVisit?.patient_name}
            </DialogTitle>
          </DialogHeader>

          {selectedVisit && (
            <div className="space-y-4 mt-2">
              {/* Patient Info Summary */}
              <div className="p-3 bg-muted/40 rounded-lg border border-border/50">
                <p className="text-xs font-semibold mb-2">Patient from AI Intake:</p>
                <div className="grid grid-cols-2 gap-1 text-xs">
                  <p><span className="text-muted-foreground">Problem:</span> {selectedVisit.problem_description}</p>
                  <p><span className="text-muted-foreground">Priority:</span> <Badge className={`text-xs ${PRIORITY_COLORS[selectedVisit.priority]}`}>{selectedVisit.priority}</Badge></p>
                  <p><span className="text-muted-foreground">National ID:</span> {selectedVisit.national_id || 'N/A'}</p>
                  <p><span className="text-muted-foreground">Insurance:</span> {selectedVisit.insurance_id || 'N/A'}</p>
                </div>
              </div>

              {/* Worker Name */}
              <div>
                <Label className="text-xs">Community Worker Name *</Label>
                <Input className="mt-1" value={prescreenForm.worker_name} onChange={e => setPrescreenForm(p => ({ ...p, worker_name: e.target.value }))} placeholder="Worker visiting patient" />
              </div>

              {/* Vitals */}
              <div>
                <Label className="text-xs font-semibold">Vitals</Label>
                <div className="grid grid-cols-3 gap-2 mt-1">
                  {[
                    { key: 'bp', label: 'BP (mmHg)' },
                    { key: 'temp', label: 'Temp (°C)' },
                    { key: 'pulse', label: 'Pulse (bpm)' },
                    { key: 'weight', label: 'Weight (kg)' },
                    { key: 'height', label: 'Height (cm)' },
                    { key: 'spo2', label: 'SpO2 (%)' },
                  ].map(f => (
                    <div key={f.key}>
                      <Label className="text-xs text-muted-foreground">{f.label}</Label>
                      <Input className="mt-0.5" placeholder={f.label} value={vitalsExpanded[f.key]} onChange={e => setVitalsExpanded(p => ({ ...p, [f.key]: e.target.value }))} />
                    </div>
                  ))}
                </div>
              </div>

              {/* Symptoms */}
              <div>
                <Label className="text-xs">Observed Symptoms *</Label>
                <Textarea className="mt-1" rows={3} value={prescreenForm.symptoms} onChange={e => setPrescreenForm(p => ({ ...p, symptoms: e.target.value }))} placeholder="Document symptoms observed during visit..." />
              </div>

              <Button variant="outline" className="gap-2 w-full" onClick={analyzeWithAI} disabled={aiLoading}>
                {aiLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Sparkles className="w-4 h-4" /> AI Assessment</>}
              </Button>

              {/* Assessment */}
              <div>
                <Label className="text-xs">Clinical Assessment</Label>
                <Textarea className="mt-1" rows={3} value={prescreenForm.assessment} onChange={e => setPrescreenForm(p => ({ ...p, assessment: e.target.value }))} placeholder="Clinical assessment by community worker..." />
              </div>

              {/* Decision */}
              <div className="grid grid-cols-2 gap-3">
                <div
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${!prescreenForm.needs_doctor ? 'border-accent bg-accent/10' : 'border-border bg-background'}`}
                  onClick={() => setPrescreenForm(p => ({ ...p, needs_doctor: false }))}
                >
                  <CheckCircle2 className={`w-5 h-5 mb-1 ${!prescreenForm.needs_doctor ? 'text-accent' : 'text-muted-foreground'}`} />
                  <p className="text-sm font-semibold">Managed by Worker</p>
                  <p className="text-xs text-muted-foreground">Patient does not need doctor visit</p>
                </div>
                <div
                  className={`p-4 rounded-lg border-2 cursor-pointer transition-all ${prescreenForm.needs_doctor ? 'border-destructive bg-destructive/10' : 'border-border bg-background'}`}
                  onClick={() => setPrescreenForm(p => ({ ...p, needs_doctor: true }))}
                >
                  <Stethoscope className={`w-5 h-5 mb-1 ${prescreenForm.needs_doctor ? 'text-destructive' : 'text-muted-foreground'}`} />
                  <p className="text-sm font-semibold">Refer to Doctor</p>
                  <p className="text-xs text-muted-foreground">Patient needs clinic/doctor visit</p>
                </div>
              </div>

              {prescreenForm.high_alert && (
                <div className="p-3 bg-destructive/10 rounded-lg border border-destructive/20">
                  <div className="flex items-center gap-2 mb-2">
                    <AlertTriangle className="w-4 h-4 text-destructive" />
                    <p className="text-xs font-semibold text-destructive">High Alert Flag Active</p>
                  </div>
                  <Input
                    value={prescreenForm.high_alert_reason}
                    onChange={e => setPrescreenForm(p => ({ ...p, high_alert_reason: e.target.value }))}
                    placeholder="Reason for high alert..."
                    className="text-xs border-destructive/30"
                  />
                </div>
              )}

              <Button className="w-full" onClick={savePrescreen} disabled={saving || !prescreenForm.symptoms}>
                {saving ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Saving...</> : 'Save Pre-Screening & Update Status'}
              </Button>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}