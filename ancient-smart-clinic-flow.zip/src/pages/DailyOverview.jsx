import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';
import { Calendar, ShieldCheck, Clock, ArrowRight, CheckCircle2, AlertTriangle, User } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import { format, isToday, isTomorrow, parseISO } from 'date-fns';

const statusColors = {
  'Scheduled': 'bg-primary/10 text-primary',
  'Checked In': 'bg-accent/10 text-accent',
  'In Progress': 'bg-orange-50 text-orange-600',
  'Completed': 'bg-green-50 text-green-700',
  'Cancelled': 'bg-muted text-muted-foreground',
};

const claimStatusColors = {
  'Draft': 'bg-muted text-muted-foreground',
  'Submitted': 'bg-primary/10 text-primary',
  'Under Review': 'bg-orange-50 text-orange-600',
  'Approved': 'bg-green-50 text-green-700',
  'Denied': 'bg-destructive/10 text-destructive',
  'Paid': 'bg-accent/10 text-accent',
};

function dayLabel(dateStr) {
  try {
    const d = parseISO(dateStr);
    if (isToday(d)) return 'Today';
    if (isTomorrow(d)) return 'Tomorrow';
    return format(d, 'EEE, MMM d');
  } catch {
    return '';
  }
}

const decodeName = (name) => { try { return decodeURIComponent(name || ''); } catch { return name || ''; } };

export default function DailyOverview() {
  const navigate = useNavigate();

  const { data: appointments = [], isLoading: loadingApts } = useQuery({
    queryKey: ['all-appointments'],
    queryFn: () => base44.entities.Appointment.list('-appointment_date', 50),
  });

  const { data: claims = [], isLoading: loadingClaims } = useQuery({
    queryKey: ['all-claims'],
    queryFn: () => base44.entities.InsuranceClaim.list('-created_date', 50),
  });

  // Upcoming = not cancelled, not completed
  const upcomingAppointments = appointments
    .filter(a => a.status !== 'Cancelled' && a.status !== 'Completed')
    .sort((a, b) => new Date(a.appointment_date) - new Date(b.appointment_date));

  // Pending claims = draft or submitted or under review
  const pendingClaims = claims.filter(c => ['Draft', 'Submitted', 'Under Review'].includes(c.status));

  const todayApts = upcomingAppointments.filter(a => {
    try { return isToday(parseISO(a.appointment_date)); } catch { return false; }
  });

  const laterApts = upcomingAppointments.filter(a => {
    try { return !isToday(parseISO(a.appointment_date)); } catch { return false; }
  });

  const totalValue = pendingClaims.reduce((sum, c) => sum + (c.charged_amount || 0), 0);

  return (
    <div className="space-y-6 max-w-7xl">
      <PageHeader
        title="Daily Overview"
        subtitle={`Prepared for ${format(new Date(), 'EEEE, MMMM d, yyyy')}`}
        action={
          <div className="flex gap-2">
            <Link to="/appointments">
              <Button variant="outline" size="sm" className="gap-1"><Calendar className="w-4 h-4" />Appointments</Button>
            </Link>
            <Link to="/insurance">
              <Button variant="outline" size="sm" className="gap-1"><ShieldCheck className="w-4 h-4" />Claims</Button>
            </Link>
          </div>
        }
      />

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="p-4 border-0 shadow-sm text-center">
          <p className="text-2xl font-bold text-primary">{todayApts.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Today's Appointments</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm text-center">
          <p className="text-2xl font-bold text-accent">{laterApts.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Upcoming (Later)</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm text-center">
          <p className="text-2xl font-bold text-orange-500">{pendingClaims.length}</p>
          <p className="text-xs text-muted-foreground mt-1">Pending Claims</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm text-center">
          <p className="text-2xl font-bold text-foreground">{totalValue > 0 ? `${(totalValue).toLocaleString()} RWF` : '—'}</p>
          <p className="text-xs text-muted-foreground mt-1">Pending Claim Value</p>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Appointments */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold flex items-center gap-2"><Calendar className="w-4 h-4 text-primary" />Upcoming Appointments</h2>
            <Link to="/appointments" className="text-xs text-primary hover:underline flex items-center gap-1">View all <ArrowRight className="w-3 h-3" /></Link>
          </div>

          {loadingApts ? (
            <Card className="p-8 border-0 shadow-sm text-center text-muted-foreground text-sm">Loading...</Card>
          ) : upcomingAppointments.length === 0 ? (
            <Card className="p-8 border-0 shadow-sm text-center">
              <CheckCircle2 className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No upcoming appointments. You're all clear!</p>
            </Card>
          ) : (
            <>
              {todayApts.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-destructive mb-2 flex items-center gap-1"><Clock className="w-3 h-3" />Today</p>
                  <div className="space-y-2">
                    {todayApts.map(apt => (
                      <Card key={apt.id} className="p-4 border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer border-l-4 border-l-primary"
                        onClick={() => apt.patient_id && navigate(`/patients/${apt.patient_id}`)}>
                        <div className="flex items-start justify-between">
                          <div className="flex items-start gap-3">
                            <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                              <span className="text-xs font-bold text-primary">{decodeName(apt.patient_name)?.[0] || 'P'}</span>
                            </div>
                            <div>
                              <p className="text-sm font-semibold">{decodeName(apt.patient_name)}</p>
                              <p className="text-xs text-muted-foreground">{apt.reason || 'General visit'}</p>
                              {apt.appointment_date && (
                                <p className="text-xs text-primary mt-0.5 flex items-center gap-1">
                                  <Clock className="w-3 h-3" />{format(parseISO(apt.appointment_date), 'h:mm a')}
                                </p>
                              )}
                              {apt.doctor_name && <p className="text-xs text-muted-foreground">Dr. {apt.doctor_name}</p>}
                            </div>
                          </div>
                          <Badge className={`text-xs shrink-0 ${statusColors[apt.status] || 'bg-muted text-muted-foreground'}`}>{apt.status}</Badge>
                        </div>
                        {apt.ai_summary && (
                          <p className="text-xs text-muted-foreground mt-2 line-clamp-1 pl-11 italic">{apt.ai_summary}</p>
                        )}
                      </Card>
                    ))}
                  </div>
                </div>
              )}

              {laterApts.length > 0 && (
                <div>
                  <p className="text-xs font-semibold text-muted-foreground mb-2">Upcoming</p>
                  <div className="space-y-2">
                    {laterApts.slice(0, 8).map(apt => (
                      <Card key={apt.id} className="p-3 border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                        onClick={() => apt.patient_id && navigate(`/patients/${apt.patient_id}`)}>
                        <div className="flex items-center justify-between">
                          <div className="flex items-center gap-3">
                            <div className="w-7 h-7 rounded-full bg-muted flex items-center justify-center shrink-0">
                              <User className="w-3 h-3 text-muted-foreground" />
                            </div>
                            <div>
                              <p className="text-sm font-medium">{decodeName(apt.patient_name)}</p>
                              <p className="text-xs text-muted-foreground">{apt.reason || 'General visit'} · {dayLabel(apt.appointment_date)}</p>
                            </div>
                          </div>
                          <Badge className={`text-xs ${statusColors[apt.status] || 'bg-muted text-muted-foreground'}`}>{apt.status}</Badge>
                        </div>
                      </Card>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Pending Claims */}
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold flex items-center gap-2"><ShieldCheck className="w-4 h-4 text-primary" />Pending Insurance Claims</h2>
            <Link to="/insurance" className="text-xs text-primary hover:underline flex items-center gap-1">View all <ArrowRight className="w-3 h-3" /></Link>
          </div>

          {loadingClaims ? (
            <Card className="p-8 border-0 shadow-sm text-center text-muted-foreground text-sm">Loading...</Card>
          ) : pendingClaims.length === 0 ? (
            <Card className="p-8 border-0 shadow-sm text-center">
              <CheckCircle2 className="w-8 h-8 text-accent mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">No pending claims. All caught up!</p>
            </Card>
          ) : (
            <div className="space-y-2">
              {pendingClaims.slice(0, 12).map(claim => (
                <Card key={claim.id} className={`p-4 border-0 shadow-sm hover:shadow-md transition-shadow ${claim.status === 'Under Review' ? 'border-l-4 border-l-orange-400' : claim.status === 'Submitted' ? 'border-l-4 border-l-primary' : ''}`}>
                  <div className="flex items-start justify-between">
                    <div>
                      <div className="flex items-center gap-2 mb-0.5">
                        <p className="text-sm font-semibold">{decodeName(claim.patient_name)}</p>
                        {claim.claim_number && (
                          <span className="text-xs text-muted-foreground font-mono">{claim.claim_number}</span>
                        )}
                      </div>
                      <p className="text-xs text-muted-foreground">{claim.insurance_type || 'Unknown insurer'}</p>
                      {claim.encounter_number && (
                        <p className="text-xs text-primary mt-0.5">Encounter: {claim.encounter_number}</p>
                      )}
                      {claim.charged_amount > 0 && (
                        <p className="text-xs font-semibold mt-1">{claim.charged_amount.toLocaleString()} RWF</p>
                      )}
                    </div>
                    <div className="flex flex-col items-end gap-1">
                      <Badge className={`text-xs ${claimStatusColors[claim.status] || 'bg-muted text-muted-foreground'}`}>{claim.status}</Badge>
                      {claim.approval_probability > 0 && (
                        <span className={`text-xs font-medium ${claim.approval_probability >= 70 ? 'text-accent' : claim.approval_probability >= 40 ? 'text-orange-500' : 'text-destructive'}`}>
                          {claim.approval_probability}% approval
                        </span>
                      )}
                    </div>
                  </div>
                  {claim.risk_flags && claim.risk_flags !== '[]' && (
                    <div className="flex items-center gap-1 mt-2 text-xs text-orange-600">
                      <AlertTriangle className="w-3 h-3" />
                      <span>Risk flags detected — review before submission</span>
                    </div>
                  )}
                  <div className="mt-2">
                    <Button size="sm" variant="outline" className="h-7 text-xs gap-1"
                      onClick={() => navigate('/insurance')}>
                      <ArrowRight className="w-3 h-3" />Manage Claim
                    </Button>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}