import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Link, useNavigate } from 'react-router-dom';

import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import {
  Users, Calendar, ShieldCheck, Activity,
  ArrowRight, UserPlus, Stethoscope, CheckSquare, Mic, FileText, Upload, Loader2
} from 'lucide-react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from 'recharts';
import StatCard from '@/components/shared/StatCard';
import PageHeader from '@/components/shared/PageHeader';
import HighRiskAlerts from '@/components/shared/HighRiskAlerts';
import { useHighRiskPatients } from '@/hooks/useHighRiskPatients';

const encounterData = [
  { day: 'Mon', count: 12 }, { day: 'Tue', count: 18 }, { day: 'Wed', count: 15 },
  { day: 'Thu', count: 22 }, { day: 'Fri', count: 19 }, { day: 'Sat', count: 8 }, { day: 'Sun', count: 5 },
];

const claimData = [
  { name: 'Approved', value: 68, color: 'hsl(168, 70%, 42%)' },
  { name: 'Pending', value: 20, color: 'hsl(199, 89%, 38%)' },
  { name: 'Denied', value: 12, color: 'hsl(0, 72%, 51%)' },
];

export default function Dashboard() {
  const [showAddPatient, setShowAddPatient] = useState(false);
  const [patientForm, setPatientForm] = useState({ full_name: '', gender: '', date_of_birth: '', phone: '', district: '', insurance_type: '', national_id: '', national_id_card: '' });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: patients = [] } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });
  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments'],
    queryFn: () => base44.entities.Appointment.list('-appointment_date', 5),
  });
  const { data: encounters = [] } = useQuery({
    queryKey: ['encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date', 200),
  });
  const { data: claims = [] } = useQuery({
    queryKey: ['claims'],
    queryFn: () => base44.entities.InsuranceClaim.list(),
  });

  const todayAppointments = appointments.filter(a => a.status === 'Scheduled' || a.status === 'Checked In');
  const riskPatients = useHighRiskPatients(encounters, patients);

  const uploadIDCard = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      setPatientForm(p => ({ ...p, national_id_card: res.file_url }));
    } finally {
      setUploading(false);
    }
  };

  const addPatient = async () => {
    if (!patientForm.full_name || !patientForm.gender) return;
    setSaving(true);
    try {
      const created = await base44.entities.Patient.create({ ...patientForm, status: 'Active' });
      queryClient.invalidateQueries({ queryKey: ['patients'] });
      setShowAddPatient(false);
      setPatientForm({ full_name: '', gender: '', date_of_birth: '', phone: '', district: '', insurance_type: '', national_id: '', national_id_card: '' });
      navigate(`/patients/${created.id}`);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6 max-w-7xl">
      <PageHeader
        title="Murava AI"
        subtitle={`Welcome back — ${new Date().toLocaleDateString('en-RW', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}`}
        action={
          <div className="flex gap-2">
            <Link to="/eligibility">
              <Button variant="outline" className="gap-2">
                <CheckSquare className="w-4 h-4" />
                Eligibility Check
              </Button>
            </Link>
          </div>
        }
      />

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard title="Total Patients" value={patients.length || 0} icon={Users} color="primary" trend="+12% this month" trendUp />
        <StatCard title="Scheduled Appointments" value={todayAppointments.length || 0} icon={Calendar} color="accent" />
        <StatCard title="Active Encounters" value={encounters.filter(e => e.status !== 'Finalized' && e.status !== 'Doctor Approved').length || 0} icon={Stethoscope} color="chart3" />
        <StatCard title="Insurance Claims" value={claims.length || 0} icon={ShieldCheck} color="chart4" trend={`${claims.filter(c=>c.status==='Approved').length} approved`} trendUp />
      </div>

      <HighRiskAlerts riskPatients={riskPatients} />



      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="col-span-2 p-6 border-0 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-foreground">Weekly Encounters</h3>
            <Badge variant="secondary" className="text-xs">This Week</Badge>
          </div>
          <ResponsiveContainer width="100%" height={240}>
            <BarChart data={encounterData}>
              <CartesianGrid strokeDasharray="3 3" stroke="hsl(214, 20%, 90%)" />
              <XAxis dataKey="day" tick={{ fontSize: 12 }} stroke="hsl(215, 12%, 50%)" />
              <YAxis tick={{ fontSize: 12 }} stroke="hsl(215, 12%, 50%)" />
              <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
              <Bar dataKey="count" fill="hsl(199, 89%, 38%)" radius={[6, 6, 0, 0]} />
            </BarChart>
          </ResponsiveContainer>
        </Card>

        <Card className="p-6 border-0 shadow-sm">
          <h3 className="text-sm font-semibold text-foreground mb-4">Claim Status Distribution</h3>
          <ResponsiveContainer width="100%" height={180}>
            <PieChart>
              <Pie data={claimData} cx="50%" cy="50%" innerRadius={50} outerRadius={75} dataKey="value" strokeWidth={0}>
                {claimData.map((entry, idx) => (
                  <Cell key={idx} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }} />
            </PieChart>
          </ResponsiveContainer>
          <div className="flex justify-center gap-4 mt-2">
            {claimData.map(d => (
              <div key={d.name} className="flex items-center gap-1.5 text-xs text-muted-foreground">
                <span className="w-2 h-2 rounded-full" style={{ background: d.color }} />
                {d.name} ({d.value}%)
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="p-6 border-0 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-foreground">Upcoming Appointments</h3>
            <Link to="/appointments" className="text-xs text-primary font-medium flex items-center gap-1 hover:underline">
              View all <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          {appointments.length === 0 ? (
            <p className="text-sm text-muted-foreground">No appointments found.</p>
          ) : (
            <div className="space-y-3">
              {appointments.slice(0, 5).map(apt => (
                <div key={apt.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover:bg-muted transition-colors cursor-pointer"
                  onClick={() => apt.patient_id && navigate(`/patients/${apt.patient_id}`)}>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-xs font-bold text-primary">{apt.patient_name?.[0] || 'P'}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">{apt.patient_name}</p>
                      <p className="text-xs text-muted-foreground">{apt.reason || 'General checkup'}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant={apt.status === 'Completed' ? 'default' : 'secondary'} className="text-xs">
                      {apt.status}
                    </Badge>
                    {apt.patient_id && apt.status !== 'Completed' && apt.status !== 'Cancelled' && (
                      <Button size="sm" variant="outline" className="text-xs h-7 px-2"
                        onClick={e => { e.stopPropagation(); navigate(`/patients/${apt.patient_id}?tab=appointments`); }}>
                        Open Chart
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </Card>

        <Card className="p-6 border-0 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-sm font-semibold text-foreground">Recent Encounters</h3>
            <Link to="/audit" className="text-xs text-primary font-medium flex items-center gap-1 hover:underline">
              Audit Log <ArrowRight className="w-3 h-3" />
            </Link>
          </div>
          <div className="space-y-3">
            {encounters.length === 0 ? (
              <p className="text-sm text-muted-foreground">No recent encounters.</p>
            ) : encounters.slice(0,5).map((enc) => (
              <div key={enc.id} className="flex items-start gap-3 p-3 rounded-lg bg-muted/50">
                <Stethoscope className="w-4 h-4 mt-0.5 text-primary" />
                <div className="flex-1">
                  <p className="text-sm font-medium">{decodeURIComponent(enc.patient_name || '')}</p>
                  <p className="text-xs text-muted-foreground">{decodeURIComponent(enc.chief_complaint || enc.assessment || 'Encounter')}</p>
                  <Badge variant="secondary" className="text-xs mt-1">{enc.status}</Badge>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Add Patient Dialog */}
      <Dialog open={showAddPatient} onOpenChange={setShowAddPatient}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><UserPlus className="w-5 h-5" />Add New Patient</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 mt-2">
            <div className="col-span-2">
              <Label className="text-xs">Full Name *</Label>
              <Input className="mt-1" value={patientForm.full_name} onChange={e => setPatientForm(p => ({...p, full_name: e.target.value}))} placeholder="Patient full name" />
            </div>
            <div>
              <Label className="text-xs">Gender *</Label>
              <Select value={patientForm.gender} onValueChange={v => setPatientForm(p => ({...p, gender: v}))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Date of Birth</Label>
              <Input type="date" className="mt-1" value={patientForm.date_of_birth} onChange={e => setPatientForm(p => ({...p, date_of_birth: e.target.value}))} />
            </div>
            <div>
              <Label className="text-xs">National ID</Label>
              <Input className="mt-1" value={patientForm.national_id} onChange={e => setPatientForm(p => ({...p, national_id: e.target.value}))} placeholder="1XXXXXXXXXXXXXXXXX" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Rwanda National ID Card *</Label>
              <div className="mt-1 flex items-center gap-2">
                {patientForm.national_id_card ? (
                  <div className="flex items-center gap-2 flex-1">
                    <img src={patientForm.national_id_card} alt="ID Card" className="h-32 object-cover rounded border border-border" />
                    <div className="flex-1">
                      <p className="text-xs text-accent font-medium">✓ Card uploaded</p>
                      <button onClick={() => setPatientForm(p => ({...p, national_id_card: ''}))} className="text-xs text-destructive hover:underline">Remove</button>
                    </div>
                  </div>
                ) : (
                  <label className="flex-1 cursor-pointer">
                    <div className="border-2 border-dashed border-border rounded-lg p-3 text-center hover:bg-muted/50 transition-colors">
                      <Upload className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                      <p className="text-xs text-muted-foreground">Click to upload full ID card</p>
                    </div>
                    <input
                      type="file"
                      accept="image/*"
                      className="hidden"
                      onChange={e => e.target.files?.[0] && uploadIDCard(e.target.files[0])}
                      disabled={uploading}
                    />
                  </label>
                )}
                {uploading && <Loader2 className="w-4 h-4 animate-spin" />}
              </div>
            </div>
            <div>
              <Label className="text-xs">Phone</Label>
              <Input className="mt-1" value={patientForm.phone} onChange={e => setPatientForm(p => ({...p, phone: e.target.value}))} placeholder="+250 7XX XXX XXX" />
            </div>
            <div>
              <Label className="text-xs">District</Label>
              <Input className="mt-1" value={patientForm.district} onChange={e => setPatientForm(p => ({...p, district: e.target.value}))} placeholder="e.g. Gasabo" />
            </div>
            <div>
              <Label className="text-xs">Insurance Type</Label>
              <Select value={patientForm.insurance_type} onValueChange={v => setPatientForm(p => ({...p, insurance_type: v}))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select insurer" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="RSSB (RAMA)">RSSB (RAMA)</SelectItem>
                  <SelectItem value="MMI">MMI</SelectItem>
                  <SelectItem value="Mutuelle de Santé">Mutuelle de Santé</SelectItem>
                  <SelectItem value="Private">Private</SelectItem>
                  <SelectItem value="None">None</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2 flex gap-2 mt-2">
              <Button className="flex-1" onClick={addPatient} disabled={saving || !patientForm.full_name || !patientForm.gender}>
                {saving ? 'Saving...' : 'Add Patient & Open Chart'}
              </Button>
              <Button variant="outline" onClick={() => setShowAddPatient(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}