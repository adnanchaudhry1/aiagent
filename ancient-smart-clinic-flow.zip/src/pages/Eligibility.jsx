import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Sparkles, CheckCircle2, XCircle, AlertTriangle, ShieldCheck, Scan, MapPin, Clock, Copy, User, ArrowLeft, UserPlus, Upload } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { useQueryClient } from '@tanstack/react-query';
import { Textarea } from '@/components/ui/textarea';
import PageHeader from '@/components/shared/PageHeader';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const RWANDA_INSURERS = ['RSSB (RAMA)', 'MMI', 'Mutuelle de Santé', 'Private'];
const SECTION_TITLE = 'text-xs font-bold text-primary uppercase tracking-wider mb-3 flex items-center gap-2';
const SECTION_NUM = 'w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold';

export default function Eligibility() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [form, setForm] = useState({ insurance_id: '', national_id: '', insurance_type: '', patient_name: '', patient_id: '' });
  const [checking, setChecking] = useState(false);
  const [result, setResult] = useState(null);
  const [fraudAnalysis, setFraudAnalysis] = useState(null);
  const [showAddPatient, setShowAddPatient] = useState(false);
  const [patientForm, setPatientForm] = useState({ full_name: '', gender: '', date_of_birth: '', phone: '', district: '', insurance_type: '', national_id: '', national_id_card: '' });
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const { data: patients = [] } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });

  const { data: encounters = [] } = useQuery({
    queryKey: ['encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date', 100),
  });

  const uploadIDCard = async (file) => {
    if (!file) return;
    setUploading(true);
    try {
      const res = await base44.integrations.Core.UploadFile({ file });
      setPatientForm(p => ({ ...p, national_id_card: res.file_url }));
    } finally {
      setUploading(false);
    }
  };

  const addPatient = async () => {
    if (!patientForm.full_name || !patientForm.gender) return;
    // Check if patient already exists by national_id
    if (patientForm.national_id) {
      const existing = patients.find(p => p.national_id === patientForm.national_id);
      if (existing) {
        toast.error(`Patient already exists in system: ${existing.full_name}`);
        return;
      }
    }
    setSaving(true);
    try {
      const created = await base44.entities.Patient.create({ ...patientForm, status: 'Active' });
      queryClient.invalidateQueries({ queryKey: ['patients'] });
      setShowAddPatient(false);
      setPatientForm({ full_name: '', gender: '', date_of_birth: '', phone: '', district: '', insurance_type: '', national_id: '', national_id_card: '' });
      toast.success('Patient added successfully!');
      navigate(`/patients/${created.id}`);
    } finally {
      setSaving(false);
    }
  };

  const loadFromPatient = (pid) => {
    const p = patients.find(x => x.id === pid);
    if (p) {
      setForm({ insurance_id: p.insurance_id || '', national_id: p.national_id || '', insurance_type: p.insurance_type || '', patient_name: p.full_name || '', patient_id: pid });
      setResult(null);
      setFraudAnalysis(null);
    }
  };

  const checkEligibility = async () => {
    if (!form.insurance_type) { toast.error('Select an insurance provider'); return; }
    setChecking(true);
    setResult(null);
    setFraudAnalysis(null);
    try {
      // Get eligibility
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda real-time insurance eligibility verification system. Verify eligibility for:

Patient Name: ${form.patient_name || 'N/A'}
National ID: ${form.national_id || 'N/A'}
Insurance Provider: ${form.insurance_type}
Insurance Member ID: ${form.insurance_id || 'N/A'}

Rwanda insurance providers: RSSB (RAMA) — Rwanda Social Security Board, MMI — Military Medical Insurance, Mutuelle de Santé — Community Health Insurance.

Perform a detailed real-time eligibility verification as if querying the actual ${form.insurance_type} portal. Include co-payment rates per Rwanda's tariff structure, benefit limits, active/inactive status, and any fraud flags.`,
        response_json_schema: {
          type: 'object',
          properties: {
            is_eligible: { type: 'boolean' },
            status: { type: 'string' },
            member_since: { type: 'string' },
            coverage_end: { type: 'string' },
            plan_name: { type: 'string' },
            co_payment_percentage: { type: 'number' },
            covered_services: { type: 'array', items: { type: 'string' } },
            excluded_services: { type: 'array', items: { type: 'string' } },
            prior_auth_required: { type: 'array', items: { type: 'string' } },
            benefit_limits: { type: 'array', items: { type: 'string' } },
            fraud_risk: { type: 'string' },
            fraud_notes: { type: 'string' },
            notes: { type: 'string' },
          }
        }
      });
      setResult(res);

      // Perform fraud analysis
      const patientEncounters = encounters.filter(e => e.patient_id === form.patient_id);
      const fraudRes = await base44.integrations.Core.InvokeLLM({
        prompt: `Analyze fraud risk for insurance claim eligibility check:

Patient: ${form.patient_name}
National ID: ${form.national_id}
Insurance: ${form.insurance_type}
Member ID: ${form.insurance_id}

Recent Encounters: ${patientEncounters.length}
Encounter History: ${patientEncounters.slice(0, 3).map(e => `${e.encounter_date?.slice(0, 10)} - ${e.chief_complaint}`).join('; ')}

Check for:
1. Location Inconsistencies (patient's district vs encounter locations)
2. Visit Frequency Abuse (multiple visits same day/week from different locations)
3. Duplicate Service Usage (same service billed multiple times)
4. Member ID Mismatches (ID variations across records)
5. Pattern Anomalies (unusual visit patterns for diagnosis)

Return fraud risk assessment.`,
        response_json_schema: {
          type: 'object',
          properties: {
            location_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
            location_notes: { type: 'string' },
            visit_frequency_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
            visit_frequency_notes: { type: 'string' },
            duplicate_usage_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
            duplicate_usage_notes: { type: 'string' },
            overall_fraud_risk: { type: 'string', enum: ['None', 'Low', 'Medium', 'High'] },
            recommendations: { type: 'array', items: { type: 'string' } }
          }
        }
      });
      setFraudAnalysis(fraudRes);
    } catch (e) {
      toast.error('Eligibility check failed. Please try again.');
    } finally {
      setChecking(false);
    }
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <div className="flex items-center gap-2 mb-4">
        <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
          <ArrowLeft className="w-4 h-4" />
        </Button>
      </div>
      <PageHeader
        title="Eligibility Verification & Fraud Prevention"
        subtitle="Real-time insurance eligibility + biometric identity verification + anti-fraud detection"
      />

      {/* SECTION 1: Patient Identification */}
      <Card className="p-6 border-0 shadow-sm">
        <div className={SECTION_TITLE}>
          <span className={SECTION_NUM}>1</span>
          Patient Identification
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="md:col-span-2">
            <Label className="text-xs">Load from Patient Database (optional)</Label>
            <Select value={form.patient_id || ''} onValueChange={loadFromPatient}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select a registered patient..." /></SelectTrigger>
              <SelectContent>
                {patients.map(p => <SelectItem key={p.id} value={p.id}>{p.full_name} — {p.insurance_type || 'No insurance'}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Patient Name {form.patient_id && '(from database)'}</Label>
            <Input className="mt-1" value={form.patient_name} onChange={e => setForm(f => ({...f, patient_name: e.target.value}))} placeholder="Full name" disabled={!!form.patient_id} />
          </div>
          <div>
            <Label className="text-xs">National ID {form.patient_id && '(from database)'}</Label>
            <Input className="mt-1" value={form.national_id} onChange={e => setForm(f => ({...f, national_id: e.target.value}))} placeholder="1XXXXXXXXXXXXXXXXX" disabled={!!form.patient_id} />
          </div>
        </div>
      </Card>

      {/* SECTION 2: National ID Card Verification */}
      <Card className="p-6 border-0 shadow-sm bg-primary/5">
        <div className={SECTION_TITLE}>
          <span className={SECTION_NUM}>2</span>
          National ID Card
        </div>
        <div className="flex justify-center">
          {form.patient_id && patients.find(p => p.id === form.patient_id)?.national_id_card ? (
            <div className="w-full max-w-sm">
              <img 
                src={patients.find(p => p.id === form.patient_id)?.national_id_card} 
                alt="Rwanda National ID Card"
                className="w-full rounded-lg shadow-lg border-2 border-primary/20"
              />
              <div className="mt-4 p-3 bg-background rounded-lg border border-border/50">
                <p className="text-xs font-semibold text-foreground mb-2">Verified Information:</p>
                <div className="text-xs space-y-1">
                  <p><span className="text-muted-foreground">Name:</span> <span className="font-medium">{form.patient_name}</span></p>
                  <p><span className="text-muted-foreground">National ID:</span> <span className="font-medium font-mono">{form.national_id}</span></p>
                </div>
              </div>
            </div>
          ) : (
            <div className="w-full max-w-sm h-64 bg-muted rounded-lg border-2 border-dashed border-border flex items-center justify-center">
              <div className="text-center">
                <Scan className="w-12 h-12 text-muted-foreground mx-auto mb-2" />
                <p className="text-sm font-medium text-foreground">No ID Card on File</p>
                <p className="text-xs text-muted-foreground mt-1">Select a patient with registered ID card</p>
              </div>
            </div>
          )}
        </div>
      </Card>

      {/* SECTION 3: Eligibility Check */}
      <Card className="p-6 border-0 shadow-sm">
        <div className={SECTION_TITLE}>
          <span className={SECTION_NUM}>3</span>
          Eligibility Check
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
          <div>
            <Label className="text-xs">Insurance Provider *</Label>
            <Select value={form.insurance_type} onValueChange={v => setForm(f => ({...f, insurance_type: v}))}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select insurer" /></SelectTrigger>
              <SelectContent>
                {RWANDA_INSURERS.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">Insurance Member ID</Label>
            <Input className="mt-1" value={form.insurance_id} onChange={e => setForm(f => ({...f, insurance_id: e.target.value}))} placeholder="Member ID" />
          </div>
        </div>
        <Button className="gap-2 w-full md:w-auto" onClick={checkEligibility} disabled={checking || !form.insurance_type}>
          {checking ? <><Loader2 className="w-4 h-4 animate-spin" /> Verifying...</> : <><ShieldCheck className="w-4 h-4" /> Verify Eligibility</>}
        </Button>
      </Card>

      {/* Add Patient Section — shown after eligibility check or always */}
      <Card className="p-5 border-0 shadow-sm bg-muted/30">
        <div className="flex items-center justify-between">
          <div>
            <p className="text-sm font-semibold">Patient Registration</p>
            <p className="text-xs text-muted-foreground">Add a new patient to the system after eligibility verification</p>
          </div>
          <Button className="gap-2" onClick={() => {
            // Pre-fill from form if available
            setPatientForm(p => ({
              ...p,
              full_name: form.patient_name || '',
              national_id: form.national_id || '',
              insurance_id: form.insurance_id || '',
              insurance_type: form.insurance_type || '',
            }));
            // Check if already in system
            if (form.national_id) {
              const existing = patients.find(p => p.national_id === form.national_id);
              if (existing) {
                toast.info(`This patient is already in the system: ${existing.full_name}`);
                navigate(`/patients/${existing.id}`);
                return;
              }
            }
            setShowAddPatient(true);
          }}>
            <UserPlus className="w-4 h-4" /> Add Patient
          </Button>
        </div>
      </Card>

      {/* Add Patient Dialog */}
      <Dialog open={showAddPatient} onOpenChange={setShowAddPatient}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><UserPlus className="w-5 h-5" />Add New Patient</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 mt-2">
            <div className="col-span-2">
              <Label className="text-xs">Full Name *</Label>
              <Input className="mt-1" value={patientForm.full_name} onChange={e => setPatientForm(p => ({...p, full_name: e.target.value}))} placeholder="Patient full name" />
            </div>
            <div>
              <Label className="text-xs">Gender *</Label>
              <Select value={patientForm.gender} onValueChange={v => setPatientForm(p => ({...p, gender: v}))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Date of Birth</Label>
              <Input type="date" className="mt-1" value={patientForm.date_of_birth} onChange={e => setPatientForm(p => ({...p, date_of_birth: e.target.value}))} />
            </div>
            <div>
              <Label className="text-xs">National ID</Label>
              <Input className="mt-1" value={patientForm.national_id} onChange={e => setPatientForm(p => ({...p, national_id: e.target.value}))} placeholder="1XXXXXXXXXXXXXXXXX" />
            </div>
            <div>
              <Label className="text-xs">Phone</Label>
              <Input className="mt-1" value={patientForm.phone} onChange={e => setPatientForm(p => ({...p, phone: e.target.value}))} placeholder="+250 7XX XXX XXX" />
            </div>
            <div>
              <Label className="text-xs">District</Label>
              <Input className="mt-1" value={patientForm.district} onChange={e => setPatientForm(p => ({...p, district: e.target.value}))} placeholder="e.g. Gasabo" />
            </div>
            <div>
              <Label className="text-xs">Insurance Type</Label>
              <Select value={patientForm.insurance_type} onValueChange={v => setPatientForm(p => ({...p, insurance_type: v}))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select insurer" /></SelectTrigger>
                <SelectContent>
                  {RWANDA_INSURERS.map(i => <SelectItem key={i} value={i}>{i}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Rwanda National ID Card</Label>
              <div className="mt-1">
                {patientForm.national_id_card ? (
                  <div className="flex items-center gap-2">
                    <img src={patientForm.national_id_card} alt="ID Card" className="h-24 object-cover rounded border border-border" />
                    <button onClick={() => setPatientForm(p => ({...p, national_id_card: ''}))} className="text-xs text-destructive hover:underline">Remove</button>
                  </div>
                ) : (
                  <label className="cursor-pointer">
                    <div className="border-2 border-dashed border-border rounded-lg p-3 text-center hover:bg-muted/50 transition-colors">
                      <Upload className="w-4 h-4 mx-auto text-muted-foreground mb-1" />
                      <p className="text-xs text-muted-foreground">Click to upload ID card</p>
                    </div>
                    <input type="file" accept="image/*" className="hidden" onChange={e => e.target.files?.[0] && uploadIDCard(e.target.files[0])} disabled={uploading} />
                  </label>
                )}
                {uploading && <Loader2 className="w-4 h-4 animate-spin mt-1" />}
              </div>
            </div>
            <div className="col-span-2 flex gap-2 mt-2">
              <Button className="flex-1" onClick={addPatient} disabled={saving || !patientForm.full_name || !patientForm.gender}>
                {saving ? 'Saving...' : 'Add Patient & Open Chart'}
              </Button>
              <Button variant="outline" onClick={() => setShowAddPatient(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {result && (
        <>
          {/* SECTION 4: Fraud Signals */}
          {fraudAnalysis && (
            <Card className={`p-6 border-0 shadow-sm border-l-4 ${fraudAnalysis.overall_fraud_risk === 'None' ? 'border-l-accent bg-accent/5' : fraudAnalysis.overall_fraud_risk === 'Low' ? 'border-l-orange-300 bg-orange-50/50' : 'border-l-destructive bg-destructive/5'}`}>
              <div className={SECTION_TITLE}>
                <span className={SECTION_NUM}>4</span>
                Fraud Detection Analysis
              </div>
              <div className="space-y-4">
                {/* Location Risk */}
                <div className="p-3 bg-background rounded-lg border border-border/50">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-semibold flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" /> Location Consistency</p>
                    <Badge className={`text-xs ${fraudAnalysis.location_risk === 'None' ? 'bg-accent/10 text-accent' : fraudAnalysis.location_risk === 'Low' ? 'bg-orange-100 text-orange-700' : 'bg-destructive/10 text-destructive'}`}>
                      {fraudAnalysis.location_risk}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{fraudAnalysis.location_notes}</p>
                </div>

                {/* Visit Frequency Risk */}
                <div className="p-3 bg-background rounded-lg border border-border/50">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-semibold flex items-center gap-1.5"><Clock className="w-3.5 h-3.5" /> Visit Frequency</p>
                    <Badge className={`text-xs ${fraudAnalysis.visit_frequency_risk === 'None' ? 'bg-accent/10 text-accent' : fraudAnalysis.visit_frequency_risk === 'Low' ? 'bg-orange-100 text-orange-700' : 'bg-destructive/10 text-destructive'}`}>
                      {fraudAnalysis.visit_frequency_risk}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{fraudAnalysis.visit_frequency_notes}</p>
                </div>

                {/* Duplicate Usage Risk */}
                <div className="p-3 bg-background rounded-lg border border-border/50">
                  <div className="flex items-center justify-between mb-1">
                    <p className="text-xs font-semibold flex items-center gap-1.5"><Copy className="w-3.5 h-3.5" /> Duplicate Service Usage</p>
                    <Badge className={`text-xs ${fraudAnalysis.duplicate_usage_risk === 'None' ? 'bg-accent/10 text-accent' : fraudAnalysis.duplicate_usage_risk === 'Low' ? 'bg-orange-100 text-orange-700' : 'bg-destructive/10 text-destructive'}`}>
                      {fraudAnalysis.duplicate_usage_risk}
                    </Badge>
                  </div>
                  <p className="text-xs text-muted-foreground">{fraudAnalysis.duplicate_usage_notes}</p>
                </div>

                {/* Overall Risk & Recommendations */}
                <div className="mt-4 p-3 bg-muted/30 rounded-lg">
                  <p className="text-xs font-semibold mb-2">Overall Fraud Risk Assessment:</p>
                  <Badge className={`${fraudAnalysis.overall_fraud_risk === 'None' ? 'bg-accent text-white' : fraudAnalysis.overall_fraud_risk === 'Low' ? 'bg-orange-500 text-white' : fraudAnalysis.overall_fraud_risk === 'Medium' ? 'bg-orange-600 text-white' : 'bg-destructive text-white'}`}>
                    {fraudAnalysis.overall_fraud_risk}
                  </Badge>
                  {fraudAnalysis.recommendations?.length > 0 && (
                    <div className="mt-2 space-y-1">
                      {fraudAnalysis.recommendations.map((rec, i) => (
                        <p key={i} className="text-xs text-foreground/80">• {rec}</p>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            </Card>
          )}

          {/* SECTION 5: Final Decision */}
          <Card className={`p-6 border-0 shadow-sm ${result.is_eligible ? 'bg-accent/5 border-l-4 border-l-accent' : 'bg-destructive/5 border-l-4 border-l-destructive'}`}>
            <div className={SECTION_TITLE}>
              <span className={SECTION_NUM}>5</span>
              Final Decision
            </div>
            <div className="flex items-center gap-4 mb-4">
              {result.is_eligible
                ? <CheckCircle2 className="w-12 h-12 text-accent shrink-0" />
                : <XCircle className="w-12 h-12 text-destructive shrink-0" />}
              <div className="flex-1">
                <p className="text-2xl font-bold">{result.is_eligible ? '✓ ELIGIBLE FOR COVERAGE' : '✗ NOT ELIGIBLE'}</p>
                <p className="text-sm text-muted-foreground mt-1">{result.status}</p>
              </div>
              <div className="text-right">
                <Badge className={`text-sm px-3 py-1.5 ${fraudAnalysis?.overall_fraud_risk === 'High' ? 'bg-destructive text-white' : fraudAnalysis?.overall_fraud_risk === 'Medium' ? 'bg-orange-500 text-white' : 'bg-accent text-white'}`}>
                  Risk: {fraudAnalysis?.overall_fraud_risk || 'Analyzing...'}
                </Badge>
              </div>
            </div>

            {/* Coverage Details */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              {result.plan_name && (
                <div className="p-2 bg-background rounded border border-border/50">
                  <p className="text-xs text-muted-foreground">Plan</p>
                  <p className="text-sm font-semibold">{result.plan_name}</p>
                </div>
              )}
              {result.co_payment_percentage !== undefined && (
                <div className="p-2 bg-background rounded border border-border/50">
                  <p className="text-xs text-muted-foreground">Co-Payment</p>
                  <p className="text-sm font-semibold">{result.co_payment_percentage}%</p>
                </div>
              )}
              {result.member_since && (
                <div className="p-2 bg-background rounded border border-border/50">
                  <p className="text-xs text-muted-foreground">Member Since</p>
                  <p className="text-sm font-semibold">{result.member_since}</p>
                </div>
              )}
              {result.coverage_end && (
                <div className="p-2 bg-background rounded border border-border/50">
                  <p className="text-xs text-muted-foreground">Coverage Expires</p>
                  <p className="text-sm font-semibold">{result.coverage_end}</p>
                </div>
              )}
            </div>

            {/* Covered/Not Covered Services */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3 mb-4">
              {result.covered_services?.length > 0 && (
                <div className="p-3 bg-accent/5 rounded-lg border border-accent/20">
                  <p className="text-xs font-semibold text-accent mb-2">✓ Covered Services</p>
                  <div className="space-y-1">
                    {result.covered_services.slice(0, 4).map((s, i) => (
                      <p key={i} className="text-xs text-foreground/80">{s}</p>
                    ))}
                  </div>
                </div>
              )}
              {result.excluded_services?.length > 0 && (
                <div className="p-3 bg-destructive/5 rounded-lg border border-destructive/20">
                  <p className="text-xs font-semibold text-destructive mb-2">✗ Not Covered</p>
                  <div className="space-y-1">
                    {result.excluded_services.slice(0, 4).map((s, i) => (
                      <p key={i} className="text-xs text-foreground/80">{s}</p>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {result.prior_auth_required?.length > 0 && (
              <div className="p-3 bg-orange-50/50 rounded-lg border border-orange-200 mb-4">
                <div className="flex items-center gap-2 mb-2">
                  <AlertTriangle className="w-4 h-4 text-orange-600" />
                  <p className="text-xs font-semibold text-orange-600">Prior Authorization Required:</p>
                </div>
                <div className="flex flex-wrap gap-1.5">
                  {result.prior_auth_required.map((a, i) => <Badge key={i} className="text-xs bg-orange-100 text-orange-700">{a}</Badge>)}
                </div>
              </div>
            )}

            {result.notes && (
              <div className="p-3 bg-muted/40 rounded-lg">
                <p className="text-xs font-semibold mb-1">Verification Notes</p>
                <p className="text-xs text-muted-foreground">{result.notes}</p>
              </div>
            )}
          </Card>
        </>
      )}
      </div>
      );
      }