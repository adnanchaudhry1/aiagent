import React, { useState, useEffect } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Mic, Sparkles, Loader2, Save, CheckCircle2, AlertTriangle,
  ArrowRight, Pill, FlaskConical, GitBranch, Plus, Trash2
} from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

import EncounterHeader from '@/components/encounter/EncounterHeader';
import VitalsSection from '@/components/encounter/VitalsSection';
import DiagnosisSection from '@/components/encounter/DiagnosisSection';
import MedicationOrderSection from '@/components/encounter/MedicationOrderSection';
import LabOrderSection from '@/components/encounter/LabOrderSection';
import AIListenPanel from '@/components/encounter/AIListenPanel';
import EncounterGISSection from '@/components/encounter/EncounterGISSection';
import EncounterHistoryReview from '@/components/encounter/EncounterHistoryReview';
import { useEncounterWorkflow } from '@/components/encounter/EncounterWorkflowNavigator';
import EvidenceBasedPanel from '@/components/encounter/EvidenceBasedPanel';

const SECTION_TITLE = 'text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2';
const SECTION_NUM = 'w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold';

const DISPOSITIONS = ['Discharged', 'Admitted', 'Referred', 'Transferred', 'Deceased', 'Left AMA', 'Follow-up'];
const PROCEDURE_LIST = ['Wound dressing', 'IV access', 'Blood draw', 'ECG', 'Nebulization', 'Suturing', 'Catheterization', 'NGT insertion', 'Splinting', 'Debridement'];

function SectionCard({ number, title, children }) {
  return (
    <Card className="p-4 border border-border/60 shadow-sm rounded-xl">
      <div className={SECTION_TITLE}>
        <span className={SECTION_NUM}>{number}</span>
        {title}
      </div>
      {children}
    </Card>
  );
}

function AISuggestBox({ label, onSuggest, context, disabled }) {
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSuggest = async () => {
    const prompt = input || context || '';
    if (!prompt.trim()) { toast.error('Add some context first'); return; }
    setLoading(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are Murava AI clinical copilot for Rwanda. Based on: "${prompt}", provide a concise clinical suggestion for "${label}". Be specific, evidence-based, and Rwanda-appropriate.`,
      });
      onSuggest(result);
      setInput('');
    } catch {
      toast.error('AI suggestion failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex gap-2 mt-2">
      <Input
        className="h-8 text-xs flex-1"
        placeholder={`Type context for AI ${label} suggestion...`}
        value={input}
        onChange={e => setInput(e.target.value)}
        onKeyDown={e => e.key === 'Enter' && handleSuggest()}
        disabled={disabled}
      />
      <Button size="sm" className="h-8 gap-1.5 text-xs shrink-0" onClick={handleSuggest} disabled={loading || disabled}>
        {loading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />}
        AI Suggest
      </Button>
    </div>
  );
}

export default function Encounter() {
  const urlParams = new URLSearchParams(window.location.search);
  const paramPatientId = urlParams.get('patientId');
  const paramPatientName = decodeURIComponent(urlParams.get('patientName') || '');
  const paramAppointmentId = urlParams.get('appointmentId');
  const paramReason = decodeURIComponent(urlParams.get('reason') || '') || null;
  const paramEncounterId = urlParams.get('encounterId');
  const paramWorkflow = urlParams.get('workflow') === 'true';

  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: patients = [] } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });

  const { data: existingEncounter } = useQuery({
    queryKey: ['encounter-load', paramEncounterId],
    queryFn: () => base44.entities.Encounter.filter({ id: paramEncounterId }).then(r => r[0]),
    enabled: !!paramEncounterId,
  });

  const { data: allEncounters = [] } = useQuery({
    queryKey: ['all-encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date', 100),
  });

  // ---- Encounter Header ----
  const [header, setHeader] = useState({
    patient_id: paramPatientId || '',
    patient_name: paramPatientName || '',
    encounter_type: 'Outpatient Visit',
    encounter_date: new Date().toISOString().slice(0, 10),
    location: 'Outpatient Clinic',
    provider: '',
  });

  // ---- All section state ----
  const [chiefComplaint, setChiefComplaint] = useState(paramReason || '');
  const [vitals, setVitals] = useState({});
  const [history, setHistory] = useState({ hpi: '', past_medical: '', surgical: '', family: '', social: '' });
  const [examination, setExamination] = useState({ general: '', cvs: '', rs: '', abdomen: '', cns: '', other: '' });
  const [diagnoses, setDiagnoses] = useState([]);
  const [medications, setMedications] = useState([]);
  const [labOrders, setLabOrders] = useState([]);
  const [procedures, setProcedures] = useState([]);
  const [clinicalNotes, setClinicalNotes] = useState('');
  const [disposition, setDisposition] = useState({ disposition: '', follow_up_date: '', referral: '' });
  const [transcription, setTranscription] = useState('');

  // ---- UI state ----
   const [encounterId, setEncounterId] = useState(null);
   const [status, setStatus] = useState('In Progress');
   const [saving, setSaving] = useState(false);
   const [showAIListen, setShowAIListen] = useState(false);
   const [newProcedure, setNewProcedure] = useState('');
   const [autoNavigateAfterApprove, setAutoNavigateAfterApprove] = useState(false);

   // Auto-navigate after approval (pass appointmentId through workflow)
   useEncounterWorkflow('encounter', encounterId, autoNavigateAfterApprove, paramAppointmentId);

  // Load existing encounter
  useEffect(() => {
    if (!existingEncounter) return;
    const e = existingEncounter;
    setHeader({ patient_id: e.patient_id || '', patient_name: e.patient_name || '', encounter_type: 'Outpatient Visit', encounter_date: e.encounter_date?.slice(0, 10) || new Date().toISOString().slice(0, 10), location: 'Outpatient Clinic', provider: '' });
    setChiefComplaint(e.chief_complaint || '');
    setTranscription(e.transcription || '');
    setExamination(prev => ({ ...prev, general: e.objective || '' }));
    if (e.icd_codes) { try { setDiagnoses(JSON.parse(e.icd_codes)); } catch {} }
    if (e.medications) { try { setMedications(JSON.parse(e.medications)); } catch {} }
    if (e.lab_orders) { try { setLabOrders(JSON.parse(e.lab_orders)); } catch {} }
    setEncounterId(e.id);
    setStatus(e.status || 'In Progress');
  }, [existingEncounter]);

  // AI Listen: populate everything from speech
  const handleAIPopulate = (result, rawTranscript) => {
    setTranscription(rawTranscript || '');
    if (result.chief_complaint) setChiefComplaint(result.chief_complaint);
    if (result.vitals) setVitals(v => ({ ...v, ...result.vitals }));
    if (result.history_present_illness || result.past_medical_history || result.surgical_history || result.family_history || result.social_history) {
      setHistory({
        hpi: result.history_present_illness || '',
        past_medical: result.past_medical_history || '',
        surgical: result.surgical_history || '',
        family: result.family_history || '',
        social: result.social_history || '',
      });
    }
    if (result.general_examination || result.systemic_examination) {
      setExamination(ex => ({
        ...ex,
        general: result.general_examination || ex.general,
        other: result.systemic_examination || ex.other,
      }));
    }
    if (result.diagnoses?.length) setDiagnoses(result.diagnoses);
    if (result.medications?.length) setMedications(result.medications);
    if (result.lab_orders?.length) setLabOrders(result.lab_orders);
    if (result.procedures?.length) setProcedures(result.procedures);
    if (result.clinical_notes) setClinicalNotes(result.clinical_notes);
    if (result.disposition || result.follow_up_date || result.referral) {
      setDisposition({ disposition: result.disposition || '', follow_up_date: result.follow_up_date || '', referral: result.referral || '' });
    }
  };

  const selectedPatient = patients.find(p => p.id === header.patient_id);

  const saveEncounter = async (finalStatus) => {
    if (!header.patient_id) { toast.error('Please select a patient first'); return null; }
    setSaving(true);
    const data = {
      patient_id: header.patient_id,
      patient_name: header.patient_name,
      encounter_date: new Date(header.encounter_date).toISOString(),
      status: finalStatus,
      chief_complaint: chiefComplaint,
      transcription,
      subjective: history.hpi,
      objective: examination.general,
      assessment: diagnoses.map(d => `${d.code} ${d.description}`).join('; '),
      plan: clinicalNotes,
      medications: JSON.stringify(medications),
      lab_orders: JSON.stringify(labOrders),
      icd_codes: JSON.stringify(diagnoses),
      ai_suggestions_log: JSON.stringify({ saved_at: new Date().toISOString() }),
      doctor_actions_log: JSON.stringify({ action: finalStatus, at: new Date().toISOString() }),
    };
    let savedId = encounterId;
    if (encounterId) {
      await base44.entities.Encounter.update(encounterId, data);
    } else {
      const created = await base44.entities.Encounter.create({ ...data, encounter_number: `ENC-${Date.now().toString().slice(-8)}` });
      savedId = created.id;
      setEncounterId(created.id);
    }
    setStatus(finalStatus);
    queryClient.invalidateQueries({ queryKey: ['encounters'] });
    queryClient.invalidateQueries({ queryKey: ['patient-encounters', header.patient_id] });
    queryClient.invalidateQueries({ queryKey: ['patient-claims', header.patient_id] });
    toast.success(`Encounter ${finalStatus === 'Doctor Approved' ? 'approved & saved to patient chart' : 'saved as draft'}`);
    setSaving(false);
    return savedId;
  };

  const approveAndCode = async () => {
     const id = await saveEncounter('Doctor Approved');
     if (id) {
       // Link encounter to appointment if appointmentId present
       if (paramAppointmentId) {
         try {
           await base44.entities.Appointment.update(paramAppointmentId, {
             encounter_id: id,
             status: 'In Progress',
           });
           queryClient.invalidateQueries({ queryKey: ['appointments'] });
         } catch {}
       }
       // Auto-create a draft insurance claim linked to this encounter
       const patient = patients.find(p => p.id === header.patient_id);
       if (patient) {
         try {
           await base44.entities.InsuranceClaim.create({
             patient_id: header.patient_id,
             patient_name: header.patient_name,
             encounter_id: id,
             encounter_number: `ENC-${id.slice(-8)}`,
             insurance_type: patient.insurance_type || 'None',
             insurance_member_id: patient.insurance_id || '',
             icd_codes: JSON.stringify(diagnoses),
             cpt_codes: '',
             status: 'Draft',
             claim_number: `CLM-${Date.now().toString().slice(-8)}`,
           });
           queryClient.invalidateQueries({ queryKey: ['claims'] });
           toast.success('Draft claim created automatically');
         } catch {}
       }
       setEncounterId(id);
       if (paramWorkflow) {
         const params = new URLSearchParams();
         params.set('encounterId', id);
         if (paramAppointmentId) params.set('appointmentId', paramAppointmentId);
         if (paramPatientId) params.set('patientId', paramPatientId);
         if (paramPatientName) params.set('patientName', paramPatientName);
         params.set('workflow', 'true');
         navigate(`/coding?${params.toString()}`);
       } else {
         setAutoNavigateAfterApprove(true);
       }
     }
   };

  return (
    <div className="max-w-7xl space-y-4">
      {/* Top bar */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <Button variant="ghost" size="icon" onClick={() => header.patient_id ? navigate(`/patients/${header.patient_id}?tab=encounters`) : navigate('/patients')}>
            <ArrowRight className="w-4 h-4 rotate-180" />
          </Button>
          <div>
            <h1 className="text-xl font-bold">Clinical Encounter</h1>
            <p className="text-xs text-muted-foreground">{paramAppointmentId ? 'From Appointment · ' : ''}
              {header.patient_name || 'No patient selected'}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            className="gap-2 border-primary text-primary hover:bg-primary/5"
            onClick={() => setShowAIListen(true)}
          >
            <Mic className="w-4 h-4" /> AI Listen
          </Button>
          <Button variant="outline" className="gap-2" onClick={async () => {
            const id = await saveEncounter('Draft');
            if (id && header.patient_id) navigate(`/patients/${header.patient_id}?tab=encounters`);
          }} disabled={saving}>
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : <Save className="w-4 h-4" />}
            Save Draft
          </Button>
          <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={approveAndCode} disabled={saving}>
            <CheckCircle2 className="w-4 h-4" /> Approve & Code
          </Button>
          <Badge variant="outline" className="text-xs">{status}</Badge>
        </div>
      </div>

      {/* Encounter Header */}
       <EncounterHeader
         form={header}
         onChange={changes => setHeader(h => ({ ...h, ...changes }))}
         patients={patients}
         status={status}
       />

      {/* History Review Section */}
       <EncounterHistoryReview
         currentEncounter={existingEncounter || { patient_id: header.patient_id }}
         allEncounters={allEncounters}
       />

      {/* Main grid — 3 columns like OpenMRS */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">

        {/* ===== LEFT COLUMN ===== */}
        <div className="space-y-4">

          {/* 1. Chief Complaint */}
          <SectionCard number="1" title="Chief Complaint">
            <Textarea
              className="min-h-[80px] text-sm"
              placeholder="Chief complaint..."
              value={chiefComplaint}
              onChange={e => setChiefComplaint(e.target.value)}
            />
            <AISuggestBox label="Chief Complaint" context={chiefComplaint} onSuggest={v => setChiefComplaint(prev => prev + '\n' + v)} />
          </SectionCard>

          {/* 2. Vitals */}
          <SectionCard number="2" title="Vitals">
            <VitalsSection vitals={vitals} onChange={setVitals} aiContext={chiefComplaint} />
          </SectionCard>

          {/* 3. History */}
          <SectionCard number="3" title="History">
            {[
              { key: 'hpi', label: 'History of Present Illness' },
              { key: 'past_medical', label: 'Past Medical History' },
              { key: 'surgical', label: 'Surgical History' },
              { key: 'family', label: 'Family History' },
              { key: 'social', label: 'Social History' },
            ].map(f => (
              <div key={f.key} className="mb-3 last:mb-0">
                <Label className="text-xs text-muted-foreground">{f.label}</Label>
                <Textarea
                  className="mt-1 min-h-[60px] text-xs"
                  placeholder={f.label + '...'}
                  value={history[f.key]}
                  onChange={e => setHistory(h => ({ ...h, [f.key]: e.target.value }))}
                />
                <AISuggestBox label={f.label} context={`${chiefComplaint} ${history[f.key]}`} onSuggest={v => setHistory(h => ({ ...h, [f.key]: h[f.key] + '\n' + v }))} />
              </div>
            ))}
          </SectionCard>

          {/* 9. Clinical Notes */}
          <SectionCard number="9" title="Notes / Clinical Notes">
            <Textarea
              className="min-h-[100px] text-sm"
              placeholder="Clinical notes, advice, instructions..."
              value={clinicalNotes}
              onChange={e => setClinicalNotes(e.target.value)}
            />
            <AISuggestBox label="Clinical Notes" context={`${chiefComplaint} ${JSON.stringify(diagnoses)}`} onSuggest={v => setClinicalNotes(prev => prev + '\n' + v)} />
          </SectionCard>
        </div>

        {/* ===== MIDDLE COLUMN ===== */}
        <div className="space-y-4">

          {/* 4. Examination */}
          <SectionCard number="4" title="Examination">
            {[
              { key: 'general', label: 'General Examination' },
              { key: 'cvs', label: 'CVS' },
              { key: 'rs', label: 'RS' },
              { key: 'abdomen', label: 'Abdomen' },
              { key: 'cns', label: 'CNS' },
            ].map(f => (
              <div key={f.key} className="mb-3 last:mb-0">
                <Label className="text-xs font-semibold text-muted-foreground">{f.label}</Label>
                <Textarea
                  className="mt-1 min-h-[60px] text-xs"
                  placeholder={f.label + '...'}
                  value={examination[f.key]}
                  onChange={e => setExamination(ex => ({ ...ex, [f.key]: e.target.value }))}
                />
                <AISuggestBox label={f.label} context={`${chiefComplaint} ${history.hpi}`} onSuggest={v => setExamination(ex => ({ ...ex, [f.key]: ex[f.key] + '\n' + v }))} />
              </div>
            ))}
          </SectionCard>

          {/* 5. Diagnosis */}
          <SectionCard number="5" title="Diagnosis">
            <DiagnosisSection diagnoses={diagnoses} onChange={setDiagnoses} />
          </SectionCard>

          {/* 10. Disposition */}
          <SectionCard number="10" title="Disposition / Outcome">
            <div className="grid grid-cols-1 gap-3">
              <div>
                <Label className="text-xs text-muted-foreground">Disposition *</Label>
                <Select value={disposition.disposition} onValueChange={v => setDisposition(d => ({ ...d, disposition: v }))}>
                  <SelectTrigger className="mt-1 h-8 text-xs"><SelectValue placeholder="Select disposition" /></SelectTrigger>
                  <SelectContent>
                    {DISPOSITIONS.map(d => <SelectItem key={d} value={d} className="text-xs">{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Follow-up Date</Label>
                <Input type="date" className="mt-1 h-8 text-xs" value={disposition.follow_up_date} onChange={e => setDisposition(d => ({ ...d, follow_up_date: e.target.value }))} />
              </div>
              <div>
                <Label className="text-xs text-muted-foreground">Referral (if any)</Label>
                <Input className="mt-1 h-8 text-xs" placeholder="Search referral location..." value={disposition.referral} onChange={e => setDisposition(d => ({ ...d, referral: e.target.value }))} />
              </div>
            </div>
          </SectionCard>
        </div>

        {/* ===== RIGHT COLUMN ===== */}
        <div className="space-y-4">

          {/* 6. Orders / Tests */}
          <SectionCard number="6" title="Orders / Tests">
            <LabOrderSection labOrders={labOrders} onChange={setLabOrders} />
          </SectionCard>

          {/* 7. Medications */}
          <SectionCard number="7" title="Medications / Drug Orders">
            <MedicationOrderSection medications={medications} onChange={setMedications} />
          </SectionCard>

          {/* 8. Procedures */}
          <SectionCard number="8" title="Procedures">
            <div className="flex gap-2 mb-3">
              <Input
                className="h-8 text-xs flex-1"
                placeholder="Search procedure name..."
                value={newProcedure}
                onChange={e => setNewProcedure(e.target.value)}
                onKeyDown={e => {
                  if (e.key === 'Enter' && newProcedure.trim()) {
                    setProcedures(prev => [...prev, newProcedure.trim()]);
                    setNewProcedure('');
                  }
                }}
              />
              <Button size="sm" className="h-8 gap-1 text-xs bg-primary" onClick={() => {
                if (newProcedure.trim()) { setProcedures(prev => [...prev, newProcedure.trim()]); setNewProcedure(''); }
              }}>
                <Plus className="w-3 h-3" /> Add
              </Button>
            </div>
            {/* Quick add procedures */}
            <div className="flex flex-wrap gap-1.5 mb-3">
              {PROCEDURE_LIST.slice(0, 5).map(p => (
                <button key={p} className="text-xs px-2 py-0.5 rounded-full border hover:bg-primary/10 hover:border-primary/40 transition-colors"
                  onClick={() => { if (!procedures.includes(p)) setProcedures(prev => [...prev, p]); }}>
                  + {p}
                </button>
              ))}
            </div>
            <div className="space-y-1">
              {procedures.length === 0 ? (
                <p className="text-xs text-muted-foreground">None</p>
              ) : (
                <table className="w-full text-xs">
                  <thead><tr className="border-b"><th className="text-left py-1 font-semibold text-muted-foreground">Procedure</th><th className="py-1"></th></tr></thead>
                  <tbody>
                    {procedures.map((p, i) => (
                      <tr key={i} className="border-b last:border-0">
                        <td className="py-1.5 text-sm">{p}</td>
                        <td className="py-1.5 text-right">
                          <button onClick={() => setProcedures(prev => prev.filter((_, j) => j !== i))} className="text-destructive"><Trash2 className="w-3.5 h-3.5" /></button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              )}
            </div>
          </SectionCard>

          {/* Evidence-Based Best Practice */}
          <EvidenceBasedPanel
            diagnoses={diagnoses}
            chiefComplaint={chiefComplaint}
            patient={selectedPatient}
            onApplyLabs={newLabs => setLabOrders(prev => [...prev, ...newLabs])}
            onApplyMeds={newMeds => setMedications(prev => [...prev, ...newMeds])}
          />

          {/* GIS Disease Map */}
          <SectionCard number="11" title="Disease Map (GIS)">
            <EncounterGISSection
              patient={selectedPatient || (header.patient_id ? { full_name: header.patient_name, district: '' } : null)}
              assessment={diagnoses.length > 0 ? diagnoses.map(d => d.description).join(', ') : ''}
            />
          </SectionCard>

          {/* Quick workflow links */}
          {encounterId && (
            <Card className="p-4 border-0 shadow-sm bg-primary/5">
              <p className="text-xs font-semibold text-primary mb-2">Continue Workflow</p>
              <div className="flex flex-wrap gap-2">
                {header.patient_id && (
                  <Button size="sm" className="text-xs h-7 gap-1 bg-accent hover:bg-accent/90" onClick={() => navigate(`/patients/${header.patient_id}?tab=encounters`)}>
                    <ArrowRight className="w-3 h-3 rotate-180" /> Patient Chart
                  </Button>
                )}
                <Button variant="outline" size="sm" className="text-xs h-7 gap-1" onClick={() => navigate(`/coding?encounterId=${encounterId}`)}>
                  <ArrowRight className="w-3 h-3" /> Medical Coding
                </Button>
                <Button variant="outline" size="sm" className="text-xs h-7 gap-1" onClick={() => navigate(`/pharmacy?encounterId=${encounterId}`)}>
                  <Pill className="w-3 h-3" /> Pharmacy
                </Button>
                <Button variant="outline" size="sm" className="text-xs h-7 gap-1" onClick={() => navigate(`/lab?encounterId=${encounterId}`)}>
                  <FlaskConical className="w-3 h-3" /> Lab
                </Button>
                <Button variant="outline" size="sm" className="text-xs h-7 gap-1" onClick={() => navigate(`/referrals?encounterId=${encounterId}`)}>
                  <GitBranch className="w-3 h-3" /> Referrals
                </Button>
              </div>
            </Card>
          )}
        </div>
      </div>

      {/* AI Listen Panel */}
      {showAIListen && (
        <AIListenPanel
          onPopulate={handleAIPopulate}
          patient={selectedPatient}
          onClose={() => setShowAIListen(false)}
        />
      )}
    </div>
  );
}