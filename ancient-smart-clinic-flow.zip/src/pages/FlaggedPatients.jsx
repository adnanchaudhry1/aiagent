import React from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { AlertTriangle, ArrowRight, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useHighRiskPatients } from '@/hooks/useHighRiskPatients';

export default function FlaggedPatients() {
  const navigate = useNavigate();

  const { data: patients = [], isLoading: loadingPatients } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });

  const { data: encounters = [], isLoading: loadingEncounters } = useQuery({
    queryKey: ['encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date', 100),
  });

  const riskPatients = useHighRiskPatients(encounters, patients);
  const criticalCount = riskPatients.filter(p => p.severity === 'critical').length;
  const isLoading = loadingPatients || loadingEncounters;

  return (
    <div className="space-y-5 max-w-4xl">
      {/* Header */}
      <div>
        <div className="flex items-center gap-3 mb-1">
          <div className="w-9 h-9 rounded-full bg-destructive/15 flex items-center justify-center">
            <AlertTriangle className="w-4 h-4 text-destructive" />
          </div>
          <div>
            <h1 className="text-2xl font-bold">High-Risk Patients</h1>
            <p className="text-sm text-muted-foreground">
              {riskPatients.length} flagged
              {criticalCount > 0 && <span className="text-destructive font-semibold"> · {criticalCount} critical</span>}
            </p>
          </div>
        </div>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-40">
          <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
        </div>
      ) : riskPatients.length === 0 ? (
        <Card className="p-10 border-0 shadow-sm text-center text-muted-foreground">
          No high-risk patients detected at this time.
        </Card>
      ) : (
        <div className="space-y-3">
          {riskPatients.map(p => {
            if (!p.patientId) return null;
            return (
              <Card
                key={p.patientId}
                className={`border-0 shadow-sm border-l-4 ${p.severity === 'critical' ? 'border-l-destructive' : 'border-l-orange-400'}`}
              >
                <div className="p-4 flex items-start gap-4">
                  {/* Avatar */}
                  <div className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 ${p.severity === 'critical' ? 'bg-destructive/15' : 'bg-orange-100'}`}>
                    <span className={`text-base font-bold ${p.severity === 'critical' ? 'text-destructive' : 'text-orange-600'}`}>
                      {p.patientName?.[0]?.toUpperCase() || <User className="w-4 h-4" />}
                    </span>
                  </div>

                  {/* Info */}
                  <div className="flex-1 min-w-0">
                    {/* Name — clickable */}
                    <button
                      className="text-left group"
                      onClick={() => navigate(`/patients/${p.patientId}`)}
                    >
                      <p className="text-base font-bold group-hover:text-primary group-hover:underline transition-colors">
                        {p.patientName}
                      </p>
                    </button>

                    <div className="flex items-center gap-2 flex-wrap mt-0.5 mb-2">
                      <Badge className={`text-xs ${p.severity === 'critical' ? 'bg-destructive/15 text-destructive' : 'bg-orange-100 text-orange-700'}`}>
                        {p.severity === 'critical' ? '🔴 Critical' : '🟠 High Risk'}
                      </Badge>
                      {p.district && <span className="text-xs text-muted-foreground">{p.district}</span>}
                      {p.insurance && <span className="text-xs text-muted-foreground">{p.insurance}</span>}
                    </div>

                    {/* Risk flags / reasons */}
                    <div className="flex flex-wrap gap-1.5">
                      {p.flags.map((f, i) => (
                        <Badge
                          key={i}
                          variant="outline"
                          className={`text-xs ${f.severity === 'critical' ? 'border-destructive/40 text-destructive bg-destructive/5' : 'border-orange-300 text-orange-700 bg-orange-50'}`}
                        >
                          {f.type === 'ICD-10' ? (
                            <span><span className="font-mono">{f.code}</span> · {f.description}</span>
                          ) : (
                            <span>{f.description}</span>
                          )}
                        </Badge>
                      ))}
                    </div>
                  </div>

                  {/* Open Chart button */}
                  <Button
                    size="sm"
                    className={`shrink-0 gap-1.5 text-white ${p.severity === 'critical' ? 'bg-destructive hover:bg-destructive/90' : 'bg-orange-500 hover:bg-orange-600'}`}
                    onClick={() => navigate(`/patients/${p.patientId}`)}
                  >
                    Open Chart <ArrowRight className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}