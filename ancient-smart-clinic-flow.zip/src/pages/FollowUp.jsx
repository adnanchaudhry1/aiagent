import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Phone, CheckCircle2, XCircle, Loader2, AlertTriangle, Calendar, Sparkles, PhoneCall } from 'lucide-react';
import FollowUpMiniTriage from '@/components/follow-up/FollowUpMiniTriage';
import PageHeader from '@/components/shared/PageHeader';
import { toast } from 'sonner';
import { format } from 'date-fns';
import { useNavigate } from 'react-router-dom';

const STATUS_COLORS = {
  Scheduled: 'bg-primary/10 text-primary',
  Completed: 'bg-accent/10 text-accent',
  Missed: 'bg-muted text-muted-foreground',
};

export default function FollowUp() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const urlParams = new URLSearchParams(window.location.search);
  const paramAppointmentId = urlParams.get('appointmentId') || '';
  const paramEncounterId = urlParams.get('encounterId') || '';

  const [selectedCall, setSelectedCall] = useState(null);
  const [response, setResponse] = useState('');
  const [aiNotes, setAiNotes] = useState('');
  const [saving, setSaving] = useState(false);
  const [aiLoading, setAiLoading] = useState(false);
  const [callingId, setCallingId] = useState(null);

  const triggerOutboundCall = async (f, e) => {
    e.stopPropagation();
    e.preventDefault();
    const phone = f.phone?.trim();
    if (!phone) { toast.error('No phone number on file for this patient.'); return; }
    setCallingId(f.id);
    try {
      const res = await base44.functions.invoke('vapiOutboundCall', {
        followUpCallId: f.id,
        phone: phone,
        patientName: f.patient_name,
      });
      if (res?.data?.success) {
        toast.success(`AI outbound call initiated for ${f.patient_name}`);
      } else {
        toast.error(res?.data?.error || 'Failed to initiate call');
      }
    } catch (err) {
      toast.error(err?.message || 'Failed to initiate outbound call');
    } finally {
      setCallingId(null);
    }
  };

  // Schedule new follow-up from appointment flow
  const [schedulingNew, setSchedulingNew] = useState(!!paramAppointmentId);
  const [followUpDays, setFollowUpDays] = useState(1);
  const [followUpOccurrences, setFollowUpOccurrences] = useState(1); // max 3
  const [savingNew, setSavingNew] = useState(false);

  const { data: appointmentData } = useQuery({
    queryKey: ['appointment-followup', paramAppointmentId],
    queryFn: () => base44.entities.Appointment.filter({ id: paramAppointmentId }).then(r => r[0]),
    enabled: !!paramAppointmentId,
  });

  const { data: followUps = [], isLoading } = useQuery({
    queryKey: ['followup_calls'],
    queryFn: () => base44.entities.FollowUpCall.list('-scheduled_date'),
  });

  const handleCallOutcome = async () => {
    if (!response) { toast.error('Select patient response'); return; }
    setSaving(true);
    try {
      const reEscalate = response === 'Not Recovered';
      await base44.entities.FollowUpCall.update(selectedCall.id, {
        status: 'Completed',
        call_date: new Date().toISOString(),
        patient_response: response,
        ai_notes: aiNotes,
        re_escalated: reEscalate,
      });

      if (reEscalate) {
        // Schedule a new follow-up appointment
        const nextDay = new Date();
        nextDay.setDate(nextDay.getDate() + 1);
        nextDay.setHours(9, 0, 0, 0);
        await base44.entities.Appointment.create({
          appointment_number: 'APT-' + Math.floor(10000000 + Math.random() * 90000000),
          patient_id: selectedCall.patient_id,
          patient_name: selectedCall.patient_name,
          appointment_date: nextDay.toISOString(),
          reason: `Follow-up re-appointment — patient still unwell. Previous encounter: ${selectedCall.encounter_id}`,
          status: 'Scheduled',
          intake_source: 'Manual',
          appointment_type: 'Hospital/Clinic',
          notes: `Phone: ${selectedCall.phone || 'N/A'} | Re-scheduled from follow-up call — patient not recovered`,
        });
        toast.warning('New follow-up appointment scheduled for tomorrow — patient still unwell.');
      } else if (response === 'Recovered') {
        // Count existing follow-ups for this encounter — max 3
        const existingForEnc = followUps.filter(f => f.encounter_id === selectedCall.encounter_id);
        if (existingForEnc.length < 3) {
          const nextWeek = new Date();
          nextWeek.setDate(nextWeek.getDate() + 7);
          await base44.entities.FollowUpCall.create({
            patient_id: selectedCall.patient_id,
            patient_name: selectedCall.patient_name,
            encounter_id: selectedCall.encounter_id,
            phone: selectedCall.phone,
            scheduled_date: nextWeek.toISOString(),
            status: 'Scheduled',
          });
          toast.success('Patient recovered! Follow-up call scheduled for next week.');
        } else {
          toast.info('Maximum 3 follow-up calls reached for this encounter.');
        }
      }

      queryClient.invalidateQueries({ queryKey: ['followup_calls'] });
      queryClient.invalidateQueries({ queryKey: ['community_visits'] });
      setSelectedCall(null);
    } catch {
      toast.error('Failed to save call outcome.');
    } finally {
      setSaving(false);
    }
  };

  const generateAINotes = async () => {
    if (!selectedCall) return;
    setAiLoading(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `AI follow-up call notes for Rwanda healthcare system:
Patient: ${selectedCall.patient_name}
Patient Response: ${response || 'Not yet captured'}
Scheduled follow-up: ${selectedCall.scheduled_date}

Generate brief AI call notes summarizing the follow-up interaction and next steps based on patient response.`,
        response_json_schema: {
          type: 'object',
          properties: { notes: { type: 'string' } }
        }
      });
      setAiNotes(res.notes);
    } catch {
      toast.error('Failed to generate AI notes');
    } finally {
      setAiLoading(false);
    }
  };

  const saveScheduledFollowUps = async () => {
    if (!appointmentData) return;
    const count = Math.min(followUpOccurrences, 3);
    setSavingNew(true);
    try {
      for (let i = 0; i < count; i++) {
        const date = new Date();
        date.setDate(date.getDate() + followUpDays * (i + 1));
        await base44.entities.FollowUpCall.create({
          patient_id: appointmentData.patient_id,
          patient_name: appointmentData.patient_name,
          encounter_id: paramEncounterId,
          phone: '',
          scheduled_date: date.toISOString(),
          status: 'Scheduled',
        });
      }
      queryClient.invalidateQueries({ queryKey: ['followup_calls'] });
      // Lock the appointment as Completed
      if (paramAppointmentId) {
        await base44.entities.Appointment.update(paramAppointmentId, { status: 'Completed', is_locked: true });
        queryClient.invalidateQueries({ queryKey: ['appointments'] });
      }
      toast.success(`${count} follow-up call(s) scheduled. Appointment completed.`);
      setSchedulingNew(false);
      setTimeout(() => navigate('/appointments'), 800);
    } catch {
      toast.error('Failed to schedule follow-ups');
    } finally {
      setSavingNew(false);
    }
  };

  const pending = followUps.filter(f => f.status === 'Scheduled');
  const completed = followUps.filter(f => f.status !== 'Scheduled');

  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader
        title="Post-Care Follow-Up Calls"
        subtitle="Phase 7 — AI schedules and manages follow-up calls with patients"
      />

      {/* Schedule follow-ups from appointment workflow */}
      {schedulingNew && appointmentData && (
        <Card className="p-6 border-0 shadow-sm border-l-4 border-l-accent bg-accent/5">
          <p className="text-xs font-bold text-accent uppercase tracking-wider mb-1">Schedule Follow-Up Calls</p>
          <p className="text-sm text-muted-foreground mb-4">Patient: <span className="font-semibold text-foreground">{appointmentData.patient_name}</span></p>
          <div className="grid grid-cols-2 gap-4 mb-4">
            <div>
              <Label className="text-xs">Follow-up interval</Label>
              <Select value={String(followUpDays)} onValueChange={v => setFollowUpDays(Number(v))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">Call after 1 day</SelectItem>
                  <SelectItem value="3">Call after 3 days</SelectItem>
                  <SelectItem value="7">Call after 1 week</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Number of occurrences (max 3)</Label>
              <Select value={String(followUpOccurrences)} onValueChange={v => setFollowUpOccurrences(Number(v))}>
                <SelectTrigger className="mt-1"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="1">1 call</SelectItem>
                  <SelectItem value="2">2 calls</SelectItem>
                  <SelectItem value="3">3 calls (maximum)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <p className="text-xs text-muted-foreground mb-4">
            {followUpOccurrences} call(s) will be scheduled, starting {followUpDays} day(s) from today.
          </p>
          <div className="flex gap-2">
            <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={saveScheduledFollowUps} disabled={savingNew}>
              {savingNew ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</> : <><CheckCircle2 className="w-4 h-4" /> Confirm & Complete Appointment</>}
            </Button>
            <Button variant="outline" onClick={async () => {
              if (paramAppointmentId) {
                await base44.entities.Appointment.update(paramAppointmentId, { status: 'Completed', is_locked: true });
                queryClient.invalidateQueries({ queryKey: ['appointments'] });
              }
              setSchedulingNew(false);
              navigate('/appointments');
            }}>Skip Follow-Up</Button>
          </div>
        </Card>
      )}

      <div className="grid grid-cols-3 gap-4">
        {[
          { label: 'Scheduled', value: pending.length, color: 'text-primary' },
          { label: 'Completed', value: completed.filter(f => f.status === 'Completed').length, color: 'text-accent' },
          { label: 'Re-Escalated', value: followUps.filter(f => f.re_escalated).length, color: 'text-destructive' },
        ].map(s => (
          <Card key={s.label} className="p-4 border-0 shadow-sm text-center">
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </Card>
        ))}
      </div>

      {pending.length > 0 && (
        <div>
          <p className="text-xs font-bold text-primary uppercase tracking-wider mb-3">Pending Follow-Up Calls ({pending.length})</p>
          <div className="space-y-3">
            {pending.map(f => (
              <Card key={f.id} className="p-4 border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer" onClick={() => { setSelectedCall(f); setResponse(''); setAiNotes(''); }}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-primary/10 flex items-center justify-center">
                      <Phone className="w-4 h-4 text-primary" />
                    </div>
                    <div>
                      <p className="text-sm font-semibold">{f.patient_name}</p>
                      {f.patient_id && <p className="text-xs text-muted-foreground font-mono">MRN: {f.patient_id.slice(-8).toUpperCase()}</p>}
                      <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                        <Calendar className="w-3 h-3" />
                        Scheduled: {format(new Date(f.scheduled_date), 'MMM d, yyyy')}
                      </p>
                      {f.phone && <p className="text-xs text-muted-foreground">{f.phone}</p>}
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={STATUS_COLORS[f.status]}>{f.status}</Badge>
                    <Button
                      size="sm"
                      className="gap-1 text-xs bg-primary hover:bg-primary/90"
                      disabled={callingId === f.id}
                      onClick={(e) => triggerOutboundCall(f, e)}
                    >
                      {callingId === f.id
                        ? <><Loader2 className="w-3 h-3 animate-spin" /> Calling...</>
                        : <><PhoneCall className="w-3 h-3" /> Call Now</>}
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {completed.length > 0 && (
        <div>
          <p className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">Completed Calls ({completed.length})</p>
          <div className="space-y-2">
            {completed.map(f => (
              <Card key={f.id} className="p-4 border-0 shadow-sm opacity-75">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium">{f.patient_name}</p>
                    <p className="text-xs text-muted-foreground">
                      Called: {f.call_date ? format(new Date(f.call_date), 'MMM d, yyyy') : 'N/A'} · Response: <span className="font-medium">{f.patient_response}</span>
                    </p>
                    {f.ai_notes && <p className="text-xs text-muted-foreground mt-0.5">{f.ai_notes?.slice(0, 100)}...</p>}
                  </div>
                  <div className="flex items-center gap-2">
                    {f.patient_response === 'Recovered' && <CheckCircle2 className="w-4 h-4 text-accent" />}
                    {f.patient_response === 'Not Recovered' && <XCircle className="w-4 h-4 text-destructive" />}
                    {f.re_escalated && <Badge className="bg-destructive/10 text-destructive text-xs flex items-center gap-1"><AlertTriangle className="w-3 h-3" />Re-Escalated</Badge>}
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>
      )}

      {!isLoading && followUps.length === 0 && (
        <div className="text-center py-16">
          <Phone className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">No follow-up calls scheduled yet.</p>
          <p className="text-xs text-muted-foreground mt-1">Follow-up calls are automatically scheduled after encounters are completed.</p>
        </div>
      )}

      {/* Call Outcome Dialog */}
      <Dialog open={!!selectedCall} onOpenChange={() => setSelectedCall(null)}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Phone className="w-5 h-5" /> Follow-Up Call: {selectedCall?.patient_name}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 mt-2">
            <div className="p-3 bg-muted/40 rounded-lg text-xs">
              <p><span className="text-muted-foreground">Scheduled:</span> {selectedCall?.scheduled_date && format(new Date(selectedCall.scheduled_date), 'MMM d, yyyy')}</p>
              <p><span className="text-muted-foreground">Phone:</span> {selectedCall?.phone || 'N/A'}</p>
            </div>

            <div>
              <Label className="text-xs">Patient Response *</Label>
              <Select value={response} onValueChange={setResponse}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="How is the patient feeling?" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Recovered">✅ Recovered — Feeling better</SelectItem>
                  <SelectItem value="Not Recovered">❌ Not Recovered — Still unwell</SelectItem>
                  <SelectItem value="No Answer">📵 No Answer</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {response && (
              <div className={`p-3 rounded-lg text-xs ${response === 'Recovered' ? 'bg-accent/10 border border-accent/20' : response === 'Not Recovered' ? 'bg-destructive/10 border border-destructive/20' : 'bg-muted/30'}`}>
                {response === 'Recovered' && <p className="text-accent font-semibold">✅ Will schedule another follow-up call in 1 week.</p>}
                {response === 'Not Recovered' && <p className="text-destructive font-semibold">🚨 Will automatically schedule a new follow-up appointment for tomorrow (patient still unwell).</p>}
                {response === 'No Answer' && <p className="text-muted-foreground">Call will be marked as missed. No action taken.</p>}
              </div>
            )}

            {/* Mini Triage */}
            <div className="border border-border rounded-lg p-3 bg-muted/20">
              <FollowUpMiniTriage
                call={selectedCall}
                onEscalate={(triageRes) => {
                  setResponse('Not Recovered');
                  setAiNotes(`Mini-triage escalation: ${triageRes.reason} (Risk score: ${triageRes.risk_score})`);
                }}
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1">
                <Label className="text-xs">AI Call Notes</Label>
                <Button variant="ghost" size="sm" className="h-6 text-xs gap-1 text-primary" onClick={generateAINotes} disabled={aiLoading || !response}>
                  {aiLoading ? <Loader2 className="w-3 h-3 animate-spin" /> : <Sparkles className="w-3 h-3" />} Generate
                </Button>
              </div>
              <Textarea rows={3} value={aiNotes} onChange={e => setAiNotes(e.target.value)} placeholder="AI-generated or manual call notes..." />
            </div>

            <Button className="w-full" onClick={handleCallOutcome} disabled={saving || !response}>
              {saving ? <><Loader2 className="w-4 h-4 animate-spin mr-2" /> Saving...</> : 'Save Call Outcome'}
            </Button>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}