import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import PageHeader from '@/components/shared/PageHeader';
import { format } from 'date-fns';
import { CheckCircle2, XCircle, Calendar, Search, CalendarPlus, PhoneOff } from 'lucide-react';
import PatientOutcomeModal from '@/components/follow-up/PatientOutcomeModal';

const RESPONSE_CONFIG = {
  Recovered: { color: 'bg-accent/10 text-accent border-accent/20', icon: CheckCircle2, iconColor: 'text-accent', label: 'Recovered' },
  'Not Recovered': { color: 'bg-destructive/10 text-destructive border-destructive/20', icon: XCircle, iconColor: 'text-destructive', label: 'Not Recovered' },
  'No Answer': { color: 'bg-muted text-muted-foreground border-border', icon: PhoneOff, iconColor: 'text-muted-foreground', label: 'No Answer' },
};

export default function FollowUpHistory() {
  const [search, setSearch] = useState('');
  const [filterResponse, setFilterResponse] = useState('all');
  const [selectedFollowUp, setSelectedFollowUp] = useState(null);
  const [selectedAppointment, setSelectedAppointment] = useState(null);

  const { data: followUps = [], isLoading } = useQuery({
    queryKey: ['followup_calls_history'],
    queryFn: () => base44.entities.FollowUpCall.list('-call_date', 200),
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments_history'],
    queryFn: () => base44.entities.Appointment.list('-appointment_date', 200),
  });

  const { data: patients = [] } = useQuery({
    queryKey: ['patients_history'],
    queryFn: () => base44.entities.Patient.list(),
  });

  // Only completed follow-ups
  const completed = followUps.filter(f => f.status === 'Completed');

  // Join with appointment data for first visit date
  const enriched = completed.map(f => {
    const appt = appointments.find(a => a.id === f.encounter_id);
    const patient = patients.find(p => p.id === f.patient_id);
    const mrn = patient?.national_id || (patient?.id ? `MRN-${patient.id.slice(0, 8).toUpperCase()}` : '');
    return { ...f, first_visit_date: appt?.appointment_date || appt?.created_date || null, visit_reason: appt?.reason || '', _appt: appt || null, mrn };
  });

  // Filter
  const filtered = enriched.filter(f => {
    const matchSearch = !search || f.patient_name?.toLowerCase().includes(search.toLowerCase());
    const matchResponse = filterResponse === 'all' || f.patient_response === filterResponse;
    return matchSearch && matchResponse;
  });

  // Summary stats
  const stats = {
    recovered: completed.filter(f => f.patient_response === 'Recovered').length,
    notRecovered: completed.filter(f => f.patient_response === 'Not Recovered').length,
    noAnswer: completed.filter(f => f.patient_response === 'No Answer').length,
    reEscalated: completed.filter(f => f.re_escalated).length,
  };

  return (
    <div className="space-y-6 max-w-5xl">
      <PageHeader
        title="Patient Follow-Up History"
        subtitle="Complete record of all follow-up calls — patient responses and outcomes"
      />

      {/* Summary Stats */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: 'Recovered', value: stats.recovered, color: 'text-accent', bg: 'bg-accent/10' },
          { label: 'Still Suffering', value: stats.notRecovered, color: 'text-destructive', bg: 'bg-destructive/10' },
          { label: 'No Answer', value: stats.noAnswer, color: 'text-muted-foreground', bg: 'bg-muted' },
          { label: 'Re-Escalated', value: stats.reEscalated, color: 'text-orange-600', bg: 'bg-orange-50' },
        ].map(s => (
          <Card key={s.label} className={`p-4 border-0 shadow-sm text-center ${s.bg}`}>
            <p className={`text-2xl font-bold ${s.color}`}>{s.value}</p>
            <p className="text-xs text-muted-foreground mt-1">{s.label}</p>
          </Card>
        ))}
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search patient name..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select value={filterResponse} onValueChange={setFilterResponse}>
          <SelectTrigger className="w-52">
            <SelectValue placeholder="Filter by response" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Responses</SelectItem>
            <SelectItem value="Recovered">✅ Recovered</SelectItem>
            <SelectItem value="Not Recovered">❌ Still Suffering</SelectItem>
            <SelectItem value="No Answer">📵 No Answer</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Outcome Modal */}
      <PatientOutcomeModal
        followUp={selectedFollowUp}
        appointment={selectedAppointment}
        onClose={() => { setSelectedFollowUp(null); setSelectedAppointment(null); }}
      />

      {/* Records Table */}
      {isLoading ? (
        <p className="text-center py-12 text-muted-foreground">Loading history...</p>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16">
          <Calendar className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
          <p className="text-muted-foreground text-sm">No completed follow-up calls found.</p>
        </div>
      ) : (
        <div className="space-y-3">
          {filtered.map(f => {
            const cfg = RESPONSE_CONFIG[f.patient_response] || RESPONSE_CONFIG['No Answer'];
            const Icon = cfg.icon;
            return (
              <Card
                key={f.id}
                className={`p-5 border shadow-sm cursor-pointer hover:shadow-md transition-shadow ${cfg.color}`}
                onClick={() => { setSelectedFollowUp(f); setSelectedAppointment(f._appt); }}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="flex items-start gap-3">
                    <div className={`mt-0.5 ${cfg.iconColor}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div>
                      <p className="font-semibold text-foreground text-sm">{f.patient_name}</p>
                      {f.mrn && <p className="text-xs text-muted-foreground font-mono">{f.mrn}</p>}
                      <div className="flex flex-wrap gap-x-4 gap-y-1 mt-1">
                        {f.first_visit_date && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            First Visit: {format(new Date(f.first_visit_date), 'MMM d, yyyy')}
                          </p>
                        )}
                        {f.call_date && (
                          <p className="text-xs text-muted-foreground flex items-center gap-1">
                            <CalendarPlus className="w-3 h-3" />
                            Follow-Up Call: {format(new Date(f.call_date), 'MMM d, yyyy')}
                          </p>
                        )}
                        {f.phone && (
                          <p className="text-xs text-muted-foreground">📞 {f.phone}</p>
                        )}
                      </div>
                      {f.visit_reason && (
                        <p className="text-xs text-muted-foreground mt-1">Reason: {f.visit_reason}</p>
                      )}
                      {f.ai_notes && (
                        <p className="text-xs text-foreground/70 mt-1 italic">"{f.ai_notes}"</p>
                      )}
                    </div>
                  </div>

                  <div className="flex flex-col items-end gap-1 flex-shrink-0">
                    <Badge className={`text-xs ${cfg.color}`}>{cfg.label}</Badge>
                    {f.re_escalated && (
                      <Badge className="text-xs bg-orange-50 text-orange-600 border-orange-200">
                        ⚠ Re-Escalated
                      </Badge>
                    )}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}