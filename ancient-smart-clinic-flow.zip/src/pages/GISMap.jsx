import React, { useState, useEffect, useMemo, useRef } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { MapContainer, TileLayer, CircleMarker, Popup, Tooltip } from 'react-leaflet';
import { useNavigate } from 'react-router-dom';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Map, Activity, AlertTriangle, TrendingUp, Sparkles, Loader2, Globe, BookOpen, Search, UserCheck, CheckCircle2, X, Hospital, ArrowRight, Users, Flame, ShieldCheck } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import StatCard from '@/components/shared/StatCard';
import { toast } from 'sonner';
import 'leaflet/dist/leaflet.css';

// Common diseases for autocomplete suggestions
const DISEASE_SUGGESTIONS = [
  'Malaria', 'Cholera', 'Typhoid', 'Tuberculosis (TB)', 'HIV/AIDS',
  'COVID-19', 'Meningitis', 'Dengue Fever', 'Pneumonia', 'Hepatitis B',
  'Hepatitis C', 'Ebola', 'Mpox (Monkeypox)', 'Measles', 'Polio',
  'Yellow Fever', 'Rabies', 'Tetanus', 'Diphtheria', 'Pertussis (Whooping Cough)',
  'Diabetes Mellitus', 'Hypertension', 'Heart Failure', 'Stroke',
  'Asthma', 'COPD', 'Kidney Failure (CKD)', 'Liver Failure', 'Cancer',
  'Anemia', 'Malnutrition', 'Eclampsia', 'Sepsis', 'Dysentery',
  'Schistosomiasis', 'Leishmaniasis', 'Trypanosomiasis', 'Brucellosis',
  'Leptospirosis', 'Rift Valley Fever', 'Marburg Virus', 'Acute Respiratory Failure',
  'Myocardial Infarction (Heart Attack)', 'Appendicitis', 'Preeclampsia',
];

// Rwanda districts with coordinates
const DISTRICTS = [
  { district: 'Gasabo', lat: -1.9403, lng: 30.0587 },
  { district: 'Kicukiro', lat: -1.9831, lng: 30.1083 },
  { district: 'Nyarugenge', lat: -1.9537, lng: 30.0442 },
  { district: 'Musanze', lat: -1.4993, lng: 29.6346 },
  { district: 'Huye', lat: -2.5962, lng: 29.7394 },
  { district: 'Rubavu', lat: -1.6832, lng: 29.2534 },
  { district: 'Kayonza', lat: -1.8608, lng: 30.6498 },
  { district: 'Bugesera', lat: -2.2136, lng: 30.2313 },
  { district: 'Ngoma', lat: -2.1615, lng: 30.4285 },
  { district: 'Nyagatare', lat: -1.2921, lng: 30.3084 },
  { district: 'Muhanga', lat: -2.0851, lng: 29.7530 },
  { district: 'Karongi', lat: -2.0677, lng: 29.3577 },
  { district: 'Rwamagana', lat: -1.9483, lng: 30.4350 },
  { district: 'Gatsibo', lat: -1.5834, lng: 30.4565 },
  { district: 'Rusizi', lat: -2.5017, lng: 28.9064 },
];

const diseaseIntelSchema = {
  type: 'object',
  properties: {
    disease_full_name: { type: 'string' },
    global_origin: { type: 'string' },
    origin_year_or_period: { type: 'string' },
    origin_country_or_region: { type: 'string' },
    how_disease_occurs: { type: 'string' },
    transmission_routes: { type: 'array', items: { type: 'string' } },
    first_outbreak_story: { type: 'string' },
    countries_controlled: {
      type: 'array',
      items: {
        type: 'object',
        properties: {
          country: { type: 'string' },
          method: { type: 'string' },
          result: { type: 'string' },
          year: { type: 'string' }
        }
      }
    },
    global_current_status: { type: 'string' },
    rwanda_context: { type: 'string' },
    rwanda_high_risk_districts: { type: 'array', items: { type: 'string' } },
    rwanda_district_cases: {
      type: 'array',
      description: 'Estimated or reported cases per Rwanda district for this disease',
      items: {
        type: 'object',
        properties: {
          district: { type: 'string' },
          estimated_cases: { type: 'number' },
          risk_level: { type: 'string', description: 'Low, Medium, High, Critical' }
        }
      }
    },
    untreated_1_week: { type: 'string' },
    untreated_1_month: { type: 'string' },
    untreated_3_months: { type: 'string' },
    economic_impact_rwf: { type: 'string' },
    prevention_tips: { type: 'array', items: { type: 'string' } },
    treatment_success_rate: { type: 'string' },
  }
};

function IntelligenceDisplay({ intelligence }) {
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4 border-0 shadow-sm bg-background">
          <div className="flex items-center gap-2 mb-3">
            <Globe className="w-4 h-4 text-primary" />
            <p className="text-sm font-semibold">Global Origin</p>
            {intelligence.origin_country_or_region && <Badge variant="secondary" className="text-xs">{intelligence.origin_country_or_region}</Badge>}
            {intelligence.origin_year_or_period && <Badge variant="outline" className="text-xs">{intelligence.origin_year_or_period}</Badge>}
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed mb-3">{intelligence.global_origin}</p>
          {intelligence.first_outbreak_story && (
            <div className="bg-muted/40 rounded-lg p-3">
              <p className="text-xs font-semibold mb-1">First Outbreak Story</p>
              <p className="text-xs text-muted-foreground">{intelligence.first_outbreak_story}</p>
            </div>
          )}
        </Card>

        <Card className="p-4 border-0 shadow-sm bg-background">
          <div className="flex items-center gap-2 mb-3">
            <BookOpen className="w-4 h-4 text-accent" />
            <p className="text-sm font-semibold">How It Occurs & Spreads</p>
          </div>
          <p className="text-xs text-muted-foreground leading-relaxed mb-3">{intelligence.how_disease_occurs}</p>
          <div className="flex flex-wrap gap-1.5">
            {intelligence.transmission_routes?.map((r, i) => (
              <Badge key={i} variant="outline" className="text-xs">{r}</Badge>
            ))}
          </div>
        </Card>

        <Card className="p-4 border-0 shadow-sm border-destructive/20 bg-destructive/5">
          <div className="flex items-center gap-2 mb-3">
            <AlertTriangle className="w-4 h-4 text-destructive" />
            <p className="text-sm font-semibold text-destructive">AI Prediction — If Patient Untreated</p>
          </div>
          <div className="space-y-2.5">
            <div className="bg-white/70 rounded-lg p-2.5">
              <p className="text-xs font-semibold text-orange-600">Within 1 Week:</p>
              <p className="text-xs">{intelligence.untreated_1_week}</p>
            </div>
            <div className="bg-white/70 rounded-lg p-2.5">
              <p className="text-xs font-semibold text-red-600">Within 1 Month:</p>
              <p className="text-xs">{intelligence.untreated_1_month}</p>
            </div>
            <div className="bg-white/70 rounded-lg p-2.5">
              <p className="text-xs font-semibold text-destructive">Within 3 Months:</p>
              <p className="text-xs">{intelligence.untreated_3_months}</p>
            </div>
          </div>
        </Card>

        <Card className="p-4 border-0 shadow-sm bg-background">
          <div className="flex items-center gap-2 mb-3">
            <TrendingUp className="w-4 h-4 text-accent" />
            <p className="text-sm font-semibold">How Countries Controlled It</p>
          </div>
          <div className="space-y-2">
            {intelligence.countries_controlled?.map((c, i) => (
              <div key={i} className="p-2.5 bg-muted/40 rounded-lg">
                <div className="flex items-center justify-between mb-0.5">
                  <p className="text-xs font-semibold">{c.country}</p>
                  {c.year && <Badge variant="outline" className="text-xs">{c.year}</Badge>}
                </div>
                <p className="text-xs text-muted-foreground">{c.method}</p>
                <p className="text-xs text-accent mt-0.5">{c.result}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card className="p-4 border-0 shadow-sm bg-background">
          <p className="text-sm font-semibold mb-2">Rwanda Context</p>
          <p className="text-xs text-muted-foreground leading-relaxed mb-3">{intelligence.rwanda_context}</p>
          {intelligence.treatment_success_rate && (
            <p className="text-xs font-semibold mb-1">Treatment Success Rate: <span className="text-accent">{intelligence.treatment_success_rate}</span></p>
          )}
          <p className="text-xs font-semibold mb-1">Global Status: <span className="text-primary">{intelligence.global_current_status}</span></p>
          {intelligence.economic_impact_rwf && (
            <p className="text-xs text-muted-foreground mt-2">Economic Impact: {intelligence.economic_impact_rwf}</p>
          )}
        </Card>
        <Card className="p-4 border-0 shadow-sm bg-background">
          <p className="text-sm font-semibold mb-2">Prevention Measures</p>
          <div className="space-y-1.5">
            {intelligence.prevention_tips?.map((tip, i) => (
              <div key={i} className="flex items-start gap-2 text-xs">
                <span className="text-accent mt-0.5">✓</span>
                <span className="text-muted-foreground">{tip}</span>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

export default function GISMap() {
  const urlParams = new URLSearchParams(window.location.search);
  const paramDisease = urlParams.get('disease') || '';
  const paramPatientId = urlParams.get('patientId') || '';
  const paramEncounterId = urlParams.get('encounterId') || '';
  const paramAppointmentId = urlParams.get('appointmentId') || '';
  const paramPatientName = urlParams.get('patientName') || '';

  const navigate = useNavigate();
  const [searchQuery, setSearchQuery] = useState(paramDisease);
  const [analyzing, setAnalyzing] = useState(false);
  const [intelligence, setIntelligence] = useState(null);
  const [savedToPatient, setSavedToPatient] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [outbreakZones, setOutbreakZones] = useState(null);
  const [loadingOutbreak, setLoadingOutbreak] = useState(false);
  const searchRef = useRef(null);
  const queryClient = useQueryClient();

  // Filter suggestions based on input
  const filteredSuggestions = useMemo(() => {
    if (!searchQuery.trim() || searchQuery.trim().length < 2) return DISEASE_SUGGESTIONS.slice(0, 8);
    const q = searchQuery.toLowerCase();
    return DISEASE_SUGGESTIONS.filter(d => d.toLowerCase().includes(q)).slice(0, 8);
  }, [searchQuery]);

  // Close suggestions when clicking outside
  useEffect(() => {
    const handleClick = (e) => {
      if (searchRef.current && !searchRef.current.contains(e.target)) {
        setShowSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClick);
    return () => document.removeEventListener('mousedown', handleClick);
  }, []);

  // Fetch all encounters to show real patient data on map
  const { data: encounters = [] } = useQuery({
    queryKey: ['encounters-gis'],
    queryFn: () => base44.entities.Encounter.list('-created_date', 200),
  });

  // Fetch patients for district info
  const { data: patients = [] } = useQuery({
    queryKey: ['patients-gis'],
    queryFn: () => base44.entities.Patient.list(),
  });

  // Fetch linked encounter if encounterId provided — to auto-populate disease from assessment
  const { data: linkedEncounter } = useQuery({
    queryKey: ['encounter-gis', paramEncounterId],
    queryFn: () => base44.entities.Encounter.filter({ id: paramEncounterId }).then(r => r[0]),
    enabled: !!paramEncounterId,
  });

  // Auto-populate search from encounter assessment
  useEffect(() => {
    if (linkedEncounter?.assessment && !searchQuery) {
      // Extract first disease/condition from assessment (first sentence or line)
      const firstLine = linkedEncounter.assessment.split(/[\n.]/)[0].trim();
      setSearchQuery(firstLine.slice(0, 80)); // cap at 80 chars
    }
  }, [linkedEncounter]);

  // Build real encounter-based district case counts for the searched disease
  const realDistrictData = useMemo(() => {
    if (!intelligence || !encounters.length) return {};
    const diseaseLower = (intelligence.disease_full_name || searchQuery).toLowerCase();
    const counts = {};
    encounters.forEach(enc => {
      const text = `${enc.assessment || ''} ${enc.chief_complaint || ''} ${enc.subjective || ''}`.toLowerCase();
      if (text.includes(diseaseLower.split(' ')[0])) {
        // Find patient district
        const patient = patients.find(p => p.id === enc.patient_id);
        const district = patient?.district || 'Kigali';
        const matched = DISTRICTS.find(d => d.district.toLowerCase().includes(district.toLowerCase()));
        if (matched) {
          counts[matched.district] = (counts[matched.district] || 0) + 1;
        }
      }
    });
    return counts;
  }, [intelligence, encounters, patients, searchQuery]);

  const analyzeDisease = async (overrideQuery) => {
    const query = overrideQuery || searchQuery;
    if (!query.trim()) return;
    setAnalyzing(true);
    setIntelligence(null);
    setSavedToPatient(false);
    setOutbreakZones(null);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a global disease intelligence AI for Rwanda's national health surveillance. Analyze "${query.trim()}" in depth.

Provide:
1. True global origin (country/region, year/period)
2. How it spreads (food, water, mosquito, contact, sexual, airborne, etc.)
3. Countries that controlled it — HOW, with measurable outcomes
4. Current global status
5. Origin story of first outbreak
6. Rwanda-specific risk context
7. Estimated cases per Rwanda district (use epidemiological estimates and any available Rwanda MOH data)
8. Risk level per district (Low/Medium/High/Critical)
9. AI prediction: what happens if untreated at 1 week, 1 month, 3 months
10. Economic impact in Rwanda context`,
        model: 'gemini_3_flash',
        add_context_from_internet: true,
        response_json_schema: diseaseIntelSchema,
      });
      setIntelligence(result);
    } catch (e) {
      toast.error('AI analysis failed. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  // Save disease to patient's encounter record
  const saveToPatientRecord = async () => {
    if (!paramEncounterId || !intelligence) return;
    try {
      // Append disease to the encounter assessment
      const currentAssessment = linkedEncounter?.assessment || '';
      const diseaseName = intelligence.disease_full_name || searchQuery;
      if (!currentAssessment.toLowerCase().includes(diseaseName.toLowerCase())) {
        await base44.entities.Encounter.update(paramEncounterId, {
          assessment: currentAssessment ? `${currentAssessment}\n[GIS Intelligence Added]: ${diseaseName}` : diseaseName,
          ai_suggestions_log: JSON.stringify({
            gis_disease_added: diseaseName,
            added_at: new Date().toISOString(),
            risk_districts: intelligence.rwanda_high_risk_districts,
          }),
        });
        queryClient.invalidateQueries({ queryKey: ['encounter-gis', paramEncounterId] });
        queryClient.invalidateQueries({ queryKey: ['encounters'] });
      }
      setSavedToPatient(true);
      toast.success(`${diseaseName} saved to patient encounter record`);
    } catch (e) {
      toast.error('Failed to save to patient record');
    }
  };

  // Outbreak zone analysis — hospitals per district
  const analyzeOutbreakZones = async () => {
    if (!intelligence) return;
    setLoadingOutbreak(true);
    try {
      const highRiskDistricts = intelligence.rwanda_high_risk_districts || mapData.filter(d => d.isHighRisk || d.riskLevel === 'High' || d.riskLevel === 'Critical').map(d => d.district);
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda healthcare facility intelligence system. For the disease "${intelligence.disease_full_name}", these are the high-risk/outbreak districts: ${highRiskDistricts.join(', ')}.

For EACH of these districts, list the real hospitals and health centers in Rwanda that are:
1. Located in or serving that district
2. Currently handling/treating ${intelligence.disease_full_name} patients

Also include ALL major Rwanda districts' hospitals so we can recommend referral options.

For each facility provide:
- Facility name (real Rwanda hospitals e.g. CHUK, King Faisal, Butaro, Kibagabaga, Musanze DH, Ruhango DH, etc.)
- Type: "Referral Hospital", "District Hospital", or "Health Center"
- District
- Estimated current patient load for this disease (Low: <10, Medium: 10-50, High: >50)
- Is it in an outbreak zone (true/false)
- Available capacity: "Available" (can take referrals) or "Overwhelmed"
- Specialties relevant to this disease

Return at least 15 facilities covering both outbreak and non-outbreak districts.`,
        response_json_schema: {
          type: 'object',
          properties: {
            outbreak_districts: { type: 'array', items: { type: 'string' } },
            facilities: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  name: { type: 'string' },
                  type: { type: 'string' },
                  district: { type: 'string' },
                  patient_load: { type: 'string', description: 'Low, Medium, High' },
                  in_outbreak_zone: { type: 'boolean' },
                  capacity_status: { type: 'string', description: 'Available or Overwhelmed' },
                  specialties: { type: 'array', items: { type: 'string' } },
                  contact: { type: 'string' },
                  recommended_for_referral: { type: 'boolean' },
                  referral_reason: { type: 'string' },
                }
              }
            },
            best_referral_facilities: { type: 'array', items: { type: 'string' }, description: 'Top 3 recommended facilities for patient referral' },
            referral_recommendation: { type: 'string' }
          }
        }
      });
      setOutbreakZones(result);
    } catch {
      toast.error('Failed to load outbreak zone data');
    } finally {
      setLoadingOutbreak(false);
    }
  };

  // Map rendering: merge AI district estimates + real encounter counts
  const mapData = useMemo(() => {
    return DISTRICTS.map(d => {
      const dLower = d.district.toLowerCase();
      const aiEntry = intelligence?.rwanda_district_cases?.find(c => {
        const cLower = (c.district || '').toLowerCase();
        return cLower.includes(dLower) || dLower.includes(cLower) || cLower === dLower;
      });
      const aiCases = aiEntry?.estimated_cases || 0;
      const realCases = realDistrictData[d.district] || 0;
      const isHighRisk = intelligence?.rwanda_high_risk_districts?.some(
        r => r.toLowerCase().includes(dLower) || dLower.includes(r.toLowerCase())
      );
      // Use aiCases directly for radius, fallback to 50 for high-risk districts with no case count
      const effectiveCases = aiCases > 0 ? aiCases : (isHighRisk ? 50 : 0);
      return {
        ...d,
        aiCases,
        realCases,
        totalCases: effectiveCases + realCases * 10,
        isHighRisk,
        riskLevel: aiEntry?.risk_level || (isHighRisk ? 'High' : 'Low'),
      };
    });
  }, [intelligence, realDistrictData]);

  const maxCases = Math.max(...mapData.map(d => d.totalCases), 1);
  const totalRealCases = Object.values(realDistrictData).reduce((a, b) => a + b, 0);
  const highRiskCount = mapData.filter(d => d.isHighRisk).length;
  const highestDistrict = mapData.reduce((m, d) => d.totalCases > m.totalCases ? d : m, mapData[0]);

  const riskColors = { Critical: '#c0392b', High: '#e74c3c', Medium: '#f39c12', Low: '#3498db' };

  // Map view toggle: 'disease' | 'transfer'
  const [mapView, setMapView] = useState('disease');

  // Compute transfer volume per district from real encounter/patient data
  const transferVolumeData = useMemo(() => {
    // Count how many patients from each district have encounters (proxy for transfer/referral volume)
    const districtCounts = {};
    const districtPatients = {};
    patients.forEach(p => {
      if (!p.district) return;
      const matched = DISTRICTS.find(d =>
        d.district.toLowerCase().includes(p.district.toLowerCase()) ||
        p.district.toLowerCase().includes(d.district.toLowerCase())
      );
      if (matched) {
        districtCounts[matched.district] = (districtCounts[matched.district] || 0) + 1;
        if (!districtPatients[matched.district]) districtPatients[matched.district] = [];
        districtPatients[matched.district].push(p.full_name);
      }
    });
    // Count encounters per district (additional transfer signal)
    encounters.forEach(enc => {
      const patient = patients.find(p => p.id === enc.patient_id);
      const district = patient?.district;
      if (!district) return;
      const matched = DISTRICTS.find(d =>
        d.district.toLowerCase().includes(district.toLowerCase()) ||
        district.toLowerCase().includes(d.district.toLowerCase())
      );
      if (matched) {
        districtCounts[matched.district] = (districtCounts[matched.district] || 0) + 0.5;
      }
    });
    return DISTRICTS.map(d => ({
      ...d,
      volume: Math.round(districtCounts[d.district] || 0),
      patients: districtPatients[d.district] || [],
    }));
  }, [patients, encounters]);

  const maxVolume = Math.max(...transferVolumeData.map(d => d.volume), 1);

  const getTransferColor = (volume, max) => {
    const ratio = volume / max;
    if (ratio > 0.7) return '#c0392b';
    if (ratio > 0.4) return '#e67e22';
    if (ratio > 0.15) return '#3498db';
    return '#95a5a6';
  };

  // Auto-analyze if disease passed via URL
  useEffect(() => {
    if (paramDisease && paramDisease.trim().length > 2) {
      analyzeDisease(paramDisease);
    }
  }, []);

  return (
    <div className="space-y-6 max-w-7xl">
      <PageHeader
        title="GIS Disease Intelligence"
        subtitle="Real-time disease surveillance, AI predictions & Rwanda district mapping"
      />

      {/* Patient context banner */}
      {(paramPatientId || paramEncounterId) && (
        <Card className="p-4 border-0 shadow-sm bg-primary/5 flex items-center gap-3">
          <UserCheck className="w-5 h-5 text-primary shrink-0" />
          <div className="flex-1">
            <p className="text-sm font-semibold text-primary">
              Patient Context — {paramPatientName || linkedEncounter?.patient_name || 'Patient'}
            </p>
            <p className="text-xs text-muted-foreground">
              {linkedEncounter?.assessment
                ? `Encounter assessment: "${linkedEncounter.assessment.slice(0, 100)}${linkedEncounter.assessment.length > 100 ? '...' : ''}"`
                : 'Linked to encounter — disease will be pre-filled from encounter data'}
            </p>
          </div>
          {intelligence && !savedToPatient && (
            <Button size="sm" className="gap-2 shrink-0" onClick={saveToPatientRecord}>
              <CheckCircle2 className="w-4 h-4" /> Save Disease to Patient Record
            </Button>
          )}
          {savedToPatient && (
            <Badge className="bg-accent/10 text-accent gap-1 shrink-0"><CheckCircle2 className="w-3 h-3" /> Saved to Record</Badge>
          )}
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <StatCard title="Real Patient Cases" value={totalRealCases || '—'} icon={Activity} color="primary" trend={intelligence ? `for ${intelligence.disease_full_name || searchQuery}` : 'Search a disease'} />
        <StatCard title="Highest Risk District" value={intelligence ? (highestDistrict?.district || '—') : '—'} icon={AlertTriangle} color="destructive" trend={intelligence ? highestDistrict?.riskLevel : 'Analyze to see'} />
        <StatCard title="High Risk Districts" value={highRiskCount || '—'} icon={Map} color="accent" />
        <StatCard title="Global Status" value={intelligence ? (intelligence.global_current_status?.split(' ').slice(0, 2).join(' ') || '—') : '—'} icon={TrendingUp} color="chart3" />
      </div>

      {/* Main Search Box */}
      <Card className="p-5 border-0 shadow-sm bg-gradient-to-r from-primary/5 to-accent/5">
        <div className="flex items-center gap-2 mb-3">
          <Search className="w-4 h-4 text-primary" />
          <p className="text-sm font-semibold">Search & Analyze Any Disease</p>
          <Badge variant="secondary" className="text-xs gap-1"><Sparkles className="w-3 h-3" /> AI + Real Data</Badge>
        </div>
        <div className="flex gap-3">
          {/* Search with autocomplete */}
          <div className="flex-1 relative" ref={searchRef}>
            <Input
              value={searchQuery}
              onChange={e => { setSearchQuery(e.target.value); setShowSuggestions(true); }}
              onFocus={() => setShowSuggestions(true)}
              onKeyDown={e => {
                if (e.key === 'Enter') { setShowSuggestions(false); analyzeDisease(); }
                if (e.key === 'Escape') setShowSuggestions(false);
              }}
              placeholder="Type any disease (e.g. Malaria, TB, Cholera, Diabetes...)"
              className="h-11 pr-8"
            />
            {searchQuery && (
              <button
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                onClick={() => { setSearchQuery(''); setIntelligence(null); setSavedToPatient(false); setShowSuggestions(false); }}
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}

            {/* Suggestions dropdown */}
            {showSuggestions && filteredSuggestions.length > 0 && (
              <div className="absolute top-full left-0 right-0 z-50 mt-1 bg-white border border-border rounded-lg shadow-lg overflow-hidden">
                <div className="px-3 py-1.5 text-xs text-muted-foreground bg-muted/50 border-b font-medium">
                  {searchQuery.length >= 2 ? 'Matching diseases' : 'Common diseases — start typing to filter'}
                </div>
                {filteredSuggestions.map((disease, i) => (
                  <button
                    key={i}
                    className="w-full text-left px-3 py-2 text-sm hover:bg-primary/5 hover:text-primary transition-colors flex items-center gap-2"
                    onMouseDown={(e) => {
                      e.preventDefault();
                      setSearchQuery(disease);
                      setShowSuggestions(false);
                      analyzeDisease(disease);
                    }}
                  >
                    <Search className="w-3.5 h-3.5 text-muted-foreground shrink-0" />
                    {disease}
                  </button>
                ))}
              </div>
            )}
          </div>

          <Button onClick={() => { setShowSuggestions(false); analyzeDisease(); }} disabled={analyzing || !searchQuery.trim()} className="gap-2 shrink-0 h-11">
            {analyzing ? <><Loader2 className="w-4 h-4 animate-spin" /> Analyzing...</> : <><Sparkles className="w-4 h-4" /> Analyze Disease</>}
          </Button>
        </div>
        <p className="text-xs text-muted-foreground mt-2">
          Click a suggestion or type freely — AI will analyze Rwanda district risk with real patient data.
          {paramEncounterId && ' Disease auto-populated from encounter assessment.'}
        </p>
      </Card>

      {/* Map — always visible, shows data when disease is analyzed */}
      <Card className="border-0 shadow-sm overflow-hidden rounded-xl">
        <div className="p-3 border-b flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <p className="text-sm font-semibold">
              {mapView === 'transfer' ? 'Transfer Volume by District' : (intelligence ? `Rwanda District Map — ${intelligence.disease_full_name}` : 'Rwanda Disease Map')}
            </p>
            {intelligence && mapView === 'disease' && (
              <Badge className="text-xs bg-primary/10 text-primary">Live AI + Real Data</Badge>
            )}
            {mapView === 'transfer' && (
              <Badge className="text-xs bg-orange-100 text-orange-700">Patient Transfer Volume</Badge>
            )}
          </div>
          <div className="flex items-center gap-3">
            {/* View toggle */}
            <div className="flex items-center gap-1 bg-muted rounded-lg p-0.5">
              <button
                className={`px-3 py-1 text-xs rounded-md transition-all font-medium ${mapView === 'disease' ? 'bg-white shadow text-primary' : 'text-muted-foreground hover:text-foreground'}`}
                onClick={() => setMapView('disease')}
              >Disease Risk</button>
              <button
                className={`px-3 py-1 text-xs rounded-md transition-all font-medium ${mapView === 'transfer' ? 'bg-white shadow text-orange-700' : 'text-muted-foreground hover:text-foreground'}`}
                onClick={() => setMapView('transfer')}
              >Transfer Volume</button>
            </div>
            {intelligence && mapView === 'disease' && (
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-red-500 inline-block" /> High Risk</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-orange-400 inline-block" /> Medium</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-blue-400 inline-block" /> Low</span>
              </div>
            )}
            {mapView === 'transfer' && (
              <div className="flex items-center gap-3 text-xs text-muted-foreground">
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-red-500 inline-block" /> High Volume</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-orange-400 inline-block" /> Medium</span>
                <span className="flex items-center gap-1"><span className="w-3 h-3 rounded-full bg-blue-400 inline-block" /> Low</span>
              </div>
            )}
          </div>
        </div>
        <div style={{ height: '500px' }}>
          <MapContainer center={[-1.9403, 29.8739]} zoom={8} style={{ height: '100%', width: '100%' }} scrollWheelZoom>
            <TileLayer
              url="https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}{r}.png"
              attribution='&copy; OpenStreetMap contributors &copy; CARTO'
            />
            {mapView === 'transfer' ? (
              transferVolumeData.map(d => {
                const radius = d.volume > 0 ? Math.max(9, (d.volume / maxVolume) * 45) : 7;
                const color = getTransferColor(d.volume, maxVolume);
                return (
                  <CircleMarker
                    key={d.district}
                    center={[d.lat, d.lng]}
                    radius={radius}
                    pathOptions={{ fillColor: color, fillOpacity: 0.65, color: color, weight: 2, opacity: 0.9 }}
                  >
                    <Tooltip direction="top" offset={[0, -10]}>
                      <div className="text-center">
                        <p className="font-bold text-sm">{d.district}</p>
                        <p className="text-xs">Transfer Volume: <strong>{d.volume}</strong></p>
                        <p className="text-xs text-gray-500">{d.patients.length} registered patients</p>
                      </div>
                    </Tooltip>
                    <Popup>
                      <div className="min-w-[180px]">
                        <p className="font-bold text-sm mb-1">{d.district} District</p>
                        <p className="text-xs text-gray-500 mb-2">Transfer / Patient Flow Zone</p>
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between"><span>Transfer Volume:</span><span className="font-bold">{d.volume}</span></div>
                          <div className="flex justify-between"><span>Registered Patients:</span><span className="font-bold">{d.patients.length}</span></div>
                        </div>
                        {d.patients.length > 0 && (
                          <div className="mt-2">
                            <p className="text-xs text-gray-500 mb-1">Patients:</p>
                            {d.patients.slice(0, 4).map((n, i) => <p key={i} className="text-xs">• {n}</p>)}
                            {d.patients.length > 4 && <p className="text-xs text-gray-400">+{d.patients.length - 4} more</p>}
                          </div>
                        )}
                      </div>
                    </Popup>
                  </CircleMarker>
                );
              })
            ) : intelligence ? (
              mapData.map(d => {
                const radius = d.totalCases > 0 ? Math.max(8, (d.totalCases / maxCases) * 40) : 7;
                const color = riskColors[d.riskLevel] || '#3498db';
                return (
                  <CircleMarker
                    key={d.district}
                    center={[d.lat, d.lng]}
                    radius={radius}
                    pathOptions={{
                      fillColor: color,
                      fillOpacity: d.isHighRisk ? 0.75 : 0.45,
                      color: color,
                      weight: d.isHighRisk ? 2 : 1,
                      opacity: 0.9,
                    }}
                  >
                    <Tooltip direction="top" offset={[0, -10]}>
                      <div className="text-center">
                        <p className="font-bold text-sm">{d.district}</p>
                        <p className="text-xs">Risk: {d.riskLevel}</p>
                        {d.aiCases > 0 && <p className="text-xs">Est. cases: {d.aiCases.toLocaleString()}</p>}
                        {d.realCases > 0 && <p className="text-xs text-green-700 font-bold">Real patient records: {d.realCases}</p>}
                        {d.isHighRisk && <p className="text-xs text-red-600 font-bold">⚠ AI High Risk</p>}
                      </div>
                    </Tooltip>
                    <Popup>
                      <div className="min-w-[200px]">
                        <p className="font-bold text-sm mb-1">{d.district} District</p>
                        <p className="text-xs text-gray-500 mb-2">{intelligence.disease_full_name}</p>
                        <div className="space-y-1 text-xs">
                          <div className="flex justify-between"><span>Risk Level:</span><span className="font-bold" style={{ color: riskColors[d.riskLevel] }}>{d.riskLevel}</span></div>
                          {d.aiCases > 0 && <div className="flex justify-between"><span>AI Estimated Cases:</span><span className="font-bold">{d.aiCases.toLocaleString()}</span></div>}
                          {d.realCases > 0 && <div className="flex justify-between"><span>Real Patient Records:</span><span className="font-bold text-green-700">{d.realCases}</span></div>}
                        </div>
                      </div>
                    </Popup>
                  </CircleMarker>
                );
              })
            ) : (
              // Default view — show all districts as neutral dots
              DISTRICTS.map(d => (
                <CircleMarker
                  key={d.district}
                  center={[d.lat, d.lng]}
                  radius={7}
                  pathOptions={{ fillColor: '#94a3b8', fillOpacity: 0.4, color: '#94a3b8', weight: 1 }}
                >
                  <Tooltip direction="top" offset={[0, -10]}>
                    <p className="text-xs font-bold">{d.district}</p>
                  </Tooltip>
                </CircleMarker>
              ))
            )}
          </MapContainer>
        </div>
      </Card>

      {/* Transfer Volume Breakdown Table */}
      {mapView === 'transfer' && (
        <Card className="p-5 border-0 shadow-sm">
          <h3 className="text-sm font-semibold mb-1 flex items-center gap-2">
            <Users className="w-4 h-4 text-orange-600" /> Transfer Volume by District Zone
          </h3>
          <p className="text-xs text-muted-foreground mb-4">Circle size = relative patient transfer/referral volume based on registered patients & encounters per district.</p>
          {transferVolumeData.every(d => d.volume === 0) ? (
            <div className="text-center py-8 text-muted-foreground">
              <p className="text-sm">No district data yet — add patients with districts assigned to see transfer volumes.</p>
            </div>
          ) : (
            <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
              {transferVolumeData.filter(d => d.volume > 0).sort((a, b) => b.volume - a.volume).map(d => {
                const ratio = d.volume / maxVolume;
                const colorClass = ratio > 0.7 ? 'bg-red-50 border-red-200' : ratio > 0.4 ? 'bg-orange-50 border-orange-200' : 'bg-blue-50 border-blue-200';
                const textClass = ratio > 0.7 ? 'text-red-600' : ratio > 0.4 ? 'text-orange-600' : 'text-blue-600';
                return (
                  <div key={d.district} className={`p-3 rounded-lg border ${colorClass}`}>
                    <p className="text-xs font-semibold">{d.district}</p>
                    <p className={`text-xl font-bold mt-1 ${textClass}`}>{d.volume}</p>
                    <p className="text-xs text-muted-foreground">transfers</p>
                    <p className="text-xs text-muted-foreground mt-0.5">{d.patients.length} patients</p>
                  </div>
                );
              })}
            </div>
          )}
        </Card>
      )}

      {/* District breakdown table — only when analyzed */}
      {mapView === 'disease' && intelligence && mapData.some(d => d.totalCases > 0) && (
        <Card className="p-5 border-0 shadow-sm">
          <h3 className="text-sm font-semibold mb-3">District Breakdown — {intelligence.disease_full_name}</h3>
          <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
            {mapData.filter(d => d.totalCases > 0).sort((a, b) => b.totalCases - a.totalCases).map(d => (
              <div key={d.district} className="p-3 rounded-lg bg-muted/50">
                <p className="text-xs font-medium">{d.district}</p>
                <Badge className={`text-xs mt-1 ${d.riskLevel === 'Critical' || d.riskLevel === 'High' ? 'bg-destructive/10 text-destructive' : d.riskLevel === 'Medium' ? 'bg-orange-50 text-orange-600' : 'bg-muted text-muted-foreground'}`}>
                  {d.riskLevel}
                </Badge>
                {d.aiCases > 0 && <p className="text-xs text-muted-foreground mt-1">~{d.aiCases.toLocaleString()} est.</p>}
                {d.realCases > 0 && <p className="text-xs text-green-700 font-semibold">{d.realCases} real</p>}
              </div>
            ))}
          </div>
        </Card>
      )}


      {/* Outbreak Zones & Hospital Capacity Panel */}
      {intelligence && (
        <Card className="p-5 border-0 shadow-sm border-l-4 border-l-destructive">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center gap-2">
              <Flame className="w-5 h-5 text-destructive" />
              <h3 className="text-sm font-semibold">Outbreak Zones & Hospital Capacity</h3>
              <Badge className="text-xs bg-destructive/10 text-destructive">For: {intelligence.disease_full_name}</Badge>
            </div>
            <Button
              size="sm"
              variant="outline"
              className="gap-2 border-destructive/30 text-destructive hover:bg-destructive/5"
              onClick={analyzeOutbreakZones}
              disabled={loadingOutbreak}
            >
              {loadingOutbreak ? <><Loader2 className="w-3.5 h-3.5 animate-spin" /> Loading...</> : <><Hospital className="w-3.5 h-3.5" /> Analyze Outbreak Zones</>}
            </Button>
          </div>

          {!outbreakZones && !loadingOutbreak && (
            <div className="text-center py-8 bg-muted/30 rounded-xl">
              <Hospital className="w-8 h-8 text-muted-foreground mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">Click "Analyze Outbreak Zones" to see which hospitals are treating patients in outbreak areas and where to refer.</p>
            </div>
          )}

          {loadingOutbreak && (
            <div className="flex flex-col items-center justify-center py-10 gap-3">
              <Loader2 className="w-8 h-8 animate-spin text-destructive" />
              <p className="text-sm text-muted-foreground">Analyzing outbreak zones and hospital capacity...</p>
            </div>
          )}

          {outbreakZones && (
            <div className="space-y-5">
              {/* Referral Recommendation Banner */}
              {outbreakZones.referral_recommendation && (
                <div className="p-4 bg-primary/5 rounded-xl border border-primary/20">
                  <div className="flex items-start gap-2">
                    <ArrowRight className="w-4 h-4 text-primary mt-0.5 shrink-0" />
                    <div>
                      <p className="text-xs font-semibold text-primary mb-1">AI Referral Recommendation</p>
                      <p className="text-sm text-foreground/80">{outbreakZones.referral_recommendation}</p>
                    </div>
                  </div>
                  {outbreakZones.best_referral_facilities?.length > 0 && (
                    <div className="mt-3 flex flex-wrap gap-2">
                      <p className="text-xs font-semibold text-muted-foreground w-full">Best facilities to refer to:</p>
                      {outbreakZones.best_referral_facilities.map((f, i) => (
                        <Badge key={i} className="bg-accent/10 text-accent text-xs">{f}</Badge>
                      ))}
                    </div>
                  )}
                </div>
              )}

              {/* Outbreak Zone Facilities */}
              <div>
                <p className="text-xs font-bold text-destructive uppercase tracking-wider mb-3 flex items-center gap-2">
                  <Flame className="w-3.5 h-3.5" /> Facilities in Outbreak Zones (High Patient Load)
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {outbreakZones.facilities?.filter(f => f.in_outbreak_zone).map((f, i) => (
                    <div key={i} className={`p-3 rounded-xl border ${f.capacity_status === 'Overwhelmed' ? 'border-destructive/30 bg-destructive/5' : 'border-orange-200 bg-orange-50/50'}`}>
                      <div className="flex items-start justify-between mb-1.5">
                        <div>
                          <p className="text-sm font-semibold">{f.name}</p>
                          <p className="text-xs text-muted-foreground">{f.district} · {f.type}</p>
                        </div>
                        <Badge className={`text-xs shrink-0 ${f.capacity_status === 'Overwhelmed' ? 'bg-destructive text-white' : 'bg-orange-100 text-orange-700'}`}>
                          {f.capacity_status}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-1.5 mt-2">
                        <Users className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">Patient Load:</span>
                        <span className={`text-xs font-semibold ${f.patient_load === 'High' ? 'text-destructive' : f.patient_load === 'Medium' ? 'text-orange-600' : 'text-accent'}`}>{f.patient_load}</span>
                      </div>
                      {f.specialties?.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                          {f.specialties.slice(0, 2).map((s, j) => <Badge key={j} variant="outline" className="text-xs py-0">{s}</Badge>)}
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>

              {/* Available for Referral */}
              <div>
                <p className="text-xs font-bold text-accent uppercase tracking-wider mb-3 flex items-center gap-2">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Available Facilities — Recommended for Referral (Low Patient Load)
                </p>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                  {outbreakZones.facilities?.filter(f => !f.in_outbreak_zone || f.capacity_status === 'Available').filter(f => f.recommended_for_referral || f.patient_load === 'Low').map((f, i) => (
                    <div key={i} className="p-3 rounded-xl border border-accent/20 bg-accent/5">
                      <div className="flex items-start justify-between mb-1.5">
                        <div>
                          <p className="text-sm font-semibold">{f.name}</p>
                          <p className="text-xs text-muted-foreground">{f.district} · {f.type}</p>
                        </div>
                        <Badge className="text-xs bg-accent/20 text-accent shrink-0">Available</Badge>
                      </div>
                      <div className="flex items-center gap-1.5 mt-1">
                        <Users className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="text-xs text-muted-foreground">Load:</span>
                        <span className="text-xs font-semibold text-accent">{f.patient_load}</span>
                      </div>
                      {f.referral_reason && <p className="text-xs text-muted-foreground mt-2 italic">{f.referral_reason}</p>}
                      {f.contact && <p className="text-xs text-primary mt-1">{f.contact}</p>}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </Card>
      )}

      {/* AI Intelligence Report */}
      {intelligence && (
        <Card className="p-5 border-0 shadow-sm ring-2 ring-primary/20">
          <div className="flex items-center justify-between mb-4">
            <h3 className="text-base font-bold flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-primary" />
              Full AI Intelligence Report — {intelligence.disease_full_name}
            </h3>
            {(paramPatientId || paramEncounterId) && !savedToPatient && (
              <Button size="sm" className="gap-2" onClick={saveToPatientRecord}>
                <CheckCircle2 className="w-4 h-4" /> Save to Patient Record
              </Button>
            )}
            {savedToPatient && (
              <Badge className="bg-accent/10 text-accent gap-1"><CheckCircle2 className="w-3 h-3" /> Saved to Encounter</Badge>
            )}
          </div>
          <IntelligenceDisplay intelligence={intelligence} />
        </Card>
      )}

      {!intelligence && !analyzing && (
        <Card className="p-10 border-0 shadow-sm text-center border-dashed border-2 border-muted">
          <Search className="w-10 h-10 text-muted-foreground mx-auto mb-3" />
          <p className="text-sm font-semibold text-muted-foreground">Search any disease to see it on the map</p>
          <p className="text-xs text-muted-foreground mt-1">
            AI will analyze Rwanda district risk, pull real patient encounter data, and generate a full intelligence report.
          </p>
        </Card>
      )}

      {/* Next Step Bar */}
      {(paramEncounterId || paramAppointmentId) && (
        <div className="flex gap-3 items-center p-4 bg-muted/30 rounded-xl border">
          <p className="text-sm text-muted-foreground flex-1">Done with GIS analysis?</p>
          <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => {
            const p = new URLSearchParams();
            if (paramEncounterId) p.set('encounterId', paramEncounterId);
            if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
            navigate(`/insurance?${p.toString()}`);
          }}>
            Next: Insurance Claims <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}