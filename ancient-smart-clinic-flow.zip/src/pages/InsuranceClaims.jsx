import React, { useState, useEffect } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { ShieldCheck, Sparkles, Loader2, AlertTriangle, CheckCircle2, XCircle, TrendingUp, ClipboardList, ArrowLeft, Eye, ArrowRight } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import PageHeader from '@/components/shared/PageHeader';
import StatCard from '@/components/shared/StatCard';
import { toast } from 'sonner';
import RCMAuditModal from '@/components/insurance/RCMAuditModal';

export default function InsuranceClaims() {
   const navigate = useNavigate();
   const urlParams = new URLSearchParams(window.location.search);
   const paramEncounterId = urlParams.get('encounterId') || '';
   const paramAppointmentId = urlParams.get('appointmentId') || '';
   const [showAudit, setShowAudit] = useState(false);
  const [selectedEncounter, setSelectedEncounter] = useState(null);
  const [predicting, setPredicting] = useState(false);
  const [prediction, setPrediction] = useState(null);
  const [viewClaim, setViewClaim] = useState(null);
  const [savedClaimId, setSavedClaimId] = useState(null);
  const [formData, setFormData] = useState({
    insurance_type: '', icd_codes: '', cpt_codes: '', modifiers: '',
    charged_amount: '', allowed_amount: '',
  });
  const queryClient = useQueryClient();

  const { data: encounters = [] } = useQuery({
    queryKey: ['encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date'),
  });

  // Auto-load encounter from URL param
  useEffect(() => {
    if (paramEncounterId && encounters.length > 0) {
      loadEncounter(paramEncounterId);
    }
  }, [paramEncounterId, encounters]);
  const { data: patients = [] } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });
  const { data: claims = [] } = useQuery({
    queryKey: ['claims'],
    queryFn: () => base44.entities.InsuranceClaim.list('-created_date'),
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['appointments-all'],
    queryFn: () => base44.entities.Appointment.list('-appointment_date'),
  });

  const loadEncounter = (encId) => {
    const enc = encounters.find(e => e.id === encId);
    if (enc) {
      setSelectedEncounter(enc);
      const patient = patients.find(p => p.id === enc.patient_id);
      setFormData({
        insurance_type: patient?.insurance_type || 'Mutuelle de Santé',
        icd_codes: enc.icd_codes || '',
        cpt_codes: enc.cpt_codes || '',
        modifiers: enc.modifiers || '',
        charged_amount: '',
        allowed_amount: '',
      });
    }
  };

  const predictApproval = async () => {
    setPredicting(true);
    try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are an insurance claim prediction AI for Rwanda's healthcare system. Analyze this claim and predict approval probability.

Insurance Type: ${formData.insurance_type}
ICD Codes: ${formData.icd_codes}
CPT Codes: ${formData.cpt_codes}
Modifiers: ${formData.modifiers}
Charged Amount: ${formData.charged_amount || 'Not specified'} RWF
Allowed Amount: ${formData.allowed_amount || 'Not specified'} RWF

Consider Rwanda-specific payers: RSSB (RAMA), MMI, Mutuelle de Santé.
Evaluate: code validity, medical necessity, documentation completeness, payer-specific rules.`,
      response_json_schema: {
        type: 'object',
        properties: {
          approval_probability: { type: 'number', description: 'Percentage 0-100' },
          risk_level: { type: 'string', description: 'Low, Medium, High' },
          risk_flags: { type: 'array', items: { type: 'string' } },
          optimization_suggestions: { type: 'array', items: { type: 'string' } },
          estimated_reimbursement: { type: 'string' },
          rejection_reasons: { type: 'array', items: { type: 'string' } },
        }
      }
    });
    setPrediction(result);
    } catch (e) {
      toast.error('AI prediction failed. Please try again.');
    } finally {
      setPredicting(false);
    }
  };

  const saveClaim = async () => {
    const claimNum = `CLM-${Date.now().toString().slice(-8)}`;
    const data = {
      claim_number: claimNum,
      patient_id: selectedEncounter?.patient_id || '',
      patient_name: selectedEncounter?.patient_name || '',
      encounter_id: selectedEncounter?.id || '',
      encounter_number: selectedEncounter?.encounter_number || '',
      insurance_type: formData.insurance_type,
      icd_codes: formData.icd_codes,
      cpt_codes: formData.cpt_codes,
      modifiers: formData.modifiers,
      charged_amount: parseFloat(formData.charged_amount) || 0,
      allowed_amount: parseFloat(formData.allowed_amount) || 0,
      approval_probability: prediction?.approval_probability || 0,
      risk_flags: JSON.stringify(prediction?.risk_flags || []),
      prediction_details: JSON.stringify(prediction),
      status: 'Draft',
    };
    const created = await base44.entities.InsuranceClaim.create(data);
    queryClient.invalidateQueries({ queryKey: ['claims'] });
    setSavedClaimId(created.id);
    toast.success('Claim saved successfully');
    return created;
  };

  const statusColors = {
    Draft: 'bg-muted text-muted-foreground',
    Submitted: 'bg-primary/10 text-primary',
    Approved: 'bg-accent/10 text-accent',
    Denied: 'bg-destructive/10 text-destructive',
    'Under Review': 'bg-orange-50 text-orange-600',
  };

  return (
     <div className="space-y-6 max-w-6xl">
       <div className="flex items-center gap-2 mb-4">
         <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
           <ArrowLeft className="w-4 h-4" />
         </Button>
       </div>
       <PageHeader
         title="Insurance Claims & Billing"
         subtitle="Rwanda RSSB, MMI & Mutuelle de Santé — ICD-10 Coding & Fraud Prevention"
         action={
           <Button variant="outline" className="gap-2" onClick={() => setShowAudit(true)}>
             <ClipboardList className="w-4 h-4" /> Run Audit of Practice
           </Button>
         }
       />
      <RCMAuditModal open={showAudit} onClose={() => setShowAudit(false)} claims={claims} />

      {/* View Claim Dialog */}
      <Dialog open={!!viewClaim} onOpenChange={() => setViewClaim(null)}>
        <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldCheck className="w-5 h-5 text-primary" /> Claim Details — {viewClaim?.claim_number}
            </DialogTitle>
          </DialogHeader>
          {viewClaim && (() => {
            const linkedEncounter = encounters.find(e => e.id === viewClaim.encounter_id);
            const linkedAppointment = appointments.find(a => a.encounter_id === viewClaim.encounter_id || a.patient_id === viewClaim.patient_id);
            const linkedPatient = patients.find(p => p.id === viewClaim.patient_id);

            // Parse ICD codes nicely
            let icdList = [];
            try { icdList = JSON.parse(viewClaim.icd_codes || '[]'); } catch { icdList = viewClaim.icd_codes ? [{ code: viewClaim.icd_codes }] : []; }
            let cptList = [];
            try { cptList = JSON.parse(viewClaim.cpt_codes || '[]'); } catch { cptList = viewClaim.cpt_codes ? [{ code: viewClaim.cpt_codes }] : []; }
            let riskFlagsList = [];
            try { riskFlagsList = JSON.parse(viewClaim.risk_flags || '[]'); } catch { riskFlagsList = viewClaim.risk_flags ? [viewClaim.risk_flags] : []; }

            return (
              <div className="space-y-4 mt-2">
                {/* Core Claim Info */}
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div className="p-3 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Patient</p>
                    <p className="font-semibold">{viewClaim.patient_name}</p>
                    {linkedPatient?.national_id && <p className="text-xs text-muted-foreground mt-0.5">ID: {linkedPatient.national_id}</p>}
                    {linkedPatient?.phone && <p className="text-xs text-muted-foreground">Phone: {linkedPatient.phone}</p>}
                  </div>
                  <div className="p-3 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Insurance</p>
                    <p className="font-semibold">{viewClaim.insurance_type}</p>
                    {linkedPatient?.insurance_id && <p className="text-xs text-muted-foreground mt-0.5">Member ID: {linkedPatient.insurance_id}</p>}
                  </div>
                  <div className="p-3 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Charged Amount</p>
                    <p className="font-semibold text-primary">{viewClaim.charged_amount ? `${Number(viewClaim.charged_amount).toLocaleString()} RWF` : '—'}</p>
                  </div>
                  <div className="p-3 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Allowed Amount</p>
                    <p className="font-semibold text-accent">{viewClaim.allowed_amount ? `${Number(viewClaim.allowed_amount).toLocaleString()} RWF` : '—'}</p>
                  </div>
                  <div className="p-3 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Approval Probability</p>
                    <div className="flex items-center gap-2 mt-1">
                      <Progress value={viewClaim.approval_probability || 0} className="h-1.5 flex-1" />
                      <span className="font-semibold text-sm">{viewClaim.approval_probability || 0}%</span>
                    </div>
                  </div>
                  <div className="p-3 bg-muted/40 rounded-lg">
                    <p className="text-xs text-muted-foreground">Status</p>
                    <Badge className={`mt-1 ${statusColors[viewClaim.status] || ''}`}>{viewClaim.status}</Badge>
                    {viewClaim.encounter_number && <p className="text-xs text-muted-foreground mt-1">Encounter: {viewClaim.encounter_number}</p>}
                  </div>
                </div>

                {/* ICD Codes */}
                <div className="p-3 bg-muted/40 rounded-lg">
                  <p className="text-xs font-semibold text-muted-foreground mb-2">ICD-10 Codes</p>
                  {icdList.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {icdList.map((item, i) => (
                        <div key={i} className="px-2 py-1 bg-primary/10 text-primary rounded text-xs font-mono">
                          {item.code || item} {item.description && <span className="font-sans text-foreground/70">— {item.description}</span>}
                        </div>
                      ))}
                    </div>
                  ) : <p className="text-xs text-muted-foreground">No ICD codes</p>}
                </div>

                {/* CPT Codes */}
                <div className="p-3 bg-muted/40 rounded-lg">
                  <p className="text-xs font-semibold text-muted-foreground mb-2">CPT Codes</p>
                  {cptList.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {cptList.map((item, i) => (
                        <div key={i} className="px-2 py-1 bg-accent/10 text-accent rounded text-xs font-mono">
                          {item.code || item} {item.description && <span className="font-sans text-foreground/70">— {item.description}</span>}
                        </div>
                      ))}
                    </div>
                  ) : <p className="text-xs text-muted-foreground">No CPT codes</p>}
                </div>

                {/* Encounter Notes */}
                {linkedEncounter && (
                  <div className="space-y-2">
                    <p className="text-xs font-bold text-primary uppercase tracking-wider">Encounter Notes</p>
                    {linkedEncounter.chief_complaint && (
                      <div className="p-3 bg-muted/40 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Chief Complaint</p>
                        <p className="text-sm">{linkedEncounter.chief_complaint}</p>
                      </div>
                    )}
                    {linkedEncounter.subjective && (
                      <div className="p-3 bg-muted/40 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Subjective (History)</p>
                        <p className="text-sm whitespace-pre-wrap">{linkedEncounter.subjective}</p>
                      </div>
                    )}
                    {linkedEncounter.objective && (
                      <div className="p-3 bg-muted/40 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Objective (Examination)</p>
                        <p className="text-sm whitespace-pre-wrap">{linkedEncounter.objective}</p>
                      </div>
                    )}
                    {linkedEncounter.assessment && (
                      <div className="p-3 bg-muted/40 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Assessment / Diagnosis</p>
                        <p className="text-sm whitespace-pre-wrap">{linkedEncounter.assessment}</p>
                      </div>
                    )}
                    {linkedEncounter.plan && (
                      <div className="p-3 bg-muted/40 rounded-lg">
                        <p className="text-xs text-muted-foreground mb-1">Plan of Care</p>
                        <p className="text-sm whitespace-pre-wrap">{linkedEncounter.plan}</p>
                      </div>
                    )}
                  </div>
                )}

                {/* Patient Call Notes (from linked appointment) */}
                {linkedAppointment?.ai_call_notes && (
                  <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                    <p className="text-xs font-semibold text-blue-700 mb-2">📞 Patient Call Notes (AI Phone Intake — Locked)</p>
                    <p className="text-sm text-foreground/80 whitespace-pre-wrap">{linkedAppointment.ai_call_notes}</p>
                  </div>
                )}

                {/* Risk Flags */}
                {riskFlagsList.length > 0 && (
                  <div className="p-3 bg-destructive/5 rounded-lg border border-destructive/20">
                    <p className="text-xs font-semibold text-destructive mb-2">Risk Flags</p>
                    <div className="flex flex-wrap gap-2">
                      {riskFlagsList.map((f, i) => (
                        <Badge key={i} variant="destructive" className="text-xs">{f}</Badge>
                      ))}
                    </div>
                  </div>
                )}

                {/* Estimated Reimbursement */}
                {viewClaim.prediction?.estimated_reimbursement && (
                  <div className="p-3 bg-accent/5 rounded-lg border border-accent/20">
                    <p className="text-xs font-semibold text-accent mb-1">Estimated Reimbursement</p>
                    <p className="text-sm font-bold">{viewClaim.prediction.estimated_reimbursement}</p>
                  </div>
                )}
              </div>
            );
          })()}
        </DialogContent>
      </Dialog>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <StatCard title="Total Claims" value={claims.length} icon={ShieldCheck} color="primary" />
        <StatCard title="Avg Approval Rate" value="87%" icon={TrendingUp} color="accent" />
        <StatCard title="Pending Review" value={claims.filter(c => c.status === 'Submitted' || c.status === 'Under Review').length} icon={AlertTriangle} color="chart3" />
      </div>

      {selectedEncounter && (
        <Card className="p-4 border-0 shadow-sm bg-primary/5">
          <p className="text-xs font-semibold text-primary">Linked Encounter — {selectedEncounter.patient_name}</p>
          <p className="text-xs text-muted-foreground mt-0.5">#{selectedEncounter.encounter_number || selectedEncounter.id?.slice(-8)} · {selectedEncounter.status}</p>
        </Card>
      )}

      <Card className="p-5 border-0 shadow-sm">
        <h3 className="text-sm font-semibold mb-3">Claim Details</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <Label className="text-xs">Insurance Type</Label>
            <Select value={formData.insurance_type} onValueChange={v => setFormData(prev => ({ ...prev, insurance_type: v }))}>
              <SelectTrigger className="mt-1"><SelectValue placeholder="Select insurer" /></SelectTrigger>
              <SelectContent>
                {['RSSB (RAMA)', 'MMI', 'Mutuelle de Santé', 'Private'].map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
              </SelectContent>
            </Select>
          </div>
          <div>
            <Label className="text-xs">ICD Codes</Label>
            <Input className="mt-1" value={formData.icd_codes} onChange={e => setFormData(prev => ({ ...prev, icd_codes: e.target.value }))} placeholder="e.g. 8A00, BA01" />
          </div>
          <div>
            <Label className="text-xs">CPT Codes</Label>
            <Input className="mt-1" value={formData.cpt_codes} onChange={e => setFormData(prev => ({ ...prev, cpt_codes: e.target.value }))} placeholder="e.g. 99213, 99214" />
          </div>
          <div>
            <Label className="text-xs">Charged Amount (RWF)</Label>
            <Input className="mt-1" type="number" value={formData.charged_amount} onChange={e => setFormData(prev => ({ ...prev, charged_amount: e.target.value }))} />
          </div>
          <div>
            <Label className="text-xs">Allowed Amount (RWF)</Label>
            <Input className="mt-1" type="number" value={formData.allowed_amount} onChange={e => setFormData(prev => ({ ...prev, allowed_amount: e.target.value }))} />
          </div>
        </div>
        <Button className="mt-4 gap-2" onClick={predictApproval} disabled={predicting || !formData.insurance_type}>
          {predicting ? <><Loader2 className="w-4 h-4 animate-spin" /> Predicting...</> : <><Sparkles className="w-4 h-4" /> Predict Approval</>}
        </Button>
      </Card>

      {prediction && (
        <Card className="p-5 border-0 shadow-sm">
          <h3 className="text-sm font-semibold mb-4">Prediction Results</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <div className="text-center p-4 rounded-xl bg-muted/50">
              <p className="text-3xl font-bold text-primary">{prediction.approval_probability}%</p>
              <p className="text-xs text-muted-foreground mt-1">Approval Probability</p>
              <Progress value={prediction.approval_probability} className="mt-2 h-2" />
            </div>
            <div className="text-center p-4 rounded-xl bg-muted/50">
              <Badge className={`text-sm ${prediction.risk_level === 'Low' ? 'bg-accent/10 text-accent' : prediction.risk_level === 'High' ? 'bg-destructive/10 text-destructive' : 'bg-orange-50 text-orange-600'}`}>
                {prediction.risk_level} Risk
              </Badge>
              <p className="text-xs text-muted-foreground mt-2">Risk Level</p>
            </div>
            <div className="text-center p-4 rounded-xl bg-muted/50">
              <p className="text-lg font-bold">{prediction.estimated_reimbursement || 'N/A'}</p>
              <p className="text-xs text-muted-foreground mt-1">Est. Reimbursement</p>
            </div>
          </div>

          {prediction.risk_flags?.length > 0 && (
            <div className="mb-3">
              <p className="text-xs font-semibold text-destructive mb-1">Risk Flags:</p>
              <div className="flex flex-wrap gap-2">
                {prediction.risk_flags.map((f, i) => (
                  <Badge key={i} variant="destructive" className="text-xs">{f}</Badge>
                ))}
              </div>
            </div>
          )}

          {prediction.optimization_suggestions?.length > 0 && (
            <div className="mb-4">
              <p className="text-xs font-semibold text-accent mb-1">Optimization Suggestions:</p>
              <ul className="space-y-1">
                {prediction.optimization_suggestions.map((s, i) => (
                  <li key={i} className="text-xs text-muted-foreground flex items-start gap-1.5">
                    <CheckCircle2 className="w-3 h-3 text-accent mt-0.5 flex-shrink-0" /> {s}
                  </li>
                ))}
              </ul>
            </div>
          )}

          <div className="flex gap-2 flex-wrap">
            <Button variant="outline" className="gap-2" onClick={async () => {
              const created = await saveClaim();
              if (created) setViewClaim({ ...created, prediction });
            }}>
              <ShieldCheck className="w-4 h-4" /> Save Claim
            </Button>
            <Button variant="outline" className="gap-2" onClick={() => {
              if (savedClaimId) {
                const c = claims.find(c => c.id === savedClaimId);
                if (c) { setViewClaim(c); return; }
              }
              // Show a preview from current form + prediction data
              setViewClaim({
                claim_number: '(unsaved)',
                patient_name: selectedEncounter?.patient_name || '—',
                insurance_type: formData.insurance_type,
                icd_codes: formData.icd_codes,
                cpt_codes: formData.cpt_codes,
                charged_amount: formData.charged_amount,
                allowed_amount: formData.allowed_amount,
                approval_probability: prediction?.approval_probability || 0,
                risk_flags: JSON.stringify(prediction?.risk_flags || []),
                status: 'Draft',
                prediction,
              });
            }}>
              <Eye className="w-4 h-4" /> View Claim
            </Button>
            <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={async () => {
              const created = await saveClaim();
              if (paramAppointmentId) {
                await base44.entities.Appointment.update(paramAppointmentId, { status: 'Completed', is_locked: true });
                queryClient.invalidateQueries({ queryKey: ['appointments'] });
              }
              toast.success('Claim submitted! Proceeding to Follow-Up...');
              const p = new URLSearchParams();
              if (paramEncounterId) p.set('encounterId', paramEncounterId);
              if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
              setTimeout(() => navigate(`/follow-up?${p.toString()}`), 600);
            }}>
              Submit & Next: Follow-Up <ArrowRight className="w-4 h-4" />
            </Button>
          </div>
        </Card>
      )}

      {claims.length > 0 && (
        <Card className="border-0 shadow-sm">
          <div className="p-5 border-b">
            <h3 className="text-sm font-semibold">Recent Claims</h3>
          </div>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Patient</TableHead>
                <TableHead>Insurance</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Approval %</TableHead>
                <TableHead>Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {claims.map(c => (
                <TableRow key={c.id}>
                  <TableCell className="text-sm font-medium">{c.patient_name}</TableCell>
                  <TableCell className="text-sm">{c.insurance_type}</TableCell>
                  <TableCell className="text-sm">{c.charged_amount ? `${Number(c.charged_amount).toLocaleString()} RWF` : '—'}</TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Progress value={c.approval_probability || 0} className="w-16 h-1.5" />
                      <span className="text-xs">{c.approval_probability || 0}%</span>
                    </div>
                  </TableCell>
                  <TableCell>
                    <div className="flex items-center gap-2">
                      <Badge className={`text-xs ${statusColors[c.status] || ''}`}>{c.status}</Badge>
                      {c.status === 'Draft' && (
                        <Button size="sm" variant="outline" className="text-xs h-6 px-2"
                          onClick={async () => {
                            await base44.entities.InsuranceClaim.update(c.id, { status: 'Submitted' });
                            queryClient.invalidateQueries({ queryKey: ['claims'] });
                            toast.success('Claim submitted');
                          }}>
                          Submit
                        </Button>
                      )}
                      <Button size="sm" variant="ghost" className="text-xs h-6 px-2 gap-1" onClick={() => setViewClaim(c)}>
                        <Eye className="w-3 h-3" /> View
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </Card>
      )}
    </div>
  );
}