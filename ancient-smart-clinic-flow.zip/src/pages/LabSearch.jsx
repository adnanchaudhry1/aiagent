import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { FlaskConical, Search, MapPin, Phone, Clock, Loader2, CheckCircle2, XCircle, ArrowRight, RefreshCw, CalendarCheck, Info, ArrowLeft } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import { useNavigate } from 'react-router-dom';
import { toast } from 'sonner';

const RWANDA_LABS = [
  { name: 'King Faisal Hospital Lab', district: 'Gasabo', address: 'KG 544 St, Kigali', phone: '+250 788 585 555', hours: '24 Hours', type: 'Tertiary' },
  { name: 'CHUK Laboratory', district: 'Nyarugenge', address: 'KN 4 Ave, Kigali', phone: '+250 788 303 800', hours: '24 Hours', type: 'Tertiary' },
  { name: 'CHUB Laboratory', district: 'Huye', address: 'SH 1, Butare', phone: '+250 788 200 405', hours: '7:00 AM - 8:00 PM', type: 'Regional' },
  { name: 'Ruhengeri Hospital Lab', district: 'Musanze', address: 'NR 4, Musanze', phone: '+250 788 540 300', hours: '7:00 AM - 8:00 PM', type: 'Regional' },
  { name: 'Kibagabaga Hospital Lab', district: 'Gasabo', address: 'KG 9 Ave, Kimironko', phone: '+250 788 464 120', hours: '7:30 AM - 6:00 PM', type: 'District' },
  { name: 'Rwanda Biomedical Centre', district: 'Kicukiro', address: 'KK 15 Ave, Gikondo', phone: '+250 788 300 600', hours: '8:00 AM - 5:00 PM', type: 'Reference' },
  { name: 'Nyamata District Lab', district: 'Bugesera', address: 'Nyamata, Bugesera', phone: '+250 788 100 220', hours: '7:00 AM - 6:00 PM', type: 'District' },
  { name: 'Muhima Hospital Lab', district: 'Nyarugenge', address: 'KN 67 St, Muhima', phone: '+250 788 570 130', hours: '8:00 AM - 5:00 PM', type: 'District' },
];

const LAB_TYPE_COLORS = {
  Tertiary: 'bg-primary/10 text-primary',
  Regional: 'bg-accent/10 text-accent',
  District: 'bg-orange-50 text-orange-600',
  Reference: 'bg-purple-50 text-purple-600',
};

export default function LabSearch() {
  const urlParams = new URLSearchParams(window.location.search);
  const preloadTest = urlParams.get('test') || '';
  const encounterId = urlParams.get('encounterId') || '';
  const paramAppointmentId = urlParams.get('appointmentId') || '';

  const [query, setQuery] = useState(preloadTest);
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState({});
  const [searched, setSearched] = useState(false);
  const [selectedLab, setSelectedLab] = useState(null);
  const [refillModal, setRefillModal] = useState(false);
  const [refillData, setRefillData] = useState({ date: '', frequency: '', notes: '' });
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: encounter } = useQuery({
    queryKey: ['encounter', encounterId],
    queryFn: () => base44.entities.Encounter.filter({ id: encounterId }).then(r => r[0]),
    enabled: !!encounterId,
  });

  const orderedLabs = useMemo(() => {
    if (!encounter?.lab_orders) return [];
    try { return JSON.parse(encounter.lab_orders); } catch { return []; }
  }, [encounter]);

  // When encounter loads, auto-populate with first lab order if no preloadTest
  useEffect(() => {
    if (encounter && orderedLabs.length > 0 && !query && !preloadTest) {
      const firstLab = orderedLabs[0];
      setQuery(firstLab.test || firstLab.test_name || '');
    }
  }, [encounter, orderedLabs]);

  const searchTest = async (searchQuery) => {
    const q = searchQuery || query;
    if (q.length < 3) return;
    setSearching(true);
    setSearched(true);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a laboratory search system for Rwanda. Search for this lab test: "${q}"

For each of these laboratories, determine if they offer this test:
${RWANDA_LABS.map(l => l.name).join(', ')}

Provide: availability, turnaround time, price in RWF, sample type, equipment quality score (1-10), and whether they accept Mutuelle/RSSB insurance.`,
        response_json_schema: {
          type: 'object',
          properties: {
            test_name: { type: 'string' },
            category: { type: 'string' },
            clinical_indication: { type: 'string' },
            normal_range: { type: 'string' },
            results: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  lab_name: { type: 'string' },
                  available: { type: 'boolean' },
                  turnaround_time: { type: 'string' },
                  price_rwf: { type: 'string' },
                  sample_type: { type: 'string' },
                  equipment_score: { type: 'number' },
                  accepts_mutuelle: { type: 'boolean' },
                  accepts_rssb: { type: 'boolean' },
                  notes: { type: 'string' }
                }
              }
            },
            related_tests: { type: 'array', items: { type: 'string' } }
          }
        }
      });
      setResults(result);
    } catch (e) {
      toast.error('Lab search failed. Please try again.');
    } finally {
      setSearching(false);
    }
  };

  useEffect(() => {
    if (preloadTest && preloadTest.length >= 3) searchTest(preloadTest);
  }, []);

  useEffect(() => {
    if (query.length >= 3) {
      const timer = setTimeout(() => searchTest(), 600);
      return () => clearTimeout(timer);
    }
  }, [query]);

  // Select lab and save preferred lab back to encounter
  const selectLab = async (lab) => {
    const isDeselecting = selectedLab?.lab_name === lab.lab_name;
    const newSelection = isDeselecting ? null : lab;
    setSelectedLab(newSelection);

    if (newSelection && encounterId && encounter) {
      const labs = orderedLabs.map(l =>
        (l.test || l.test_name)?.toLowerCase().includes(query.toLowerCase())
          ? { ...l, preferred_lab: newSelection.lab_name }
          : l
      );
      await base44.entities.Encounter.update(encounterId, { lab_orders: JSON.stringify(labs) });
      queryClient.invalidateQueries({ queryKey: ['encounter', encounterId] });
      toast.success(`${newSelection.lab_name} selected and saved to encounter`);
    }
  };

  const saveLabRefill = async () => {
    if (!refillData.date) { toast.error('Set a follow-up date'); return; }
    if (encounter && encounterId) {
      const labs = orderedLabs.map(l =>
        (l.test || l.test_name)?.toLowerCase().includes(query.toLowerCase())
          ? { ...l, refill_date: refillData.date, refill_frequency: refillData.frequency, preferred_lab: selectedLab?.lab_name, refill_notes: refillData.notes }
          : l
      );
      await base44.entities.Encounter.update(encounterId, { lab_orders: JSON.stringify(labs) });
      queryClient.invalidateQueries({ queryKey: ['encounter', encounterId] });
      toast.success(`Follow-up lab test scheduled for ${refillData.date}`);
    }
    setRefillModal(false);
  };

  return (
     <div className="space-y-6 max-w-6xl">
       <div className="flex items-center gap-2 mb-4">
         <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
           <ArrowLeft className="w-4 h-4" />
         </Button>
       </div>
       <PageHeader
         title="Lab Test Search"
         subtitle="Find the best lab across Rwanda — with scoring, insurance & follow-up scheduling"
         action={
           encounterId && (
             <Button variant="outline" className="gap-2" onClick={() => {
               const p = new URLSearchParams();
               p.set('encounterId', encounterId);
               if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
               navigate(`/referrals?${p.toString()}`);
             }}>
               Next: Referrals <ArrowRight className="w-4 h-4" />
             </Button>
           )
         }
       />

      {/* Encounter context — auto-populated labs */}
      {encounter && (
        <Card className="p-4 border-0 shadow-sm bg-primary/5">
          <p className="text-xs font-semibold text-primary mb-2">Linked Encounter — {encounter.patient_name}</p>
          {orderedLabs.length > 0 ? (
            <div className="flex flex-wrap gap-2">
              {orderedLabs.map((l, i) => (
                <Badge
                  key={i}
                  variant={l.preferred_lab ? 'default' : 'secondary'}
                  className="text-xs cursor-pointer hover:bg-primary/20"
                  onClick={() => setQuery(l.test || l.test_name)}
                >
                  <FlaskConical className="w-3 h-3 mr-1" />{l.test || l.test_name}
                  {l.preferred_lab && <span className="ml-1 opacity-75">✓ {l.preferred_lab}</span>}
                </Badge>
              ))}
            </div>
          ) : (
            <div className="flex items-center gap-2 mt-1 p-3 bg-muted/50 rounded-lg">
              <Info className="w-4 h-4 text-muted-foreground shrink-0" />
              <p className="text-xs text-muted-foreground">
                No lab orders were added in this encounter. You can still search for a test manually below.
              </p>
            </div>
          )}
        </Card>
      )}

      <Card className="p-5 border-0 shadow-sm">
        <div className="relative max-w-xl">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search lab test (e.g. HbA1c, CBC, Malaria RDT, Creatinine)..."
            className="pl-10 pr-10 text-base h-12"
          />
          {searching && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-primary" />}
        </div>
        <p className="text-xs text-muted-foreground mt-2">Type at least 3 characters to search. Click a row to select the preferred lab — it saves automatically.</p>
      </Card>

      {results.test_name && (
        <>
          <Card className="p-5 border-0 shadow-sm">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <FlaskConical className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">{results.test_name}</h3>
                  <p className="text-sm text-muted-foreground">{results.category}</p>
                  {results.clinical_indication && <p className="text-xs text-muted-foreground">Indication: {results.clinical_indication}</p>}
                  {results.normal_range && <p className="text-xs text-accent mt-1">Normal Range: {results.normal_range}</p>}
                  {results.related_tests?.length > 0 && (
                    <div className="flex gap-2 mt-2 flex-wrap">
                      <span className="text-xs text-muted-foreground">Related:</span>
                      {results.related_tests.map((t, i) => (
                        <Badge key={i} variant="secondary" className="text-xs cursor-pointer hover:bg-primary/10" onClick={() => setQuery(t)}>{t}</Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              {encounterId && (
                <Button variant="outline" size="sm" className="gap-2 shrink-0" onClick={() => setRefillModal(true)}>
                  <RefreshCw className="w-4 h-4" /> Schedule Follow-up
                </Button>
              )}
            </div>
            {selectedLab && (
              <div className="mt-3 p-3 bg-accent/5 rounded-lg flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-accent" />
                <p className="text-sm font-semibold text-accent">Selected: {selectedLab.lab_name}</p>
                <Badge variant="secondary" className="text-xs">{selectedLab.turnaround_time}</Badge>
                <p className="text-xs text-muted-foreground ml-auto">Saved to encounter ✓</p>
              </div>
            )}
          </Card>

          <Card className="border-0 shadow-sm">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Laboratory</TableHead>
                  <TableHead>District / Type</TableHead>
                  <TableHead>Availability</TableHead>
                  <TableHead>Turnaround</TableHead>
                  <TableHead>Price (RWF)</TableHead>
                  <TableHead>Quality</TableHead>
                  <TableHead>Insurance</TableHead>
                  <TableHead>Select</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.results?.map((r, idx) => {
                  const lab = RWANDA_LABS.find(l => l.name === r.lab_name) || RWANDA_LABS[idx % RWANDA_LABS.length];
                  const isSelected = selectedLab?.lab_name === r.lab_name;
                  return (
                    <TableRow key={idx} className={isSelected ? 'bg-accent/5' : ''}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded bg-primary/5 flex items-center justify-center">
                            <FlaskConical className="w-3.5 h-3.5 text-primary" />
                          </div>
                          <div>
                            <p className="text-sm font-medium">{r.lab_name}</p>
                            <p className="text-xs text-muted-foreground flex items-center gap-1"><Phone className="w-3 h-3" />{lab.phone}</p>
                          </div>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-xs">
                          <div className="flex items-center gap-1"><MapPin className="w-3 h-3" />{lab.district}</div>
                          <Badge className={`text-xs mt-1 ${LAB_TYPE_COLORS[lab.type] || ''}`}>{lab.type}</Badge>
                        </div>
                      </TableCell>
                      <TableCell>
                        {r.available ? (
                          <Badge className="bg-accent/10 text-accent text-xs gap-1"><CheckCircle2 className="w-3 h-3" /> Available</Badge>
                        ) : (
                          <Badge className="bg-destructive/10 text-destructive text-xs gap-1"><XCircle className="w-3 h-3" /> Unavailable</Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-xs">{r.turnaround_time || '—'}</TableCell>
                      <TableCell className="text-sm font-medium">{r.price_rwf || '—'}</TableCell>
                      <TableCell>
                        {r.equipment_score && (
                          <div className="flex items-center gap-1">
                            <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                              <div className="h-full rounded-full bg-accent" style={{ width: `${r.equipment_score * 10}%` }} />
                            </div>
                            <span className="text-xs font-semibold">{r.equipment_score}/10</span>
                          </div>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex gap-1">
                          {r.accepts_mutuelle && <Badge className="text-xs bg-green-50 text-green-700 px-1">M</Badge>}
                          {r.accepts_rssb && <Badge className="text-xs bg-blue-50 text-blue-700 px-1">R</Badge>}
                        </div>
                      </TableCell>
                      <TableCell>
                        {r.available && (
                          <Button
                            size="sm"
                            variant={isSelected ? 'default' : 'outline'}
                            className={`text-xs h-7 px-2 gap-1 ${isSelected ? 'bg-accent hover:bg-accent/90' : ''}`}
                            onClick={() => selectLab(r)}
                          >
                            {isSelected ? <><CheckCircle2 className="w-3 h-3" />Selected</> : 'Select'}
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Card>
        </>
      )}

      {searched && !searching && !results.test_name && (
        <Card className="p-8 border-0 shadow-sm text-center">
          <p className="text-muted-foreground">No results found. Try a different test name.</p>
        </Card>
      )}

      {!searched && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {RWANDA_LABS.map(l => (
            <Card key={l.name} className="p-4 border-0 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex items-center justify-between mb-1">
                <p className="text-sm font-semibold line-clamp-1">{l.name}</p>
              </div>
              <Badge className={`text-xs mb-2 ${LAB_TYPE_COLORS[l.type] || ''}`}>{l.type}</Badge>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="w-3 h-3" />{l.district}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Phone className="w-3 h-3" />{l.phone}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Clock className="w-3 h-3" />{l.hours}</p>
            </Card>
          ))}
        </div>
      )}

      {/* Next Step Bar */}
      {encounterId && (
        <div className="flex gap-3 items-center p-4 bg-muted/30 rounded-xl border">
          <p className="text-sm text-muted-foreground flex-1">Done with lab orders?</p>
          <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => {
            const p = new URLSearchParams();
            p.set('encounterId', encounterId);
            if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
            navigate(`/referrals?${p.toString()}`);
          }}>
            Next: Referrals <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Follow-up Modal */}
      <Dialog open={refillModal} onOpenChange={setRefillModal}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><RefreshCw className="w-4 h-4" /> Schedule Follow-up Test</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <p className="text-sm text-muted-foreground">Patient can visit the selected lab directly on the scheduled date without a new doctor visit.</p>
            <div>
              <Label className="text-xs">Test</Label>
              <p className="text-sm font-semibold mt-0.5">{query}</p>
            </div>
            {selectedLab && (
              <div>
                <Label className="text-xs">Preferred Lab</Label>
                <p className="text-sm font-semibold mt-0.5 text-accent">{selectedLab.lab_name}</p>
              </div>
            )}
            <div>
              <Label className="text-xs">Follow-up Date *</Label>
              <Input type="date" className="mt-1" value={refillData.date} onChange={e => setRefillData(p => ({ ...p, date: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs">Repeat Frequency</Label>
              <Input className="mt-1" value={refillData.frequency} onChange={e => setRefillData(p => ({ ...p, frequency: e.target.value }))} placeholder="e.g. Monthly, Every 3 months" />
            </div>
            <div>
              <Label className="text-xs">Notes</Label>
              <Input className="mt-1" value={refillData.notes} onChange={e => setRefillData(p => ({ ...p, notes: e.target.value }))} placeholder="Fasting required, etc." />
            </div>
            <div className="flex gap-2">
              <Button className="flex-1 gap-2" onClick={saveLabRefill}><CalendarCheck className="w-4 h-4" /> Save Schedule</Button>
              <Button variant="outline" onClick={() => setRefillModal(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}