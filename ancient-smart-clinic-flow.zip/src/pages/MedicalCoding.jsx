import React, { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Sparkles, Loader2, Plus, X, CheckCircle2, FileCode2, ArrowRight, Pill, ArrowLeft } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

export default function MedicalCoding() {
  const urlParams = new URLSearchParams(window.location.search);
  const paramEncounterId = urlParams.get('encounterId');
  const paramAppointmentId = urlParams.get('appointmentId');

  const [selectedEncounter, setSelectedEncounter] = useState(null);
  const [encounterText, setEncounterText] = useState('');
  const [icdCodes, setIcdCodes] = useState([]);
  const [cptCodes, setCptCodes] = useState([]);
  const [modifiers, setModifiers] = useState([]);
  const [generating, setGenerating] = useState(false);
  const [saved, setSaved] = useState(false);
  const [manualIcd, setManualIcd] = useState({ code: '', description: '' });
  const [manualCpt, setManualCpt] = useState({ code: '', description: '' });
  const [manualMod, setManualMod] = useState({ code: '', description: '' });
  const navigate = useNavigate();

  const { data: encounters = [] } = useQuery({
    queryKey: ['encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date'),
  });

  useEffect(() => {
    if (paramEncounterId && encounters.length > 0) {
      loadEncounter(paramEncounterId);
    }
  }, [paramEncounterId, encounters]);

  const loadEncounter = (encId) => {
    const enc = encounters.find(e => e.id === encId);
    if (enc) {
      setSelectedEncounter(enc);
      setEncounterText(`Assessment: ${enc.assessment || ''}\nPlan: ${enc.plan || ''}\nSubjective: ${enc.subjective || ''}`);
      if (enc.icd_codes) {
        try { setIcdCodes(JSON.parse(enc.icd_codes)); } catch { setIcdCodes([]); }
      }
      if (enc.cpt_codes) {
        try { setCptCodes(JSON.parse(enc.cpt_codes)); } catch { setCptCodes([]); }
      }
    }
  };

  const getCodeSuggestions = async () => {
    if (!encounterText.trim()) {
      toast.error('Please enter or load encounter text first');
      return;
    }
    setGenerating(true);
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a Rwanda medical coding AI expert. Based on this clinical encounter text, suggest ICD-10 diagnostic codes, CPT procedure codes, and billing modifiers.

      IMPORTANT: Rwanda uses ICD-10 (not ICD-11). Use ICD-10 codes only.

      Encounter Text:
      "${encounterText}"

      For each suggested code, provide:
      - The code (ICD-10 format e.g. A00.0, J45, etc.)
      - Description
      - Confidence score (0-100)

      Consider Rwanda's healthcare payer context: RSSB (RAMA), MMI, Mutuelle de Santé.`,
      response_json_schema: {
        type: 'object',
        properties: {
          icd_codes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                code: { type: 'string' },
                description: { type: 'string' },
                confidence: { type: 'number' }
              }
            }
          },
          cpt_codes: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                code: { type: 'string' },
                description: { type: 'string' },
                confidence: { type: 'number' }
              }
            }
          },
          modifiers: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                code: { type: 'string' },
                description: { type: 'string' },
                confidence: { type: 'number' }
              }
            }
          }
        }
      }
    });
    setIcdCodes(result.icd_codes || []);
    setCptCodes(result.cpt_codes || []);
    setModifiers(result.modifiers || []);
    setGenerating(false);
    toast.success('Code suggestions generated');
  };

  const saveToEncounter = async () => {
    if (selectedEncounter) {
      await base44.entities.Encounter.update(selectedEncounter.id, {
        icd_codes: JSON.stringify(icdCodes),
        cpt_codes: JSON.stringify(cptCodes),
        modifiers: JSON.stringify(modifiers),
      });
      setSaved(true);
      toast.success('Codes saved to encounter');
    }
  };

  const removeCode = (type, idx) => {
    if (type === 'icd') setIcdCodes(prev => prev.filter((_, i) => i !== idx));
    if (type === 'cpt') setCptCodes(prev => prev.filter((_, i) => i !== idx));
    if (type === 'mod') setModifiers(prev => prev.filter((_, i) => i !== idx));
  };

  const addManualCode = (type) => {
    if (type === 'icd' && manualIcd.code) { setIcdCodes(prev => [...prev, { ...manualIcd, confidence: 100 }]); setManualIcd({ code: '', description: '' }); }
    if (type === 'cpt' && manualCpt.code) { setCptCodes(prev => [...prev, { ...manualCpt, confidence: 100 }]); setManualCpt({ code: '', description: '' }); }
    if (type === 'mod' && manualMod.code) { setModifiers(prev => [...prev, { ...manualMod, confidence: 100 }]); setManualMod({ code: '', description: '' }); }
  };

  const CodeTable = ({ title, codes, type, manual, setManual }) => (
    <Card className="p-5 border-0 shadow-sm">
      <div className="flex items-center justify-between mb-3">
        <h3 className="text-sm font-semibold">{title}</h3>
        <Badge variant="secondary" className="text-xs">{codes.length} codes</Badge>
      </div>
      {codes.length > 0 && (
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead className="text-xs">Code</TableHead>
              <TableHead className="text-xs">Description</TableHead>
              <TableHead className="text-xs">Confidence</TableHead>
              <TableHead className="text-xs w-12"></TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {codes.map((c, idx) => (
              <TableRow key={idx}>
                <TableCell className="font-mono text-sm font-semibold text-primary">{c.code}</TableCell>
                <TableCell className="text-sm">{c.description}</TableCell>
                <TableCell>
                  <div className="flex items-center gap-2">
                    <div className="w-16 h-1.5 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${c.confidence >= 80 ? 'bg-accent' : c.confidence >= 60 ? 'bg-orange-400' : 'bg-destructive'}`}
                        style={{ width: `${c.confidence}%` }}
                      />
                    </div>
                    <span className="text-xs text-muted-foreground">{c.confidence}%</span>
                  </div>
                </TableCell>
                <TableCell>
                  <Button variant="ghost" size="sm" onClick={() => removeCode(type, idx)}>
                    <X className="w-3 h-3" />
                  </Button>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      )}
      <div className="flex gap-2 mt-3">
        <Input placeholder="Code" value={manual.code} onChange={e => setManual({ ...manual, code: e.target.value })} className="w-28 text-sm" />
        <Input placeholder="Description" value={manual.description} onChange={e => setManual({ ...manual, description: e.target.value })} className="flex-1 text-sm" />
        <Button variant="outline" size="sm" onClick={() => addManualCode(type)} className="gap-1">
          <Plus className="w-3 h-3" /> Add
        </Button>
      </div>
    </Card>
  );

  return (
     <div className="space-y-6 max-w-6xl">
       <div className="flex items-center gap-2 mb-4">
         <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
           <ArrowLeft className="w-4 h-4" />
         </Button>
       </div>
       <PageHeader
         title="Medical Coding Engine"
         subtitle="ICD-10, CPT & Modifier Code Management (Rwanda Standard)"
         action={
           selectedEncounter && saved && (
             <Button className="gap-2" onClick={() => {
               let meds = '';
               try { meds = selectedEncounter?.medications ? JSON.parse(selectedEncounter.medications)?.[0]?.name || '' : ''; } catch {}
               const params = new URLSearchParams();
               params.set('encounterId', selectedEncounter.id);
               if (paramAppointmentId) params.set('appointmentId', paramAppointmentId);
               params.set('medication', meds);
               navigate(`/pharmacy?${params.toString()}`);
             }}>
               Proceed to Pharmacy <ArrowRight className="w-4 h-4" />
             </Button>
           )
         }
       />

      {selectedEncounter && (
        <Card className="p-4 border-0 shadow-sm bg-primary/5">
          <p className="text-xs font-semibold text-primary">Linked Encounter — {selectedEncounter.patient_name}</p>
          <p className="text-xs text-muted-foreground mt-0.5">#{selectedEncounter.encounter_number || selectedEncounter.id?.slice(-8)} · {selectedEncounter.status}</p>
        </Card>
      )}

      <Card className="p-5 border-0 shadow-sm">
        <Textarea
          value={encounterText}
          onChange={e => setEncounterText(e.target.value)}
          placeholder="Encounter assessment/plan text (auto-loaded from encounter)..."
          className="min-h-[100px] text-sm"
        />
        <Button className="mt-3 gap-2" onClick={getCodeSuggestions} disabled={generating}>
          {generating ? <><Loader2 className="w-4 h-4 animate-spin" /> Generating...</> : <><Sparkles className="w-4 h-4" /> Get Code Suggestions</>}
        </Button>
      </Card>

      <div className="grid grid-cols-1 gap-4">
        <CodeTable title="ICD-10 Diagnostic Codes (Rwanda Standard)" codes={icdCodes} type="icd" manual={manualIcd} setManual={setManualIcd} />
        <CodeTable title="CPT Procedure Codes" codes={cptCodes} type="cpt" manual={manualCpt} setManual={setManualCpt} />
        <CodeTable title="Billing Modifiers" codes={modifiers} type="mod" manual={manualMod} setManual={setManualMod} />
      </div>

      {selectedEncounter && (
        <div className="flex gap-3 flex-wrap items-center p-4 bg-muted/30 rounded-xl border">
          <Button className="gap-2" onClick={saveToEncounter} disabled={icdCodes.length === 0 && cptCodes.length === 0}>
            <CheckCircle2 className="w-4 h-4" /> Save Codes to Encounter
          </Button>
          <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => {
            let meds = '';
            try { meds = selectedEncounter?.medications ? JSON.parse(selectedEncounter.medications)?.[0]?.name || '' : ''; } catch {}
            const params = new URLSearchParams();
            params.set('encounterId', selectedEncounter.id);
            if (paramAppointmentId) params.set('appointmentId', paramAppointmentId);
            params.set('medication', meds);
            navigate(`/pharmacy?${params.toString()}`);
          }}>
            <Pill className="w-4 h-4" /> Next: Pharmacy <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}