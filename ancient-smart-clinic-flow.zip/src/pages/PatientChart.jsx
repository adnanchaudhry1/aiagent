import React, { useState } from 'react';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useParams, useSearchParams } from 'react-router-dom';
import {
  User, Calendar, Stethoscope, Pill, FlaskConical, GitBranch,
  ShieldCheck, Map, Activity, ArrowLeft, Mic, CheckSquare, Lock, ExternalLink
} from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import TalkingModeEncounter from '@/components/encounter/TalkingModeEncounter';
import { usePatientRiskFlags } from '@/hooks/useHighRiskPatients';
import PatientChartEncounters from '@/components/patient/PatientChartEncounters';
import PatientChartAppointments from '@/components/patient/PatientChartAppointments';
import PatientChartMedications from '@/components/patient/PatientChartMedications';
import PatientChartLabs from '@/components/patient/PatientChartLabs';
import PatientChartReferrals from '@/components/patient/PatientChartReferrals';
import PatientChartClaims from '@/components/patient/PatientChartClaims';
import PatientGISPanel from '@/components/patient/PatientGISPanel';
import PatientEligibility from '@/components/patient/PatientEligibility';
import PatientMedicalCoding from '@/components/patient/PatientMedicalCoding';

export default function PatientChart() {
  const { patientId } = useParams();
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [talkingMode, setTalkingMode] = useState(false);
  const [talkingAppointment, setTalkingAppointment] = useState(null);
  const defaultTab = searchParams.get('tab') || 'appointments';
  const { data: patient, isLoading } = useQuery({
    queryKey: ['patient', patientId],
    queryFn: () => base44.entities.Patient.filter({ id: patientId }).then(r => r[0]),
    enabled: !!patientId,
  });

  const { data: appointments = [] } = useQuery({
    queryKey: ['patient-appointments', patientId],
    queryFn: () => base44.entities.Appointment.filter({ patient_id: patientId }, '-appointment_date'),
    enabled: !!patientId,
  });

  const { data: encounters = [], refetch: refetchEncounters } = useQuery({
    queryKey: ['patient-encounters', patientId],
    queryFn: () => base44.entities.Encounter.filter({ patient_id: patientId }, '-created_date'),
    enabled: !!patientId,
  });

  const { data: claims = [] } = useQuery({
    queryKey: ['patient-claims', patientId],
    queryFn: () => base44.entities.InsuranceClaim.filter({ patient_id: patientId }, '-created_date'),
    enabled: !!patientId,
  });

  // Hook must be called unconditionally — before any early returns
  const { flags: riskFlags, severity: riskSeverity } = usePatientRiskFlags(encounters);

  const handleStartAppointment = (apt) => {
    setTalkingAppointment(apt);
    setTalkingMode(true);
  };

  const handleEncounterSaved = () => {
    refetchEncounters();
    queryClient.invalidateQueries({ queryKey: ['patient-appointments', patientId] });
    queryClient.invalidateQueries({ queryKey: ['patient-claims', patientId] });
    queryClient.invalidateQueries({ queryKey: ['patient-encounters', patientId] });
    queryClient.invalidateQueries({ queryKey: ['appointments'] });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="w-8 h-8 border-4 border-primary/30 border-t-primary rounded-full animate-spin" />
      </div>
    );
  }

  if (!patient) {
    return (
      <div className="text-center py-16">
        <p className="text-muted-foreground">Patient not found.</p>
        <Button variant="outline" className="mt-4" onClick={() => navigate('/patients')}>Back to Patients</Button>
      </div>
    );
  }

  const latestEncounter = encounters[0];
  const activeAppointment = appointments.find(a => a.status === 'Scheduled' || a.status === 'Checked In' || a.status === 'In Progress');

  return (
    <div className="space-y-5 max-w-7xl">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate('/patients')}>
            <ArrowLeft className="w-4 h-4" />
          </Button>
          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center">
            <span className="text-xl font-bold text-primary">{patient.full_name?.[0]}</span>
          </div>
          <div>
            <h1 className="text-2xl font-bold">{patient.full_name}</h1>
            <div className="flex items-center gap-2 mt-1 flex-wrap">
              <Badge variant="secondary" className="text-xs">{patient.gender}</Badge>
              {patient.date_of_birth && <Badge variant="outline" className="text-xs">DOB: {patient.date_of_birth}</Badge>}
              {patient.blood_type && <Badge variant="outline" className="text-xs">{patient.blood_type}</Badge>}
              {patient.insurance_type && <Badge className="text-xs bg-primary/10 text-primary">{patient.insurance_type}</Badge>}
              <Badge variant={patient.status === 'Active' ? 'default' : 'secondary'} className="text-xs">{patient.status}</Badge>
              {patient.national_id && <Badge variant="outline" className="text-xs">ID: {patient.national_id}</Badge>}
            </div>
          </div>
        </div>
        <div className="flex gap-2">
          {activeAppointment && (
            <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => handleStartAppointment(activeAppointment)}>
              <Mic className="w-4 h-4" /> Start AI Encounter
            </Button>
          )}
          <Button variant="outline" className="gap-2" onClick={() => { setTalkingAppointment(null); setTalkingMode(true); }}>
            <Mic className="w-4 h-4" /> New Encounter
          </Button>
        </div>
      </div>

      {/* High-Risk Alert Banner */}
      {riskSeverity && (
        <Card className={`p-4 border-0 shadow-sm border-l-4 ${riskSeverity === 'critical' ? 'border-l-destructive bg-destructive/5' : 'border-l-orange-400 bg-orange-50/50'}`}>
          <div className="flex items-start gap-3">
            <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${riskSeverity === 'critical' ? 'bg-destructive/15' : 'bg-orange-100'}`}>
              <span className="text-lg">{riskSeverity === 'critical' ? '🔴' : '🟠'}</span>
            </div>
            <div className="flex-1">
              <p className={`text-sm font-bold ${riskSeverity === 'critical' ? 'text-destructive' : 'text-orange-700'}`}>
                {riskSeverity === 'critical' ? 'Critical Risk — Immediate Attention Required' : 'High-Risk Flags Detected'}
              </p>
              <p className="text-xs text-muted-foreground mt-0.5 mb-2">
                {riskFlags.length} flag{riskFlags.length > 1 ? 's' : ''} detected from ICD-10 codes, lab orders and clinical assessments
              </p>
              <div className="flex flex-wrap gap-1.5">
                {riskFlags.map((f, i) => (
                  <span key={i} className={`inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-xs border font-medium ${f.severity === 'critical' ? 'bg-destructive/10 text-destructive border-destructive/30' : 'bg-orange-50 text-orange-700 border-orange-200'}`}>
                    <span className="font-mono">{f.type}</span> · {f.description}
                  </span>
                ))}
              </div>
            </div>
          </div>
        </Card>
      )}

      {/* Active Appointment Banner */}
      {activeAppointment && (
        <Card className="p-4 border-0 shadow-sm bg-accent/5 border-l-4 border-l-accent">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm font-semibold text-accent">Active Appointment</p>
              <p className="text-xs text-muted-foreground mt-0.5">Reason: {activeAppointment.reason || 'General visit'} • Status: {activeAppointment.status}</p>
            </div>
            <Button size="sm" className="gap-2 bg-accent hover:bg-accent/90 text-white" onClick={() => handleStartAppointment(activeAppointment)}>
              <Mic className="w-3.5 h-3.5" /> Start AI-Assisted Encounter
            </Button>
          </div>
        </Card>
      )}

      {/* Patient Info Cards */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-3">
        <Card className="p-4 border-0 shadow-sm">
          <p className="text-xs text-muted-foreground">National ID</p>
          <p className="text-sm font-semibold mt-0.5">{patient.national_id || '—'}</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm">
          <p className="text-xs text-muted-foreground">Phone</p>
          <p className="text-sm font-semibold mt-0.5">{patient.phone || '—'}</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm">
          <p className="text-xs text-muted-foreground">District</p>
          <p className="text-sm font-semibold mt-0.5">{patient.district || '—'}</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm">
          <p className="text-xs text-muted-foreground">Insurance</p>
          <p className="text-sm font-semibold mt-0.5">{patient.insurance_type || '—'}</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm">
          <p className="text-xs text-muted-foreground">Insurance ID</p>
          <p className="text-sm font-semibold mt-0.5">{patient.insurance_id || '—'}</p>
        </Card>
        {patient.allergies && (
          <Card className="p-4 border-0 shadow-sm border-destructive/20 bg-destructive/5 col-span-2">
            <p className="text-xs text-destructive font-semibold">⚠ Allergies</p>
            <p className="text-sm mt-0.5">{patient.allergies}</p>
          </Card>
        )}
        {patient.chronic_conditions && (
          <Card className="p-4 border-0 shadow-sm col-span-3 border-orange-200 bg-orange-50/50">
            <p className="text-xs text-orange-600 font-semibold">Chronic Conditions</p>
            <p className="text-sm mt-0.5">{patient.chronic_conditions}</p>
          </Card>
        )}
      </div>

      {/* Quick stats */}
      <div className="grid grid-cols-3 gap-3">
        <Card className="p-4 border-0 shadow-sm text-center">
          <p className="text-2xl font-bold text-primary">{encounters.length}</p>
          <p className="text-xs text-muted-foreground">Total Encounters</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm text-center">
          <p className="text-2xl font-bold text-accent">{appointments.length}</p>
          <p className="text-xs text-muted-foreground">Appointments</p>
        </Card>
        <Card className="p-4 border-0 shadow-sm text-center">
          <p className="text-2xl font-bold text-chart-4">{claims.length}</p>
          <p className="text-xs text-muted-foreground">Insurance Claims</p>
        </Card>
      </div>

      {/* All Patient Modules as Tabs */}
      <Tabs defaultValue={defaultTab} className="w-full">
        <TabsList className="flex-wrap h-auto gap-1 bg-muted p-1">
          <TabsTrigger value="appointments" className="gap-1.5 text-xs"><Calendar className="w-3.5 h-3.5" />Appointments ({appointments.length})</TabsTrigger>
          <TabsTrigger value="encounters" className="gap-1.5 text-xs"><Stethoscope className="w-3.5 h-3.5" />Encounters ({encounters.length})</TabsTrigger>
          <TabsTrigger value="coding" className="gap-1.5 text-xs"><Activity className="w-3.5 h-3.5" />Medical Coding</TabsTrigger>
          <TabsTrigger value="medications" className="gap-1.5 text-xs"><Pill className="w-3.5 h-3.5" />Medications</TabsTrigger>
          <TabsTrigger value="labs" className="gap-1.5 text-xs"><FlaskConical className="w-3.5 h-3.5" />Lab Orders</TabsTrigger>
          <TabsTrigger value="referrals" className="gap-1.5 text-xs"><GitBranch className="w-3.5 h-3.5" />Referrals</TabsTrigger>
          <TabsTrigger value="claims" className="gap-1.5 text-xs"><ShieldCheck className="w-3.5 h-3.5" />Insurance Claims ({claims.length})</TabsTrigger>
          <TabsTrigger value="eligibility" className="gap-1.5 text-xs"><CheckSquare className="w-3.5 h-3.5" />Eligibility</TabsTrigger>
          <TabsTrigger value="gis" className="gap-1.5 text-xs"><Map className="w-3.5 h-3.5" />Disease Map</TabsTrigger>
        </TabsList>

        <TabsContent value="appointments" className="mt-4">
          <PatientChartAppointments appointments={appointments} patient={patient} onStartAppointment={handleStartAppointment} />
        </TabsContent>
        <TabsContent value="encounters" className="mt-4">
          <PatientChartEncounters encounters={encounters} patient={patient} claims={claims} patientId={patientId} />
        </TabsContent>
        <TabsContent value="coding" className="mt-4">
          <PatientMedicalCoding encounters={encounters} patient={patient} />
        </TabsContent>
        <TabsContent value="medications" className="mt-4">
          <PatientChartMedications encounters={encounters} patient={patient} />
        </TabsContent>
        <TabsContent value="labs" className="mt-4">
          <PatientChartLabs encounters={encounters} patient={patient} />
        </TabsContent>
        <TabsContent value="referrals" className="mt-4">
          <PatientChartReferrals encounters={encounters} patient={patient} />
        </TabsContent>
        <TabsContent value="claims" className="mt-4">
          <PatientChartClaims claims={claims} patient={patient} encounters={encounters} />
        </TabsContent>
        <TabsContent value="eligibility" className="mt-4">
          <PatientEligibility patient={patient} />
        </TabsContent>
        <TabsContent value="gis" className="mt-4">
          <PatientGISPanel patient={patient} latestEncounter={latestEncounter} />
        </TabsContent>
      </Tabs>

      {/* AI Talking Mode Encounter */}
      <TalkingModeEncounter
        open={talkingMode}
        onClose={() => { setTalkingMode(false); setTalkingAppointment(null); handleEncounterSaved(); }}
        appointment={talkingAppointment || { patient_id: patient.id, patient_name: patient.full_name, reason: '' }}
        patient={patient}
        onEncounterSaved={handleEncounterSaved}
      />
    </div>
  );
}