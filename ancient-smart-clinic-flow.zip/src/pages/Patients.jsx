import React, { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Plus, Search, UserPlus, Eye, Stethoscope, FolderOpen, AlertTriangle, X } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import PageHeader from '@/components/shared/PageHeader';
import { useHighRiskPatients } from '@/hooks/useHighRiskPatients';

const defaultPatient = {
  full_name: '', date_of_birth: '', gender: 'Male', national_id: '',
  phone: '', district: '', insurance_type: 'Mutuelle de Santé', insurance_id: '',
  blood_type: '', allergies: '', chronic_conditions: '', emergency_contact: '', status: 'Active'
};

export default function Patients() {
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState(defaultPatient);
  const [search, setSearch] = useState('');
  const queryClient = useQueryClient();
  const navigate = useNavigate();

  const urlParams = new URLSearchParams(window.location.search);
  const showFlaggedOnly = urlParams.get('flagged') === 'true';

  const { data: patients = [], isLoading } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });

  const { data: encounters = [] } = useQuery({
    queryKey: ['encounters'],
    queryFn: () => base44.entities.Encounter.list('-created_date', 100),
  });

  const riskPatients = useHighRiskPatients(encounters, patients);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Patient.create({
      ...data,
      mr_number: 'MR-' + Math.floor(10000000 + Math.random() * 90000000),
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['patients'] });
      setShowForm(false);
      setFormData(defaultPatient);
    },
  });

  const flaggedPatientIds = new Set(riskPatients.map(r => r.patientId));

  const filtered = patients.filter(p => {
    const matchesSearch = p.full_name?.toLowerCase().includes(search.toLowerCase()) || p.national_id?.includes(search) || p.mr_number?.toLowerCase().includes(search.toLowerCase());
    if (showFlaggedOnly) return matchesSearch && flaggedPatientIds.has(p.id);
    return matchesSearch;
  });

  const updateField = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));

  return (
    <div className="space-y-6 max-w-7xl">
      <PageHeader
        title="Patient Registry"
        subtitle={`${patients.length} patients in system`}
        action={
          <Button className="gap-2" onClick={() => setShowForm(true)}>
            <UserPlus className="w-4 h-4" /> Add Patient
          </Button>
        }
      />

      {showFlaggedOnly && (
        <div className="flex items-center gap-3 p-3 rounded-lg bg-destructive/10 border border-destructive/20">
          <AlertTriangle className="w-4 h-4 text-destructive shrink-0" />
          <p className="text-sm font-semibold text-destructive flex-1">Showing {filtered.length} high-risk flagged patient{filtered.length !== 1 ? 's' : ''} only</p>
          <Button size="sm" variant="ghost" className="h-7 text-xs gap-1" onClick={() => navigate('/patients')}>
            <X className="w-3 h-3" /> Clear filter
          </Button>
        </div>
      )}

      <Card className="border-0 shadow-sm">
        <div className="p-4 border-b">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input placeholder="Search by name, ID, or MR#..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9" />
          </div>
        </div>
        <Table>
          <TableHeader>
            <TableRow>
              <TableHead>Name</TableHead>
              <TableHead>National ID</TableHead>
              <TableHead>Gender</TableHead>
              <TableHead>District</TableHead>
              <TableHead>Phone</TableHead>
              <TableHead>Insurance</TableHead>
              <TableHead>Status</TableHead>
              <TableHead>Actions</TableHead>

            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">Loading...</TableCell></TableRow>
            ) : filtered.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="text-center py-8 text-muted-foreground">No patients found</TableCell></TableRow>
            ) : filtered.map(p => (
              <TableRow key={p.id} className="hover:bg-muted/50">
                <TableCell>
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center">
                      <span className="text-xs font-bold text-primary">{p.full_name?.[0]}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">{p.full_name}</p>
                      {p.mr_number && <p className="text-xs font-mono font-semibold text-primary">{p.mr_number}</p>}
                      {flaggedPatientIds.has(p.id) && (
                        <Badge className="text-xs bg-destructive/10 text-destructive mt-0.5">
                          {riskPatients.find(r => r.patientId === p.id)?.severity === 'critical' ? '🔴 Critical' : '🟠 High Risk'}
                        </Badge>
                      )}
                    </div>
                  </div>
                </TableCell>
                <TableCell>
                  <div>
                    <p className="text-xs text-muted-foreground">National ID</p>
                    <p className="text-sm">{p.national_id || '—'}</p>
                  </div>
                </TableCell>
                <TableCell className="text-sm">{p.gender}</TableCell>
                <TableCell className="text-sm">{p.district || '—'}</TableCell>
                <TableCell className="text-sm">{p.phone || '—'}</TableCell>
                <TableCell>
                  <div>
                    <Badge variant="secondary" className="text-xs">{p.insurance_type || 'None'}</Badge>
                    {p.insurance_id && <p className="text-xs text-muted-foreground mt-0.5">{p.insurance_id}</p>}
                  </div>
                </TableCell>
                <TableCell><Badge variant={p.status === 'Active' ? 'default' : 'secondary'} className="text-xs">{p.status}</Badge></TableCell>
                <TableCell>
                  <div className="flex gap-1">
                    <Link to={`/patients/${p.id}`}>
                      <Button variant="default" size="sm" className="gap-1 text-xs"><FolderOpen className="w-3 h-3" /> Chart</Button>
                    </Link>
                    <Link to={`/encounter?patientId=${p.id}&patientName=${encodeURIComponent(p.full_name)}`}>
                      <Button variant="ghost" size="sm" className="gap-1 text-xs"><Stethoscope className="w-3 h-3" /> Encounter</Button>
                    </Link>
                  </div>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </Card>

      <Dialog open={showForm} onOpenChange={setShowForm}>
        <DialogContent className="max-w-lg">
          <DialogHeader><DialogTitle>Register New Patient</DialogTitle></DialogHeader>
          <div className="grid grid-cols-2 gap-3 mt-2">
            <div className="col-span-2">
              <Label className="text-xs">Full Name *</Label>
              <Input value={formData.full_name} onChange={e => updateField('full_name', e.target.value)} placeholder="Patient name" />
            </div>
            <div>
              <Label className="text-xs">Date of Birth</Label>
              <Input type="date" value={formData.date_of_birth} onChange={e => updateField('date_of_birth', e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Gender *</Label>
              <Select value={formData.gender} onValueChange={v => updateField('gender', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Male">Male</SelectItem>
                  <SelectItem value="Female">Female</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">National ID</Label>
              <Input value={formData.national_id} onChange={e => updateField('national_id', e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">Phone</Label>
              <Input value={formData.phone} onChange={e => updateField('phone', e.target.value)} />
            </div>
            <div>
              <Label className="text-xs">District</Label>
              <Input value={formData.district} onChange={e => updateField('district', e.target.value)} placeholder="e.g. Kicukiro" />
            </div>
            <div>
              <Label className="text-xs">Insurance Type *</Label>
              <Select value={formData.insurance_type} onValueChange={v => updateField('insurance_type', v)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {['RSSB (RAMA)', 'MMI', 'Mutuelle de Santé', 'Private', 'None'].map(t => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Insurance ID / Member #</Label>
              <Input value={formData.insurance_id} onChange={e => updateField('insurance_id', e.target.value)} placeholder="e.g. RAMA-001234" />
            </div>
            <div>
              <Label className="text-xs">Blood Type</Label>
              <Select value={formData.blood_type} onValueChange={v => updateField('blood_type', v)}>
                <SelectTrigger><SelectValue placeholder="Select" /></SelectTrigger>
                <SelectContent>
                  {['A+', 'A-', 'B+', 'B-', 'AB+', 'AB-', 'O+', 'O-'].map(t => (
                    <SelectItem key={t} value={t}>{t}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Allergies</Label>
              <Input value={formData.allergies} onChange={e => updateField('allergies', e.target.value)} placeholder="Known allergies" />
            </div>
            <div className="col-span-2">
              <Label className="text-xs">Chronic Conditions</Label>
              <Input value={formData.chronic_conditions} onChange={e => updateField('chronic_conditions', e.target.value)} placeholder="e.g. Hypertension, Diabetes" />
            </div>
          </div>
          {(!formData.full_name || !formData.gender || !formData.insurance_type) && (
            <p className="text-xs text-destructive mt-2">* Full name, gender, and insurance type are required.</p>
          )}
          <Button
            className="w-full mt-2"
            onClick={() => createMutation.mutate(formData)}
            disabled={!formData.full_name || !formData.gender || !formData.insurance_type || createMutation.isPending}
          >
            {createMutation.isPending ? 'Registering...' : 'Register Patient'}
          </Button>
        </DialogContent>
      </Dialog>
    </div>
  );
}