import React, { useState, useEffect, useMemo } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Pill, Search, MapPin, Phone, Clock, Loader2, CheckCircle2, XCircle, ArrowRight, RefreshCw, AlertTriangle, CalendarCheck, FlaskConical, ArrowLeft } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import PageHeader from '@/components/shared/PageHeader';
import { toast } from 'sonner';

const RWANDAN_PHARMACIES = [
  { name: 'Kipharma', district: 'Kicukiro', address: 'KN 4 Ave, Kigali', phone: '+250 788 300 100', hours: '8:00 AM - 9:00 PM' },
  { name: 'Locus Pharmacy', district: 'Gasabo', address: 'KG 9 Ave, Kimironko', phone: '+250 788 400 200', hours: '7:30 AM - 10:00 PM' },
  { name: 'Pharmaplus', district: 'Nyarugenge', address: 'KN 3 St, Downtown', phone: '+250 788 500 300', hours: '8:00 AM - 8:00 PM' },
  { name: 'Agafarma Pharmacy', district: 'Gasabo', address: 'KG 5 Ave, Remera', phone: '+250 788 600 400', hours: '7:00 AM - 9:00 PM' },
  { name: 'La Référence Pharmacy', district: 'Kicukiro', address: 'KK 15 Ave, Gikondo', phone: '+250 788 700 500', hours: '8:00 AM - 8:30 PM' },
  { name: 'Pharmacie Conseil', district: 'Huye', address: 'SH 1, Butare', phone: '+250 788 800 600', hours: '8:00 AM - 7:00 PM' },
  { name: 'Pharmacy One', district: 'Musanze', address: 'NR 4, Musanze', phone: '+250 788 900 700', hours: '8:00 AM - 8:00 PM' },
  { name: 'New Pharmacy Kigali', district: 'Nyarugenge', address: 'KN 67 St, Kigali City', phone: '+250 788 100 800', hours: '24 Hours' },
];

export default function PharmacySearch() {
  const urlParams = new URLSearchParams(window.location.search);
  const paramMedication = urlParams.get('medication') || '';
  const paramEncounterId = urlParams.get('encounterId') || '';
  const paramAppointmentId = urlParams.get('appointmentId') || '';

  const [query, setQuery] = useState(paramMedication);
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState({});
  const [searched, setSearched] = useState(false);
  const [selectedPharmacy, setSelectedPharmacy] = useState(null); // selected pharmacy for current medication
  const [dispensing, setDispensing] = useState(null);
  const [dispenseQty, setDispenseQty] = useState('');
  const [dispensedDone, setDispensedDone] = useState(false); // show "go to lab" prompt
  const [refillModal, setRefillModal] = useState(false);
  const [refillData, setRefillData] = useState({ date: '', dose: '', notes: '' });
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const { data: encounter } = useQuery({
    queryKey: ['encounter', paramEncounterId],
    queryFn: () => base44.entities.Encounter.filter({ id: paramEncounterId }).then(r => r[0]),
    enabled: !!paramEncounterId,
  });

  const prescribedMeds = useMemo(() => {
    if (!encounter?.medications) return [];
    try { return JSON.parse(encounter.medications); } catch { return []; }
  }, [encounter]);

  const prescribedDose = useMemo(() => {
    const med = prescribedMeds.find(m => m.name?.toLowerCase().includes(query.toLowerCase()));
    return med?.dose || null;
  }, [prescribedMeds, query]);

  const searchMedication = async () => {
    if (query.length < 3) return;
    setSearching(true);
    setSearched(true);
    setSelectedPharmacy(null);
    setDispensedDone(false);
    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a pharmacy inventory search system for Rwanda. Search for this medication: "${query}"
${prescribedDose ? `\nIMPORTANT: The prescribed dose from the doctor is: ${prescribedDose}. The pharmacy must only dispense this dose — not more, not less.` : ''}

For each of these pharmacies, determine if they would likely stock this medication and provide details:
${RWANDAN_PHARMACIES.map(p => p.name).join(', ')}

Include: stock status, price per prescribed dose in RWF, available dose strengths, max allowed quantity, and generic alternatives.`,
        response_json_schema: {
          type: 'object',
          properties: {
            medication_name: { type: 'string' },
            generic_name: { type: 'string' },
            medication_class: { type: 'string' },
            prescribed_dose: { type: 'string' },
            max_dispense_quantity: { type: 'string' },
            results: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  pharmacy_name: { type: 'string' },
                  available: { type: 'boolean' },
                  stock_level: { type: 'string' },
                  price_rwf: { type: 'string' },
                  available_doses: { type: 'array', items: { type: 'string' } },
                  notes: { type: 'string' }
                }
              }
            },
            alternatives: { type: 'array', items: { type: 'string' } }
          }
        }
      });
      setResults(result);
    } catch (e) {
      toast.error('Pharmacy search failed. Please try again.');
    } finally {
      setSearching(false);
    }
  };

  useEffect(() => {
    if (paramMedication && paramMedication.length >= 3) searchMedication();
  }, []);

  useEffect(() => {
    if (query.length >= 3) {
      const timer = setTimeout(searchMedication, 600);
      return () => clearTimeout(timer);
    }
  }, [query]);

  // Save selected pharmacy back to encounter
  const handleSelectPharmacy = async (pharmResult) => {
    const isDeselecting = selectedPharmacy?.pharmacy_name === pharmResult.pharmacy_name;
    const newSelection = isDeselecting ? null : pharmResult;
    setSelectedPharmacy(newSelection);

    if (newSelection && paramEncounterId && encounter) {
      // Save preferred pharmacy into the medication record
      const meds = prescribedMeds.map(m =>
        m.name?.toLowerCase().includes(query.toLowerCase())
          ? { ...m, preferred_pharmacy: newSelection.pharmacy_name }
          : m
      );
      await base44.entities.Encounter.update(paramEncounterId, { medications: JSON.stringify(meds) });
      queryClient.invalidateQueries({ queryKey: ['encounter', paramEncounterId] });
      toast.success(`${newSelection.pharmacy_name} selected and saved`);
    }
  };

  const handleDispense = (pharmResult) => {
    setDispensing(pharmResult);
    setDispenseQty('');
  };

  const confirmDispense = () => {
    if (!dispenseQty) { toast.error('Enter quantity'); return; }
    const prescribed = prescribedDose || results.prescribed_dose;
    toast.success(`Dispensed ${dispenseQty} units of ${results.medication_name}${prescribed ? ` (${prescribed})` : ''} at ${dispensing.pharmacy_name}`);
    setDispensing(null);
    setDispensedDone(true);
  };

  const saveRefill = async () => {
    if (!refillData.date || !refillData.dose) { toast.error('Fill in refill date and dose'); return; }
    if (encounter && paramEncounterId) {
      const meds = prescribedMeds.map(m =>
        m.name?.toLowerCase().includes(query.toLowerCase())
          ? { ...m, refill_date: refillData.date, refill_dose: refillData.dose, refill_notes: refillData.notes }
          : m
      );
      await base44.entities.Encounter.update(paramEncounterId, { medications: JSON.stringify(meds) });
      queryClient.invalidateQueries({ queryKey: ['encounter', paramEncounterId] });
      toast.success(`Refill scheduled for ${query} on ${refillData.date}`);
    }
    setRefillModal(false);
  };

  return (
     <div className="space-y-6 max-w-6xl">
       <div className="flex items-center gap-2 mb-4">
         <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
           <ArrowLeft className="w-4 h-4" />
         </Button>
       </div>
       <PageHeader
         title="Pharmacy Search & Inventory"
         subtitle="Dose-controlled dispensing across Rwandan pharmacies"
         action={
           paramEncounterId && (
             <Button variant="outline" className="gap-2" onClick={() => {
               const p = new URLSearchParams();
               p.set('encounterId', paramEncounterId);
               if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
               navigate(`/lab?${p.toString()}`);
             }}>
               Next: Lab Search <ArrowRight className="w-4 h-4" />
             </Button>
           )
         }
       />

      {/* Encounter context — auto-populated meds */}
      {encounter && (
        <Card className="p-4 border-0 shadow-sm bg-primary/5">
          <p className="text-xs font-semibold text-primary mb-1">Linked Encounter — {encounter.patient_name}</p>
          {prescribedMeds.length > 0 ? (
            <div className="flex flex-wrap gap-2 mt-2">
              {prescribedMeds.map((m, i) => (
                <Badge
                  key={i}
                  variant={m.preferred_pharmacy ? 'default' : 'secondary'}
                  className="text-xs cursor-pointer hover:bg-primary/20"
                  onClick={() => setQuery(m.name)}
                >
                  <Pill className="w-3 h-3 mr-1" />{m.name}{m.dose ? ` — ${m.dose}` : ''}
                  {m.preferred_pharmacy && <span className="ml-1 opacity-75">✓ {m.preferred_pharmacy}</span>}
                </Badge>
              ))}
            </div>
          ) : (
            <p className="text-xs text-muted-foreground mt-1">No medications prescribed in this encounter.</p>
          )}
        </Card>
      )}

      {/* "Done — go to lab" prompt after dispensing */}
      {dispensedDone && paramEncounterId && (
        <Card className="p-4 border-0 shadow-sm bg-accent/5 border-l-4 border-l-accent flex items-center justify-between">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-5 h-5 text-accent" />
            <div>
              <p className="text-sm font-semibold text-accent">Medication dispensed successfully!</p>
              <p className="text-xs text-muted-foreground">Would you like to proceed to the lab for ordered tests?</p>
            </div>
          </div>
          <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => {
            const p = new URLSearchParams();
            p.set('encounterId', paramEncounterId);
            if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
            navigate(`/lab?${p.toString()}`);
          }}>
            <FlaskConical className="w-4 h-4" /> Go to Lab <ArrowRight className="w-4 h-4" />
          </Button>
        </Card>
      )}

      <Card className="p-5 border-0 shadow-sm">
        <div className="relative max-w-xl">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            value={query}
            onChange={e => setQuery(e.target.value)}
            placeholder="Search medication (e.g. Amoxicillin, Metformin, Ibuprofen)..."
            className="pl-10 pr-10 text-base h-12"
          />
          {searching && <Loader2 className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 animate-spin text-primary" />}
        </div>
        <p className="text-xs text-muted-foreground mt-2">Type at least 3 characters to search. Click a pharmacy row to select & save it.</p>
      </Card>

      {/* Selected pharmacy banner */}
      {selectedPharmacy && results.medication_name && (
        <Card className="p-3 border-0 shadow-sm bg-accent/5 flex items-center gap-3">
          <CheckCircle2 className="w-4 h-4 text-accent shrink-0" />
          <p className="text-sm font-semibold text-accent">Selected: {selectedPharmacy.pharmacy_name}</p>
          <Badge variant="secondary" className="text-xs">{selectedPharmacy.price_rwf} RWF</Badge>
          <p className="text-xs text-muted-foreground ml-auto">Saved to encounter ✓</p>
        </Card>
      )}

      {results.medication_name && (
        <>
          <Card className="p-5 border-0 shadow-sm">
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                  <Pill className="w-6 h-6 text-primary" />
                </div>
                <div>
                  <h3 className="text-lg font-bold">{results.medication_name}</h3>
                  <p className="text-sm text-muted-foreground">{results.generic_name} — {results.medication_class}</p>
                  {(prescribedDose || results.prescribed_dose) && (
                    <div className="flex items-center gap-2 mt-2">
                      <Badge className="bg-orange-50 text-orange-700 text-xs">
                        <AlertTriangle className="w-3 h-3 mr-1" />
                        Prescribed Dose: {prescribedDose || results.prescribed_dose}
                      </Badge>
                      {results.max_dispense_quantity && (
                        <Badge variant="outline" className="text-xs">Max: {results.max_dispense_quantity}</Badge>
                      )}
                    </div>
                  )}
                  {results.alternatives?.length > 0 && (
                    <div className="flex gap-2 mt-2 flex-wrap">
                      <span className="text-xs text-muted-foreground">Alternatives:</span>
                      {results.alternatives.map((a, i) => (
                        <Badge key={i} variant="secondary" className="text-xs cursor-pointer hover:bg-primary/10" onClick={() => setQuery(a)}>{a}</Badge>
                      ))}
                    </div>
                  )}
                </div>
              </div>
              {paramEncounterId && (
                <Button variant="outline" size="sm" className="gap-2 shrink-0" onClick={() => setRefillModal(true)}>
                  <RefreshCw className="w-4 h-4" /> Schedule Refill
                </Button>
              )}
            </div>
          </Card>

          <Card className="border-0 shadow-sm">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Pharmacy</TableHead>
                  <TableHead>Location</TableHead>
                  <TableHead>Availability</TableHead>
                  <TableHead>Available Doses</TableHead>
                  <TableHead>Price (RWF)</TableHead>
                  <TableHead>Hours</TableHead>
                  <TableHead>Select</TableHead>
                  <TableHead>Dispense</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {results.results?.map((r, idx) => {
                  const pharmacy = RWANDAN_PHARMACIES.find(p => p.name === r.pharmacy_name) || RWANDAN_PHARMACIES[idx % RWANDAN_PHARMACIES.length];
                  const prescribed = prescribedDose || results.prescribed_dose;
                  const hasPrescribedDose = !prescribed || r.available_doses?.some(d => d.includes(prescribed.split(' ')[0]));
                  const isSelected = selectedPharmacy?.pharmacy_name === r.pharmacy_name;
                  return (
                    <TableRow key={idx} className={isSelected ? 'bg-accent/5' : ''}>
                      <TableCell>
                        <div className="flex items-center gap-2">
                          <div className="w-7 h-7 rounded bg-primary/5 flex items-center justify-center">
                            <Pill className="w-3.5 h-3.5 text-primary" />
                          </div>
                          <span className="text-sm font-medium">{r.pharmacy_name}</span>
                        </div>
                      </TableCell>
                      <TableCell>
                        <div className="text-xs">
                          <div className="flex items-center gap-1"><MapPin className="w-3 h-3" />{pharmacy.district}</div>
                          <p className="text-muted-foreground">{pharmacy.address}</p>
                        </div>
                      </TableCell>
                      <TableCell>
                        {r.available ? (
                          <Badge className="bg-accent/10 text-accent text-xs gap-1"><CheckCircle2 className="w-3 h-3" /> In Stock</Badge>
                        ) : (
                          <Badge className="bg-destructive/10 text-destructive text-xs gap-1"><XCircle className="w-3 h-3" /> Out of Stock</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <div className="flex flex-wrap gap-1">
                          {r.available_doses?.map((d, di) => {
                            const isPrescribed = prescribed && d.includes(prescribed.split(' ')[0]);
                            return (
                              <Badge key={di} className={`text-xs ${isPrescribed ? 'bg-primary/10 text-primary font-bold' : 'bg-muted text-muted-foreground'}`}>{d}</Badge>
                            );
                          })}
                        </div>
                      </TableCell>
                      <TableCell className="text-sm font-medium">{r.price_rwf || '—'}</TableCell>
                      <TableCell>
                        <span className="text-xs flex items-center gap-1"><Clock className="w-3 h-3" />{pharmacy.hours}</span>
                      </TableCell>
                      <TableCell>
                        {r.available && (
                          <Button
                            size="sm"
                            variant={isSelected ? 'default' : 'outline'}
                            className={`text-xs h-7 px-2 gap-1 ${isSelected ? 'bg-accent hover:bg-accent/90' : ''}`}
                            onClick={() => handleSelectPharmacy(r)}
                          >
                            {isSelected ? <><CheckCircle2 className="w-3 h-3" />Selected</> : 'Select'}
                          </Button>
                        )}
                      </TableCell>
                      <TableCell>
                        {r.available && (
                          <Button
                            size="sm"
                            className="text-xs h-7 px-2 gap-1"
                            disabled={!!(prescribed && !hasPrescribedDose)}
                            onClick={() => handleDispense(r)}
                            title={prescribed && !hasPrescribedDose ? `Prescribed dose ${prescribed} not available here` : 'Dispense medication'}
                          >
                            <Pill className="w-3 h-3" /> Dispense
                          </Button>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </Card>
        </>
      )}

      {searched && !searching && !results.medication_name && (
        <Card className="p-8 border-0 shadow-sm text-center">
          <p className="text-muted-foreground">No results found. Try a different medication name.</p>
        </Card>
      )}

      {!searched && (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {RWANDAN_PHARMACIES.map(p => (
            <Card key={p.name} className="p-4 border-0 shadow-sm hover:shadow-md transition-shadow">
              <p className="text-sm font-semibold">{p.name}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-1"><MapPin className="w-3 h-3" />{p.district}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Phone className="w-3 h-3" />{p.phone}</p>
              <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5"><Clock className="w-3 h-3" />{p.hours}</p>
            </Card>
          ))}
        </div>
      )}

      {/* Dispense Modal */}
      <Dialog open={!!dispensing} onOpenChange={() => setDispensing(null)}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle>Dispense Medication</DialogTitle></DialogHeader>
          {dispensing && (
            <div className="space-y-4 mt-2">
              <div className="p-3 bg-primary/5 rounded-lg">
                <p className="text-sm font-semibold">{results.medication_name}</p>
                <p className="text-xs text-muted-foreground mt-0.5">Pharmacy: {dispensing.pharmacy_name}</p>
                {(prescribedDose || results.prescribed_dose) && (
                  <p className="text-xs text-orange-600 font-medium mt-1">
                    <AlertTriangle className="w-3 h-3 inline mr-1" />
                    Prescribed dose: {prescribedDose || results.prescribed_dose} — cannot exceed
                  </p>
                )}
                {results.max_dispense_quantity && (
                  <p className="text-xs text-muted-foreground mt-0.5">Max quantity: {results.max_dispense_quantity}</p>
                )}
              </div>
              <div>
                <Label className="text-xs">Quantity to Dispense</Label>
                <Input
                  type="number"
                  min="1"
                  className="mt-1"
                  value={dispenseQty}
                  onChange={e => setDispenseQty(e.target.value)}
                  placeholder="Enter quantity..."
                />
                <p className="text-xs text-muted-foreground mt-1">Only the prescribed dose strength may be dispensed.</p>
              </div>
              <div className="flex gap-2">
                <Button className="flex-1" onClick={confirmDispense}>Confirm Dispense</Button>
                <Button variant="outline" onClick={() => setDispensing(null)}>Cancel</Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Next Step Bar */}
      {paramEncounterId && (
        <div className="flex gap-3 items-center p-4 bg-muted/30 rounded-xl border">
          <p className="text-sm text-muted-foreground flex-1">Done with pharmacy?</p>
          <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => {
            const p = new URLSearchParams();
            p.set('encounterId', paramEncounterId);
            if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
            navigate(`/lab?${p.toString()}`);
          }}>
            Next: Lab <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}

      {/* Refill Modal */}
      <Dialog open={refillModal} onOpenChange={setRefillModal}>
        <DialogContent className="max-w-sm">
          <DialogHeader><DialogTitle className="flex items-center gap-2"><RefreshCw className="w-4 h-4" /> Schedule Refill</DialogTitle></DialogHeader>
          <div className="space-y-3 mt-2">
            <p className="text-sm text-muted-foreground">Patient will collect refill from pharmacy without needing a new doctor visit.</p>
            <div>
              <Label className="text-xs">Medication</Label>
              <p className="text-sm font-semibold mt-1">{query}</p>
            </div>
            <div>
              <Label className="text-xs">Refill Date *</Label>
              <Input type="date" className="mt-1" value={refillData.date} onChange={e => setRefillData(p => ({ ...p, date: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs">Dose for Refill *</Label>
              <Input className="mt-1" value={refillData.dose} onChange={e => setRefillData(p => ({ ...p, dose: e.target.value }))}
                placeholder={prescribedDose || 'e.g. 500mg'} />
            </div>
            <div>
              <Label className="text-xs">Notes</Label>
              <Input className="mt-1" value={refillData.notes} onChange={e => setRefillData(p => ({ ...p, notes: e.target.value }))} placeholder="Any instructions..." />
            </div>
            <div className="flex gap-2">
              <Button className="flex-1 gap-2" onClick={saveRefill}><CalendarCheck className="w-4 h-4" /> Save Refill</Button>
              <Button variant="outline" onClick={() => setRefillModal(false)}>Cancel</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}