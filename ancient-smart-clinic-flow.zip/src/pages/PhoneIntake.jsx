import React, { useState } from 'react';
import { base44 } from '@/api/base44Client';
import { useQuery, useQueryClient } from '@tanstack/react-query';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import {
  Phone, PhoneCall, PhoneOff, Loader2, Sparkles, UserPlus,
  CheckCircle2, AlertTriangle, Users, ShieldCheck, ShieldX,
  Hospital, Building2, ArrowRight
} from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import TriageModule from '@/components/phone-intake/TriageModule';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';

const PRIORITY_COLORS = {
  Low: 'bg-accent/10 text-accent',
  Medium: 'bg-orange-100 text-orange-700',
  High: 'bg-destructive/10 text-destructive',
  Critical: 'bg-destructive text-white',
};

const COMMUNITY_WORKERS = [
  'Jean Baptiste Nkurunziza',
  'Marie Claire Uwimana',
  'Emmanuel Habimana',
  'Claudette Mukamana',
  'Patrick Bizimana',
];

// Simulated eligibility check
async function checkEligibilityAI(insuranceId, insuranceType, patientName) {
  const res = await base44.integrations.Core.InvokeLLM({
    prompt: `You are a Rwanda insurance eligibility verification system for an AI phone helpline. 
Check eligibility for:
Patient Name: ${patientName}
Insurance ID: ${insuranceId || 'Not provided'}
Insurance Type: ${insuranceType || 'Unknown'}

If the insurance ID is provided (not empty), return eligible=true. If insurance ID is missing or blank, return eligible=false.
Provide a short verbal message the AI will say to the patient.`,
    response_json_schema: {
      type: 'object',
      properties: {
        eligible: { type: 'boolean' },
        status_message: { type: 'string' },
        plan_name: { type: 'string' },
        co_payment: { type: 'string' },
      }
    }
  });
  return res;
}

export default function PhoneIntake() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  // Call state
  const [callActive, setCallActive] = useState(false);
  const [callStep, setCallStep] = useState('info'); // 'info' | 'eligibility' | 'symptoms' | 'triage' | 'routing' | 'assignment' | 'done'
  const [triageResult, setTriageResult] = useState(null);

  // Form data
  const [intakeData, setIntakeData] = useState({
    patient_name: '',
    date_of_birth: '',
    national_id: '',
    insurance_id: '',
    insurance_type: '',
    phone: '',
    problem_description: '',
  });

  // Step results
  const [eligibilityResult, setEligibilityResult] = useState(null);
  const [checkingEligibility, setCheckingEligibility] = useState(false);
  const [aiAnalysis, setAiAnalysis] = useState(null);
  const [processing, setProcessing] = useState(false);
  const [appointmentType, setAppointmentType] = useState(''); // 'chw' | 'hospital'
  const [assignedWorker, setAssignedWorker] = useState('');
  const [saved, setSaved] = useState(false);
  const [createdAppointmentNumber, setCreatedAppointmentNumber] = useState('');
  const [isReturningPatient, setIsReturningPatient] = useState(false);

  const { data: patients = [] } = useQuery({
    queryKey: ['patients'],
    queryFn: () => base44.entities.Patient.list(),
  });

  const startCall = () => {
    setCallActive(true);
    setCallStep('info');
    setEligibilityResult(null);
    setAiAnalysis(null);
    setTriageResult(null);
    setSaved(false);
    setAppointmentType('');
    setCreatedAppointmentNumber('');
    toast.success('AI has picked up the call. Collecting patient information...');
  };

  const endCall = () => {
    setCallActive(false);
    setCallStep('info');
  };

  const runEligibilityCheck = async () => {
    if (!intakeData.patient_name) { toast.error('Patient name is required'); return; }
    setCheckingEligibility(true);
    try {
      const result = await checkEligibilityAI(intakeData.insurance_id, intakeData.insurance_type, intakeData.patient_name);
      setEligibilityResult(result);
      if (result.eligible) {
        setCallStep('triage');
        toast.success('Patient is eligible. Proceeding to triage...');
      } else {
        setCallStep('eligibility');
        toast.error('Patient is not eligible for coverage.');
      }
    } catch {
      toast.error('Eligibility check failed');
    } finally {
      setCheckingEligibility(false);
    }
  };

  const handleTriageComplete = (result) => {
    setTriageResult(result);
    // Map triage result to existing aiAnalysis shape for downstream compatibility
    const priorityMap = { CRITICAL: 'Critical', HIGH: 'High', MODERATE: 'Medium', LOW: 'Low' };
    const mappedAnalysis = {
      priority: priorityMap[result.risk_level] || 'Medium',
      high_alert: result.risk_level === 'CRITICAL' || result.risk_level === 'HIGH',
      high_alert_reason: result.red_flags?.join(', ') || '',
      priority_reason: result.reason,
      recommended_actions: result.red_flags || [],
      suspected_conditions: [],
      doctor_visit_likely: result.routeType === 'hospital',
      ai_summary: result.summary || result.reason,
    };
    setAiAnalysis(mappedAnalysis);
    const workerIndex = result.routeType === 'hospital' ? 0 : Math.floor(Math.random() * COMMUNITY_WORKERS.length);
    setAssignedWorker(COMMUNITY_WORKERS[workerIndex]);
    setAppointmentType(result.routeType);
    setCallStep('routing');
    toast.success('Triage complete. Proceeding to routing...');
  };

  const analyzeWithAI = async () => {
    if (!intakeData.problem_description) { toast.error('Problem description is required.'); return; }
    setProcessing(true);
    try {
      const res = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a Rwanda healthcare AI triage system. A patient called the helpline. Analyze their case and assign priority.

Patient Name: ${intakeData.patient_name}
Date of Birth: ${intakeData.date_of_birth || 'Not provided'}
National ID: ${intakeData.national_id || 'Not provided'}
Insurance ID: ${intakeData.insurance_id || 'Not provided'}
Problem Description: ${intakeData.problem_description}

Assess:
1. Priority level (Low, Medium, High, Critical) based on symptoms
2. Whether this is a high alert case
3. Reason for the priority level
4. Recommended immediate actions
5. Suspected conditions based on symptoms
6. Whether doctor visit is likely needed`,
        response_json_schema: {
          type: 'object',
          properties: {
            priority: { type: 'string', enum: ['Low', 'Medium', 'High', 'Critical'] },
            high_alert: { type: 'boolean' },
            high_alert_reason: { type: 'string' },
            priority_reason: { type: 'string' },
            recommended_actions: { type: 'array', items: { type: 'string' } },
            suspected_conditions: { type: 'array', items: { type: 'string' } },
            doctor_visit_likely: { type: 'boolean' },
            ai_summary: { type: 'string' },
          }
        }
      });
      setAiAnalysis(res);
      const workerIndex = res.priority === 'Critical' || res.priority === 'High' ? 0 : Math.floor(Math.random() * COMMUNITY_WORKERS.length);
      setAssignedWorker(COMMUNITY_WORKERS[workerIndex]);
      const aiSuggested = (res.priority === 'Critical' || res.priority === 'High' || res.doctor_visit_likely) ? 'hospital' : 'chw';
      setAppointmentType(aiSuggested);
      setCallStep('routing');
    } catch {
      toast.error('AI analysis failed. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const saveCase = async () => {
    if (!aiAnalysis || !appointmentType) return;
    setProcessing(true);
    try {
      // Find or use patient id — match by national_id first, then name
      let patientId = '';
      const existingPatient = patients.find(p =>
        (intakeData.national_id && p.national_id === intakeData.national_id) ||
        p.full_name?.toLowerCase() === intakeData.patient_name?.toLowerCase()
      );
      if (existingPatient) {
        patientId = existingPatient.id;
        setIsReturningPatient(true);
        // Update existing patient with any new info from this call
        const updates = {};
        if (intakeData.phone && !existingPatient.phone) updates.phone = intakeData.phone;
        if (intakeData.insurance_id && !existingPatient.insurance_id) updates.insurance_id = intakeData.insurance_id;
        if (intakeData.insurance_type && !existingPatient.insurance_type) updates.insurance_type = intakeData.insurance_type;
        if (Object.keys(updates).length > 0) {
          await base44.entities.Patient.update(patientId, updates);
          queryClient.invalidateQueries({ queryKey: ['patients'] });
        }
      } else {
        setIsReturningPatient(false);
        const newPatient = await base44.entities.Patient.create({
          full_name: intakeData.patient_name,
          gender: 'Other',
          national_id: intakeData.national_id,
          phone: intakeData.phone,
          date_of_birth: intakeData.date_of_birth,
          insurance_id: intakeData.insurance_id,
          insurance_type: intakeData.insurance_type,
          status: 'Active',
        });
        patientId = newPatient.id;
        queryClient.invalidateQueries({ queryKey: ['patients'] });
      }

      const apptNumber = `APT-${Date.now().toString().slice(-8)}`;
      const callNotes = `[AI PHONE CALL — LOCKED]\n\nPatient stated: "${intakeData.problem_description}"\n\nAI Triage Summary: ${aiAnalysis.ai_summary}\nPriority: ${aiAnalysis.priority}\nSuspected: ${aiAnalysis.suspected_conditions?.join(', ') || 'N/A'}\n\nEligibility: ${eligibilityResult?.status_message || 'Verified'}`;

      if (appointmentType === 'chw') {
        // Create community worker visit
        await base44.entities.CommunityWorkerVisit.create({
          patient_id: patientId,
          patient_name: intakeData.patient_name,
          national_id: intakeData.national_id,
          date_of_birth: intakeData.date_of_birth,
          insurance_id: intakeData.insurance_id,
          phone: intakeData.phone,
          problem_description: intakeData.problem_description,
          priority: aiAnalysis.priority,
          high_alert: aiAnalysis.high_alert,
          high_alert_reason: aiAnalysis.high_alert_reason,
          worker_name: assignedWorker,
          status: 'Assigned',
          intake_source: 'AI Phone Call',
        });
        queryClient.invalidateQueries({ queryKey: ['community_visits'] });
        toast.success(`Community Worker case assigned to ${assignedWorker}`);
        reset();
        navigate('/community-worker');
      } else {
        // Create hospital appointment with locked AI call notes
        await base44.entities.Appointment.create({
          appointment_number: apptNumber,
          patient_id: patientId,
          patient_name: intakeData.patient_name,
          appointment_date: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
          reason: 'Pre-screening Appointment',
          status: 'Scheduled',
          intake_source: 'AI Phone Call',
          appointment_type: 'Hospital/Clinic',
          ai_call_notes: callNotes,
          call_transcript: `Patient: "${intakeData.problem_description}"`,
          ai_summary: aiAnalysis.ai_summary,
          risk_flags: aiAnalysis.high_alert ? aiAnalysis.high_alert_reason : '',
          is_locked: false,
        });
        queryClient.invalidateQueries({ queryKey: ['appointments'] });

        // Send confirmation notification if phone provided (best-effort, silent fail)
        if (intakeData.phone) {
          try {
            await base44.integrations.Core.SendEmail({
              to: intakeData.phone.includes('@') ? intakeData.phone : `${intakeData.phone.replace(/\s/g, '')}@placeholder.com`,
              subject: `Appointment Confirmation — ${apptNumber}`,
              body: `Dear ${intakeData.patient_name},\n\nYour pre-screening appointment has been successfully booked.\n\nAppointment Number: ${apptNumber}\nDate: ${new Date(Date.now() + 24 * 60 * 60 * 1000).toLocaleDateString()}\nType: Pre-screening Appointment\n\nPlease arrive 15 minutes early. If you need to reschedule, please call us.\n\nThank you,\nMurava Health`,
            });
          } catch {
            // silent fail
          }
        }

        toast.success(`Appointment ${apptNumber} booked successfully! Redirecting to Appointments...`);
        reset();
        navigate('/appointments');
      }
    } catch {
      toast.error('Failed to save. Please try again.');
    } finally {
      setProcessing(false);
    }
  };

  const reset = () => {
    setIntakeData({ patient_name: '', date_of_birth: '', national_id: '', insurance_id: '', insurance_type: '', phone: '', problem_description: '' });
    setAiAnalysis(null);
    setTriageResult(null);
    setEligibilityResult(null);
    setAssignedWorker('');
    setSaved(false);
    setCallActive(false);
    setCallStep('info');
    setAppointmentType('');
    setCreatedAppointmentNumber('');
    setIsReturningPatient(false);
  };

  return (
    <div className="space-y-6 max-w-4xl">
      <PageHeader
        title="AI Phone Intake"
        subtitle="AI picks up patient call, verifies eligibility, collects symptoms, routes to CHW or Hospital"
        action={
          <Button variant="outline" className="gap-2" onClick={() => navigate('/community-worker')}>
            <Users className="w-4 h-4" /> Community Workers
          </Button>
        }
      />

      {/* Call Control */}
      <Card className={`p-6 border-0 shadow-sm ${callActive ? 'bg-accent/5 border-l-4 border-l-accent' : 'bg-muted/30'}`}>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className={`w-12 h-12 rounded-full flex items-center justify-center ${callActive ? 'bg-accent/20 animate-pulse' : 'bg-muted'}`}>
              {callActive ? <PhoneCall className="w-6 h-6 text-accent" /> : <Phone className="w-6 h-6 text-muted-foreground" />}
            </div>
            <div>
              <p className="text-sm font-bold">{callActive ? '🔴 Call in Progress — AI Collecting Information' : 'Patient Helpline'}</p>
              <p className="text-xs text-muted-foreground">{callActive ? 'Fill in the details as AI collects them from the patient' : 'Simulate an incoming patient call to the AI helpline'}</p>
            </div>
          </div>
          {!callActive ? (
            <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={startCall}>
              <Phone className="w-4 h-4" /> Simulate Incoming Call
            </Button>
          ) : (
            <Button variant="destructive" className="gap-2" onClick={endCall}>
              <PhoneOff className="w-4 h-4" /> End Call
            </Button>
          )}
        </div>
      </Card>

      {/* STEP 1: Patient Info */}
      {(callActive || intakeData.patient_name) && callStep !== 'done' && (
        <Card className="p-6 border-0 shadow-sm">
          <p className="text-xs font-bold text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">1</span>
            AI Asks: "What is your full name? Date of birth? National ID? Insurance ID?"
          </p>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label className="text-xs">Patient Full Name *</Label>
              <Input className="mt-1" value={intakeData.patient_name} onChange={e => setIntakeData(p => ({ ...p, patient_name: e.target.value }))} placeholder="As told by patient..." />
            </div>
            <div>
              <Label className="text-xs">Date of Birth</Label>
              <Input type="date" className="mt-1" value={intakeData.date_of_birth} onChange={e => setIntakeData(p => ({ ...p, date_of_birth: e.target.value }))} />
            </div>
            <div>
              <Label className="text-xs">National ID</Label>
              <Input className="mt-1" value={intakeData.national_id} onChange={e => setIntakeData(p => ({ ...p, national_id: e.target.value }))} placeholder="1XXXXXXXXXXXXXXXXX" />
            </div>
            <div>
              <Label className="text-xs">Insurance Type</Label>
              <Select value={intakeData.insurance_type} onValueChange={v => setIntakeData(p => ({ ...p, insurance_type: v }))}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select insurer" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="RSSB (RAMA)">RSSB (RAMA)</SelectItem>
                  <SelectItem value="MMI">MMI</SelectItem>
                  <SelectItem value="Mutuelle de Santé">Mutuelle de Santé</SelectItem>
                  <SelectItem value="Private">Private</SelectItem>
                  <SelectItem value="None">None</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label className="text-xs">Insurance ID *</Label>
              <Input className="mt-1" value={intakeData.insurance_id} onChange={e => setIntakeData(p => ({ ...p, insurance_id: e.target.value }))} placeholder="Insurance member ID" />
            </div>
            <div>
              <Label className="text-xs">Phone Number</Label>
              <Input className="mt-1" value={intakeData.phone} onChange={e => setIntakeData(p => ({ ...p, phone: e.target.value }))} placeholder="+250 7XX XXX XXX" />
            </div>
          </div>
          <Button className="mt-4 gap-2" onClick={runEligibilityCheck} disabled={checkingEligibility || !intakeData.patient_name}>
            {checkingEligibility ? <><Loader2 className="w-4 h-4 animate-spin" /> Checking Eligibility...</> : <><ShieldCheck className="w-4 h-4" /> Check Eligibility</>}
          </Button>
        </Card>
      )}

      {/* ELIGIBILITY RESULT — NOT ELIGIBLE */}
      {callStep === 'eligibility' && eligibilityResult && !eligibilityResult.eligible && (
        <Card className="p-6 border-0 shadow-sm border-l-4 border-l-destructive bg-destructive/5">
          <div className="flex items-start gap-4">
            <ShieldX className="w-8 h-8 text-destructive shrink-0" />
            <div className="flex-1">
              <p className="text-base font-bold text-destructive mb-2">Patient Not Eligible</p>
              <div className="p-3 bg-background rounded-lg border border-destructive/20 mb-3">
                <p className="text-xs font-semibold text-muted-foreground mb-1">AI says to patient:</p>
                <p className="text-sm italic">"{eligibilityResult.status_message || 'You are not eligible, so I cannot proceed with your appointment. Sorry.'}"</p>
              </div>
              <p className="text-xs text-muted-foreground">The call will be terminated. No appointment will be created.</p>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            <Button variant="destructive" className="gap-2" onClick={endCall}><PhoneOff className="w-4 h-4" /> End Call</Button>
            <Button variant="outline" onClick={() => setCallStep('info')}>Try Again</Button>
          </div>
        </Card>
      )}

      {/* ELIGIBILITY — ELIGIBLE */}
      {eligibilityResult?.eligible && callStep !== 'done' && (
        <Card className="p-3 border-0 shadow-sm bg-accent/5 border-l-4 border-l-accent flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-accent shrink-0" />
          <div>
            <p className="text-sm font-semibold text-accent">Patient Eligible — {eligibilityResult.plan_name || 'Insurance Verified'}</p>
            <p className="text-xs text-muted-foreground">{eligibilityResult.status_message} {eligibilityResult.co_payment && `· Co-pay: ${eligibilityResult.co_payment}`}</p>
          </div>
        </Card>
      )}

      {/* STEP 2: Symptom Description */}
      {callStep === 'triage' && !triageResult && (
        <Card className="p-6 border-0 shadow-sm">
          <p className="text-xs font-bold text-primary uppercase tracking-wider mb-4 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">2</span>
            AI Asks: "What are you feeling? Why are you calling today?"
          </p>
          <div>
            <Label className="text-xs">Patient's Description *</Label>
            <Textarea className="mt-1" rows={3} value={intakeData.problem_description} onChange={e => setIntakeData(p => ({ ...p, problem_description: e.target.value }))} placeholder="Record exactly what the patient says..." />
            <p className="text-xs text-muted-foreground mt-1">This will be locked and attached to the appointment. Neither doctor nor receptionist can modify it.</p>
          </div>
        </Card>
      )}

      {/* TRIAGE MODULE */}
      {callStep === 'triage' && intakeData.problem_description && (
        <TriageModule intakeData={intakeData} onTriageComplete={handleTriageComplete} />
      )}

      {/* AI Analysis Display */}
      {aiAnalysis && callStep !== 'done' && (
        <Card className={`p-6 border-0 shadow-sm border-l-4 ${aiAnalysis.high_alert ? 'border-l-destructive bg-destructive/5' : 'border-l-primary bg-primary/5'}`}>
          <p className="text-xs font-bold text-primary uppercase tracking-wider mb-3 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">3</span>
            AI Triage Analysis
          </p>
          <div className="flex items-center gap-3 mb-3">
            <Badge className={`text-sm px-4 py-1.5 ${PRIORITY_COLORS[aiAnalysis.priority]}`}>
              {aiAnalysis.priority === 'Critical' ? '🚨' : '📋'} {aiAnalysis.priority} Priority
            </Badge>
            {aiAnalysis.high_alert && (
              <Badge className="bg-destructive text-white flex items-center gap-1">
                <AlertTriangle className="w-3.5 h-3.5" /> HIGH ALERT
              </Badge>
            )}
          </div>
          <p className="text-sm text-foreground/80">{aiAnalysis.ai_summary}</p>
        </Card>
      )}

      {/* STEP 3: Routing Choice */}
      {callStep === 'routing' && aiAnalysis && (
        <Card className="p-6 border-0 shadow-sm border-2 border-primary/30">
          <p className="text-xs font-bold text-primary uppercase tracking-wider mb-2 flex items-center gap-2">
            <span className="w-5 h-5 rounded-full bg-primary text-white flex items-center justify-center text-xs font-bold">4</span>
            AI Asks: "Where would you like to book your appointment?"
          </p>

          {/* AI recommendation banner */}
          <div className={`p-3 rounded-lg text-xs mb-5 flex items-center gap-2 ${appointmentType === 'hospital' ? 'bg-primary/10 border border-primary/20 text-primary' : 'bg-accent/10 border border-accent/20 text-accent'}`}>
            <Sparkles className="w-3.5 h-3.5 shrink-0" />
            <span>
              <strong>AI Suggestion:</strong> {appointmentType === 'hospital' ? 'Hospital / Clinic — Symptoms require a doctor visit.' : 'Community Health Worker — Home pre-screening is sufficient.'}
              {' '}Patient can change this preference.
            </span>
          </div>

          {/* Selection cards */}
          <div className="grid grid-cols-2 gap-4 mb-5">
            <div
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all relative ${appointmentType === 'chw' ? 'border-accent bg-accent/10 shadow-md' : 'border-border hover:border-accent/50'}`}
              onClick={() => setAppointmentType('chw')}
            >
              {appointmentType === 'chw' && (
                <span className="absolute top-2 right-2 w-5 h-5 bg-accent rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                </span>
              )}
              <Users className={`w-9 h-9 mb-3 ${appointmentType === 'chw' ? 'text-accent' : 'text-muted-foreground'}`} />
              <p className={`text-sm font-bold ${appointmentType === 'chw' ? 'text-accent' : ''}`}>Community Health Worker</p>
              <p className="text-xs text-muted-foreground mt-1">A CHW will visit you at home for pre-screening</p>
            </div>
            <div
              className={`p-5 rounded-xl border-2 cursor-pointer transition-all relative ${appointmentType === 'hospital' ? 'border-primary bg-primary/10 shadow-md' : 'border-border hover:border-primary/50'}`}
              onClick={() => setAppointmentType('hospital')}
            >
              {appointmentType === 'hospital' && (
                <span className="absolute top-2 right-2 w-5 h-5 bg-primary rounded-full flex items-center justify-center">
                  <CheckCircle2 className="w-3.5 h-3.5 text-white" />
                </span>
              )}
              <Building2 className={`w-9 h-9 mb-3 ${appointmentType === 'hospital' ? 'text-primary' : 'text-muted-foreground'}`} />
              <p className={`text-sm font-bold ${appointmentType === 'hospital' ? 'text-primary' : ''}`}>Hospital / Clinic</p>
              <p className="text-xs text-muted-foreground mt-1">Book a clinic appointment for in-person screening</p>
            </div>
          </div>

          {/* If CHW: assign worker */}
          {appointmentType === 'chw' && (
            <div className="mb-5">
              <Label className="text-xs font-semibold">Assign Community Worker *</Label>
              <Select value={assignedWorker} onValueChange={setAssignedWorker}>
                <SelectTrigger className="mt-1"><SelectValue placeholder="Select worker..." /></SelectTrigger>
                <SelectContent>
                  {COMMUNITY_WORKERS.map(w => <SelectItem key={w} value={w}>{w}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          )}

          <Button
            className={`w-full gap-2 text-sm py-5 ${appointmentType === 'hospital' ? 'bg-primary hover:bg-primary/90' : 'bg-accent hover:bg-accent/90'}`}
            onClick={saveCase}
            disabled={processing || !appointmentType || (appointmentType === 'chw' && !assignedWorker)}
          >
            {processing ? <><Loader2 className="w-4 h-4 animate-spin" /> Saving...</> : (
              appointmentType === 'hospital'
                ? <><Hospital className="w-4 h-4" /> Book Appointment</>
                : <><UserPlus className="w-4 h-4" /> Assign to Community Worker</>
            )}
          </Button>
        </Card>
      )}

      {/* DONE */}
      {callStep === 'done' && (
        <Card className="p-6 border-0 shadow-sm bg-accent/5 border-l-4 border-l-accent">
          <div className="flex items-start gap-4">
            <CheckCircle2 className="w-8 h-8 text-accent shrink-0" />
            <div className="flex-1">
              <p className="text-base font-bold text-accent">Call Completed Successfully</p>
              <p className="text-xs mt-1">
                <span className={`font-semibold px-2 py-0.5 rounded-full ${isReturningPatient ? 'bg-primary/10 text-primary' : 'bg-accent/10 text-accent'}`}>
                  {isReturningPatient ? '🔄 Returning Patient' : '🆕 New Patient Profile Created'}
                </span>
              </p>
              {appointmentType === 'hospital' && createdAppointmentNumber && (
                <p className="text-sm mt-1">Appointment <span className="font-mono font-bold">{createdAppointmentNumber}</span> created for hospital visit.</p>
              )}
              {appointmentType === 'chw' && (
                <p className="text-sm mt-1">Community Worker case assigned to <span className="font-semibold">{assignedWorker}</span>.</p>
              )}
              <p className="text-xs text-muted-foreground mt-1">AI call notes are locked and attached to the record.</p>
            </div>
          </div>
          <div className="flex gap-2 mt-4">
            {appointmentType === 'hospital' && (
              <Button className="gap-2" onClick={() => navigate('/appointments')}>
                <ArrowRight className="w-4 h-4" /> View Appointments
              </Button>
            )}
            {appointmentType === 'chw' && (
              <Button className="gap-2" onClick={() => navigate('/community-worker')}>
                <Users className="w-4 h-4" /> View Community Workers
              </Button>
            )}
            <Button variant="outline" onClick={reset}>New Call</Button>
          </div>
        </Card>
      )}
    </div>
  );
}