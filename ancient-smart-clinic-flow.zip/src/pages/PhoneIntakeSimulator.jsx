import { useState, useRef } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, PhoneOff, Mic, MicOff, Loader2, CheckCircle2, AlertTriangle, PhoneCall } from "lucide-react";
import { base44 } from "@/api/base44Client";

const PRIORITY_COLORS = {
  Critical: "bg-red-100 text-red-700 border-red-300",
  High: "bg-orange-100 text-orange-700 border-orange-300",
  Medium: "bg-yellow-100 text-yellow-700 border-yellow-300",
  Low: "bg-green-100 text-green-700 border-green-300",
};

const CALL_STATES = {
  IDLE: "idle",
  RINGING: "ringing",
  GREETING: "greeting",
  LISTENING: "listening",
  PROCESSING: "processing",
  RESPONDED: "responded",
  ENDED: "ended",
};

export default function PhoneIntakeSimulator() {
  const [callState, setCallState] = useState(CALL_STATES.IDLE);
  const [transcript, setTranscript] = useState("");
  const [aiResult, setAiResult] = useState(null);
  const [isRecording, setIsRecording] = useState(false);
  const [audioError, setAudioError] = useState("");
  const [callLog, setCallLog] = useState([]);

  const mediaRecorderRef = useRef(null);
  const audioChunksRef = useRef([]);
  const recognitionRef = useRef(null);

  const addLog = (msg) => setCallLog((prev) => [...prev, { time: new Date().toLocaleTimeString(), msg }]);

  const speak = (text, onEnd) => {
    window.speechSynthesis.cancel();
    const utter = new SpeechSynthesisUtterance(text);
    utter.rate = 0.95;
    utter.onend = onEnd || null;
    window.speechSynthesis.speak(utter);
  };

  const startCall = () => {
    setCallState(CALL_STATES.RINGING);
    setAiResult(null);
    setTranscript("");
    setCallLog([]);
    setAudioError("");
    addLog("Incoming call...");

    setTimeout(() => {
      setCallState(CALL_STATES.GREETING);
      addLog("Call connected. AI greeting...");
      speak(
        "Hello and welcome to Murava Health. Muraho kandi murakaza neza. Please describe your health concern after the beep.",
        () => {
          setCallState(CALL_STATES.LISTENING);
          addLog("Listening for patient...");
          startListening();
        }
      );
    }, 1500);
  };

  const startListening = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setAudioError("Your browser doesn't support speech recognition. Try Chrome.");
      setCallState(CALL_STATES.ENDED);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = false;
    recognition.interimResults = false;
    recognition.lang = "en-US";
    recognitionRef.current = recognition;

    setIsRecording(true);

    recognition.onresult = (e) => {
      const text = e.results[0][0].transcript;
      setTranscript(text);
      addLog(`Patient said: "${text}"`);
      setIsRecording(false);
      processSpeech(text);
    };

    recognition.onerror = (e) => {
      setAudioError("Could not capture audio: " + e.error);
      setIsRecording(false);
      setCallState(CALL_STATES.ENDED);
    };

    recognition.onend = () => {
      setIsRecording(false);
    };

    recognition.start();
  };

  const stopListening = () => {
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    setIsRecording(false);
  };

  const processSpeech = async (text) => {
    setCallState(CALL_STATES.PROCESSING);
    addLog("AI analyzing complaint...");

    try {
      const result = await base44.integrations.Core.InvokeLLM({
        prompt: `You are a clinical triage AI for Murava Health in Rwanda.
A patient called and said: "${text}"

Analyze and return a JSON with:
- priority: "Critical" | "High" | "Medium" | "Low"
- patient_feedback: A short, calm spoken response (2-3 sentences) to tell the patient what to do next
- clinical_notes: Brief clinical summary for the healthcare team
- route_to: "Emergency" | "Hospital" | "Community Health Worker" | "Self-care"
- high_alert: true/false (true only if life-threatening)`,
        response_json_schema: {
          type: "object",
          properties: {
            priority: { type: "string" },
            patient_feedback: { type: "string" },
            clinical_notes: { type: "string" },
            route_to: { type: "string" },
            high_alert: { type: "boolean" },
          },
        },
      });

      setAiResult(result);
      addLog(`Triage: ${result.priority} priority — Route to: ${result.route_to}`);

      // Save to database
      try {
        await base44.entities.CommunityWorkerVisit.create({
          patient_name: "Phone Simulator Patient",
          problem_description: text,
          priority: result.priority,
          symptoms: text,
          assessment: result.clinical_notes,
          high_alert: result.high_alert,
          high_alert_reason: result.high_alert ? result.clinical_notes : "",
          intake_source: "AI Phone Call",
          visit_date: new Date().toISOString(),
          status: "Assigned",
        });
        addLog("Saved to system ✓");
      } catch (e) {
        addLog("DB save skipped (demo mode)");
      }

      setCallState(CALL_STATES.RESPONDED);
      speak(result.patient_feedback, () => {
        addLog("AI response delivered. Call ending...");
        setTimeout(() => setCallState(CALL_STATES.ENDED), 1000);
      });
    } catch (err) {
      addLog("AI processing error: " + err.message);
      setCallState(CALL_STATES.ENDED);
    }
  };

  const endCall = () => {
    window.speechSynthesis.cancel();
    stopListening();
    setCallState(CALL_STATES.ENDED);
    addLog("Call ended.");
  };

  const resetCall = () => {
    window.speechSynthesis.cancel();
    setCallState(CALL_STATES.IDLE);
    setAiResult(null);
    setTranscript("");
    setCallLog([]);
    setAudioError("");
  };

  const isActive = [CALL_STATES.RINGING, CALL_STATES.GREETING, CALL_STATES.LISTENING, CALL_STATES.PROCESSING, CALL_STATES.RESPONDED].includes(callState);

  return (
    <div className="max-w-2xl mx-auto p-6 space-y-4">
      {/* Header */}
      <div className="flex items-center gap-3">
        <div className="p-2 bg-primary/10 rounded-lg">
          <PhoneCall className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">AI Phone Intake Simulator</h1>
          <p className="text-muted-foreground text-sm">Test the AI phone agent directly in your browser — no Twilio needed</p>
        </div>
      </div>

      {/* Phone UI */}
      <Card className={`border-2 transition-colors ${isActive ? "border-primary/40 bg-primary/5" : "border-border"}`}>
        <CardContent className="pt-6 pb-6 flex flex-col items-center gap-4">
          {/* Status */}
          <div className="text-center">
            {callState === CALL_STATES.IDLE && <p className="text-muted-foreground">Ready to simulate a patient call</p>}
            {callState === CALL_STATES.RINGING && <p className="text-primary animate-pulse font-medium text-lg">📞 Ringing...</p>}
            {callState === CALL_STATES.GREETING && <p className="text-primary font-medium text-lg flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> AI is greeting the patient...</p>}
            {callState === CALL_STATES.LISTENING && (
              <div className="flex flex-col items-center gap-2">
                <p className="text-green-600 font-medium text-lg flex items-center gap-2">
                  <Mic className="w-5 h-5 animate-pulse" /> Listening... speak now
                </p>
                <p className="text-xs text-muted-foreground">Describe a health complaint out loud</p>
              </div>
            )}
            {callState === CALL_STATES.PROCESSING && <p className="text-orange-600 font-medium text-lg flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> AI analyzing complaint...</p>}
            {callState === CALL_STATES.RESPONDED && <p className="text-blue-600 font-medium text-lg flex items-center gap-2"><Loader2 className="w-4 h-4 animate-spin" /> AI responding to patient...</p>}
            {callState === CALL_STATES.ENDED && <p className="text-muted-foreground font-medium flex items-center gap-2"><CheckCircle2 className="w-4 h-4 text-green-500" /> Call ended</p>}
          </div>

          {/* Phone buttons */}
          <div className="flex gap-3 mt-2">
            {callState === CALL_STATES.IDLE && (
              <Button onClick={startCall} className="gap-2 px-8 py-6 text-base rounded-full bg-green-600 hover:bg-green-700">
                <Phone className="w-5 h-5" /> Simulate Incoming Call
              </Button>
            )}
            {isActive && (
              <Button onClick={endCall} variant="destructive" className="gap-2 px-8 py-6 text-base rounded-full">
                <PhoneOff className="w-5 h-5" /> End Call
              </Button>
            )}
            {callState === CALL_STATES.LISTENING && (
              <Button onClick={stopListening} variant="outline" className="gap-2 px-6 py-6 text-base rounded-full">
                <MicOff className="w-4 h-4" /> Done Speaking
              </Button>
            )}
            {callState === CALL_STATES.ENDED && (
              <Button onClick={resetCall} variant="outline" className="gap-2 px-8">
                <Phone className="w-4 h-4" /> New Call
              </Button>
            )}
          </div>

          {audioError && (
            <div className="flex items-center gap-2 text-red-600 text-sm bg-red-50 px-3 py-2 rounded-md">
              <AlertTriangle className="w-4 h-4" /> {audioError}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Transcript */}
      {transcript && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm text-muted-foreground">Patient Said</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm italic">"{transcript}"</p>
          </CardContent>
        </Card>
      )}

      {/* AI Result */}
      {aiResult && (
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm flex items-center justify-between">
              AI Triage Result
              <div className="flex gap-2">
                <Badge className={PRIORITY_COLORS[aiResult.priority]}>{aiResult.priority} Priority</Badge>
                {aiResult.high_alert && <Badge className="bg-red-600 text-white">⚠ High Alert</Badge>}
              </div>
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-3">
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-1">ROUTE TO</p>
              <p className="text-sm font-semibold text-primary">{aiResult.route_to}</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-1">AI RESPONSE TO PATIENT</p>
              <p className="text-sm bg-muted/40 rounded p-2 italic">"{aiResult.patient_feedback}"</p>
            </div>
            <div>
              <p className="text-xs text-muted-foreground font-medium mb-1">CLINICAL NOTES (for staff)</p>
              <p className="text-sm">{aiResult.clinical_notes}</p>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Call Log */}
      {callLog.length > 0 && (
        <Card className="bg-slate-950 text-slate-100">
          <CardHeader className="pb-2">
            <CardTitle className="text-xs text-slate-400">Call Log</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-1">
              {callLog.map((entry, i) => (
                <p key={i} className="text-xs font-mono">
                  <span className="text-slate-500">[{entry.time}]</span> {entry.msg}
                </p>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}