import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Sparkles, Loader2, MapPin, Star, Phone, Building2, User, ArrowRight, Clock, CalendarCheck, CheckCircle2, Search, ArrowLeft } from 'lucide-react';
import PageHeader from '@/components/shared/PageHeader';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';

const RWANDA_DISTRICTS = [
  'All Districts',
  'Bugesera', 'Burera', 'Gakenke', 'Gasabo', 'Gatsibo', 'Gicumbi', 'Gisagara',
  'Huye', 'Kamonyi', 'Karongi', 'Kayonza', 'Kicukiro', 'Kirehe', 'Muhanga',
  'Musanze', 'Ngoma', 'Ngororero', 'Nyabihu', 'Nyagatare', 'Nyamagabe',
  'Nyamasheke', 'Nyanza', 'Nyarugenge', 'Nyaruguru', 'Rubavu', 'Ruhango',
  'Rulindo', 'Rusizi', 'Rutsiro', 'Rwamagana',
];

export default function Referrals() {
  const urlParams = new URLSearchParams(window.location.search);
  const paramEncounterId = urlParams.get('encounterId') || '';
  const paramAppointmentId = urlParams.get('appointmentId') || '';

  const [diagnosis, setDiagnosis] = useState('');
  const [district, setDistrict] = useState('All Districts');
  const [searching, setSearching] = useState(false);
  const [results, setResults] = useState(null);
  const [selectedDoctor, setSelectedDoctor] = useState(null);
  const navigate = useNavigate();

  // Hospital/Doctor search state
  const [hospitalQuery, setHospitalQuery] = useState('');
  const [hospitalDistrict, setHospitalDistrict] = useState('All Districts');
  const [hospitalSpecialty, setHospitalSpecialty] = useState('');
  const [searchingHospitals, setSearchingHospitals] = useState(false);
  const [hospitalResults, setHospitalResults] = useState(null);

  const { data: encounter } = useQuery({
    queryKey: ['encounter', paramEncounterId],
    queryFn: () => base44.entities.Encounter.filter({ id: paramEncounterId }).then(r => r[0]),
    enabled: !!paramEncounterId,
  });

  useEffect(() => {
    if (encounter) setDiagnosis(encounter.assessment || '');
  }, [encounter]);

  const findSpecialists = async () => {
    if (!diagnosis.trim()) return;
    setSearching(true);
    setSelectedDoctor(null);
    const districtContext = district === 'All Districts' ? 'Search across all 30 districts of Rwanda' : `Patient is from ${district} district`;
    try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a smart referral engine for Rwanda's healthcare system. Based on the diagnosis, suggest the best specialists and facilities across Rwanda.

Diagnosis/ICD-11: ${diagnosis}
District Preference: ${districtContext}

Rwanda healthcare tiers:
- Health Centers (basic care)
- District Hospitals (secondary)
- Referral Hospitals: CHUK, CHUB, RMH (Rwanda Military Hospital)
- King Faisal Hospital (complex/tertiary cases)

Suggest 4-5 specialists/facilities with realistic availability and scheduling information.`,
      model: 'gemini_3_flash',
      response_json_schema: {
        type: 'object',
        properties: {
          referral_specialty: { type: 'string' },
          urgency_level: { type: 'string' },
          suggestions: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                facility_name: { type: 'string' },
                facility_type: { type: 'string' },
                specialist_name: { type: 'string' },
                specialty: { type: 'string' },
                district: { type: 'string' },
                match_score: { type: 'number' },
                phone: { type: 'string' },
                recommendation_reason: { type: 'string' },
                next_available_date: { type: 'string', description: 'e.g. Tomorrow, Within 2 days, Within 5 days, Next week' },
                estimated_wait: { type: 'string', description: 'e.g. Same day, 1-2 days, 3-5 days, 1 week' },
                availability_slots: { type: 'array', items: { type: 'string' }, description: 'e.g. Mon 9am, Tue 2pm' },
                accepts_mutuelle: { type: 'boolean' },
                accepts_rssb: { type: 'boolean' },
                current_queue: { type: 'number', description: 'Current number of patients in queue' },
              }
            }
          }
        }
      }
    });
    setResults(result);
    } catch (e) {
      toast.error('Specialist search failed. Please try again.');
    } finally {
      setSearching(false);
    }
  };

  const searchHospitalsAndDoctors = async () => {
    setSearchingHospitals(true);
    setHospitalResults(null);
    const districtCtx = hospitalDistrict === 'All Districts' ? 'all districts of Rwanda' : hospitalDistrict + ' district';
    try {
    const result = await base44.integrations.Core.InvokeLLM({
      prompt: `You are a hospital and doctor directory for Rwanda's healthcare system.

Search query: "${hospitalQuery || 'All hospitals and doctors'}"
District filter: ${districtCtx}
Specialty filter: "${hospitalSpecialty || 'All specialties'}"

List real hospitals, clinics and doctors in Rwanda matching these criteria. Include:
- Public hospitals, private clinics, referral hospitals
- King Faisal Hospital, CHUK, CHUB, RMH (Rwanda Military Hospital), district hospitals
- Doctors with their specialties

Provide 6-8 results with contact info, services, and doctor availability.`,
      model: 'gemini_3_flash',
      response_json_schema: {
        type: 'object',
        properties: {
          total_found: { type: 'number' },
          results: {
            type: 'array',
            items: {
              type: 'object',
              properties: {
                name: { type: 'string' },
                type: { type: 'string', description: 'Hospital, Clinic, Health Center, Private Practice' },
                district: { type: 'string' },
                address: { type: 'string' },
                phone: { type: 'string' },
                specialties: { type: 'array', items: { type: 'string' } },
                key_doctors: { type: 'array', items: { type: 'string' } },
                accepts_mutuelle: { type: 'boolean' },
                accepts_rssb: { type: 'boolean' },
                emergency_services: { type: 'boolean' },
                working_hours: { type: 'string' },
                beds_available: { type: 'string' },
              }
            }
          }
        }
      }
    });
    setHospitalResults(result);
    } catch (e) {
      toast.error('Hospital search failed. Please try again.');
    } finally {
      setSearchingHospitals(false);
    }
  };

  const urgencyColor = (level) => {
    if (level === 'High' || level === 'Urgent') return 'bg-destructive/10 text-destructive';
    if (level === 'Medium') return 'bg-orange-50 text-orange-600';
    return 'bg-accent/10 text-accent';
  };

  return (
     <div className="space-y-6 max-w-6xl">
       <div className="flex items-center gap-2 mb-4">
         <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
           <ArrowLeft className="w-4 h-4" />
         </Button>
       </div>
       <PageHeader
         title="Smart Referral Engine"
         subtitle="Find the best specialist across all 30 districts of Rwanda with live availability"
         action={
           paramEncounterId && (
             <Button variant="outline" className="gap-2" onClick={() => {
               const p = new URLSearchParams();
               p.set('encounterId', paramEncounterId);
               if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
               if (encounter?.assessment) p.set('disease', encounter.assessment.split(/[\n.]/)[0].slice(0, 80));
               navigate(`/gis-map?${p.toString()}`);
             }}>
               Next: GIS Disease Map <ArrowRight className="w-4 h-4" />
             </Button>
           )
         }
       />

      {encounter && (
        <Card className="p-4 border-0 shadow-sm bg-primary/5">
          <p className="text-xs font-semibold text-primary mb-1">Linked Encounter</p>
          <p className="text-sm font-medium">{encounter.patient_name} — {encounter.chief_complaint || 'Encounter'}</p>
          {encounter.assessment && <p className="text-xs text-muted-foreground mt-1">Assessment: {encounter.assessment}</p>}
        </Card>
      )}

      <Tabs defaultValue="specialist">
        <TabsList className="mb-4">
          <TabsTrigger value="specialist" className="gap-2"><Sparkles className="w-4 h-4" /> Find Specialist by Diagnosis</TabsTrigger>
          <TabsTrigger value="hospital" className="gap-2"><Search className="w-4 h-4" /> Search Hospital / Doctor</TabsTrigger>
        </TabsList>

        {/* Tab 1: Specialist Referral by Diagnosis */}
        <TabsContent value="specialist" className="space-y-4">
          <Card className="p-5 border-0 shadow-sm">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="md:col-span-2">
                <Label className="text-xs">Diagnosis / ICD-11 Code</Label>
                <Input
                  className="mt-1"
                  value={diagnosis}
                  onChange={e => setDiagnosis(e.target.value)}
                  onKeyDown={e => e.key === 'Enter' && findSpecialists()}
                  placeholder="e.g. Type 2 Diabetes Mellitus, 5A11, Cardiac Arrhythmia..."
                />
              </div>
              <div>
                <Label className="text-xs">District Preference</Label>
                <Select value={district} onValueChange={setDistrict}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select district" /></SelectTrigger>
                  <SelectContent>
                    {RWANDA_DISTRICTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </div>
            <Button className="mt-4 gap-2" onClick={findSpecialists} disabled={searching || !diagnosis.trim()}>
              {searching ? <><Loader2 className="w-4 h-4 animate-spin" /> Finding Specialists...</> : <><Sparkles className="w-4 h-4" /> Find Best Specialist</>}
            </Button>
          </Card>

          {results && (
            <>
              <div className="flex items-center gap-3">
                <Badge variant="secondary" className="text-xs">{results.referral_specialty}</Badge>
                <Badge className={`text-xs ${urgencyColor(results.urgency_level)}`}>{results.urgency_level} Urgency</Badge>
              </div>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {results.suggestions?.map((s, idx) => (
                  <Card
                    key={idx}
                    className={`p-5 border-0 shadow-sm hover:shadow-md transition-shadow cursor-pointer ${selectedDoctor === idx ? 'ring-2 ring-primary' : idx === 0 ? 'ring-1 ring-primary/30' : ''}`}
                    onClick={() => setSelectedDoctor(selectedDoctor === idx ? null : idx)}
                  >
                    {idx === 0 && <Badge className="mb-3 text-xs bg-primary/10 text-primary">Best Match</Badge>}
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Building2 className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-bold">{s.facility_name}</p>
                          <p className="text-xs text-muted-foreground">{s.facility_type}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                        <span className="text-sm font-bold">{s.match_score}%</span>
                      </div>
                    </div>
                    <div className="space-y-1.5 mb-3">
                      <div className="flex items-center gap-2 text-sm">
                        <User className="w-3.5 h-3.5 text-muted-foreground" />
                        <span className="font-medium">{s.specialist_name}</span>
                        <Badge variant="secondary" className="text-xs">{s.specialty}</Badge>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <MapPin className="w-3.5 h-3.5" /> {s.district}
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <Phone className="w-3.5 h-3.5" /> {s.phone}
                      </div>
                    </div>
                    <div className="bg-accent/5 rounded-xl p-3 mb-3">
                      <p className="text-xs font-semibold text-accent mb-2 flex items-center gap-1">
                        <CalendarCheck className="w-3.5 h-3.5" /> Availability
                      </p>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <p className="text-xs text-muted-foreground">Next Available</p>
                          <p className="text-xs font-semibold text-accent">{s.next_available_date || 'Within 1 week'}</p>
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Wait Time</p>
                          <p className="text-xs font-semibold">{s.estimated_wait || '3-5 days'}</p>
                        </div>
                        {s.current_queue !== undefined && (
                          <div>
                            <p className="text-xs text-muted-foreground">Current Queue</p>
                            <p className="text-xs font-semibold">{s.current_queue} patients</p>
                          </div>
                        )}
                      </div>
                      {s.availability_slots?.length > 0 && (
                        <div className="mt-2">
                          <p className="text-xs text-muted-foreground mb-1">Open Slots:</p>
                          <div className="flex flex-wrap gap-1.5">
                            {s.availability_slots.map((slot, si) => (
                              <Badge key={si} variant="outline" className="text-xs cursor-pointer hover:bg-primary/10">
                                <Clock className="w-3 h-3 mr-1" />{slot}
                              </Badge>
                            ))}
                          </div>
                        </div>
                      )}
                    </div>
                    <div className="flex gap-2 mb-3">
                      {s.accepts_mutuelle && <Badge className="text-xs bg-green-50 text-green-700"><CheckCircle2 className="w-3 h-3 mr-1" />Mutuelle</Badge>}
                      {s.accepts_rssb && <Badge className="text-xs bg-green-50 text-green-700"><CheckCircle2 className="w-3 h-3 mr-1" />RSSB</Badge>}
                    </div>
                    <p className="text-xs text-muted-foreground leading-relaxed bg-muted/50 rounded-lg p-2.5">
                      {s.recommendation_reason}
                    </p>
                    {selectedDoctor === idx && (
                      <Button className="w-full mt-3 gap-2 bg-accent hover:bg-accent/90" size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          toast.success(`Referral confirmed to ${s.specialist_name} at ${s.facility_name}. Next available: ${s.next_available_date || 'Within 1 week'}`);
                        }}>
                        <CheckCircle2 className="w-4 h-4" /> Confirm Referral to {s.specialist_name}
                      </Button>
                    )}
                  </Card>
                ))}
              </div>
            </>
          )}
        </TabsContent>

        {/* Tab 2: Hospital & Doctor Search by District */}
        <TabsContent value="hospital" className="space-y-4">
          <Card className="p-5 border-0 shadow-sm">
            <p className="text-sm font-semibold mb-3">Search Hospitals & Doctors in Rwanda</p>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <Label className="text-xs">Hospital / Doctor Name (optional)</Label>
                <Input
                  className="mt-1"
                  value={hospitalQuery}
                  onChange={e => setHospitalQuery(e.target.value)}
                  placeholder="e.g. CHUK, King Faisal, Dr. Mugisha..."
                />
              </div>
              <div>
                <Label className="text-xs">District</Label>
                <Select value={hospitalDistrict} onValueChange={setHospitalDistrict}>
                  <SelectTrigger className="mt-1"><SelectValue placeholder="Select district" /></SelectTrigger>
                  <SelectContent>
                    {RWANDA_DISTRICTS.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <Label className="text-xs">Specialty (optional)</Label>
                <Input
                  className="mt-1"
                  value={hospitalSpecialty}
                  onChange={e => setHospitalSpecialty(e.target.value)}
                  placeholder="e.g. Cardiology, Pediatrics, Surgery..."
                />
              </div>
            </div>
            <Button className="mt-4 gap-2" onClick={searchHospitalsAndDoctors} disabled={searchingHospitals}>
              {searchingHospitals ? <><Loader2 className="w-4 h-4 animate-spin" /> Searching...</> : <><Search className="w-4 h-4" /> Search Hospitals & Doctors</>}
            </Button>
          </Card>

          {hospitalResults && (
            <>
              <p className="text-sm text-muted-foreground">{hospitalResults.total_found || hospitalResults.results?.length || 0} results found</p>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {hospitalResults.results?.map((h, idx) => (
                  <Card key={idx} className="p-5 border-0 shadow-sm hover:shadow-md transition-shadow">
                    <div className="flex items-start justify-between mb-3">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center">
                          <Building2 className="w-5 h-5 text-primary" />
                        </div>
                        <div>
                          <p className="text-sm font-bold">{h.name}</p>
                          <p className="text-xs text-muted-foreground">{h.type}</p>
                        </div>
                      </div>
                      {h.emergency_services && (
                        <Badge className="text-xs bg-red-50 text-red-600">24/7 Emergency</Badge>
                      )}
                    </div>
                    <div className="space-y-1.5 mb-3">
                      <div className="flex items-center gap-2 text-xs text-muted-foreground">
                        <MapPin className="w-3.5 h-3.5" /> {h.district} — {h.address}
                      </div>
                      {h.phone && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Phone className="w-3.5 h-3.5" /> {h.phone}
                        </div>
                      )}
                      {h.working_hours && (
                        <div className="flex items-center gap-2 text-xs text-muted-foreground">
                          <Clock className="w-3.5 h-3.5" /> {h.working_hours}
                        </div>
                      )}
                    </div>
                    {h.specialties?.length > 0 && (
                      <div className="mb-3">
                        <p className="text-xs text-muted-foreground mb-1">Specialties:</p>
                        <div className="flex flex-wrap gap-1">
                          {h.specialties.map((sp, i) => <Badge key={i} variant="secondary" className="text-xs">{sp}</Badge>)}
                        </div>
                      </div>
                    )}
                    {h.key_doctors?.length > 0 && (
                      <div className="mb-3">
                        <p className="text-xs text-muted-foreground mb-1">Key Doctors:</p>
                        <div className="space-y-1">
                          {h.key_doctors.map((dr, i) => (
                            <div key={i} className="flex items-center gap-2 text-xs">
                              <User className="w-3 h-3 text-primary" /> {dr}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                    <div className="flex gap-2 mb-3">
                      {h.accepts_mutuelle && <Badge className="text-xs bg-green-50 text-green-700"><CheckCircle2 className="w-3 h-3 mr-1" />Mutuelle</Badge>}
                      {h.accepts_rssb && <Badge className="text-xs bg-green-50 text-green-700"><CheckCircle2 className="w-3 h-3 mr-1" />RSSB</Badge>}
                      {h.beds_available && <Badge variant="outline" className="text-xs">{h.beds_available} beds</Badge>}
                    </div>
                    <Button size="sm" variant="outline" className="w-full gap-2"
                      onClick={() => toast.success(`Referral to ${h.name} noted. Call ${h.phone || 'hospital'} to confirm.`)}>
                      <CheckCircle2 className="w-3.5 h-3.5" /> Refer to This Facility
                    </Button>
                  </Card>
                ))}
              </div>
            </>
          )}
        </TabsContent>
      </Tabs>

      {/* Next Step Bar */}
      {paramEncounterId && (
        <div className="flex gap-3 items-center p-4 bg-muted/30 rounded-xl border">
          <p className="text-sm text-muted-foreground flex-1">Done with referrals?</p>
          <Button className="gap-2 bg-accent hover:bg-accent/90" onClick={() => {
            const p = new URLSearchParams();
            p.set('encounterId', paramEncounterId);
            if (paramAppointmentId) p.set('appointmentId', paramAppointmentId);
            if (encounter?.assessment) p.set('disease', encounter.assessment.split(/[\n.]/)[0].slice(0, 80));
            navigate(`/gis-map?${p.toString()}`);
          }}>
            Next: GIS Map <ArrowRight className="w-4 h-4" />
          </Button>
        </div>
      )}
    </div>
  );
}