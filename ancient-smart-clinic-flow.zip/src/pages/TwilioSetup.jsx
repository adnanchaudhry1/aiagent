import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Phone, CheckCircle2, ExternalLink, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useState } from "react";

const TWILIO_NUMBER = "+18336926331";

const steps = [
  {
    num: 1,
    title: "Log in to Twilio Console",
    desc: "Go to console.twilio.com and sign in.",
    link: "https://console.twilio.com",
    linkLabel: "Open Twilio Console"
  },
  {
    num: 2,
    title: "Go to Phone Numbers",
    desc: 'Navigate to Phone Numbers → Manage → Active Numbers and click on your number: +1 (833) 692-6331.'
  },
  {
    num: 3,
    title: "Set Voice Webhook (A call comes in)",
    desc: 'Under "Voice Configuration", set "A CALL COMES IN" to Webhook and paste the URL below:',
    webhookKey: "incoming"
  },
  {
    num: 4,
    title: "Save and Test",
    desc: `Call ${TWILIO_NUMBER} from any phone. Speak your health concern in English or Kinyarwanda. The AI will triage your call and save it to the system.`
  }
];

// These will be the actual Base44 function endpoint URLs
const WEBHOOK_URLS = {
  incoming: "https://api.base44.com/api/apps/6832a61e9fcbf453b4dcd2d3/functions/twilioVoiceWebhook",
  process: "https://api.base44.com/api/apps/6832a61e9fcbf453b4dcd2d3/functions/twilioProcessSpeech"
};

function CopyableURL({ url }) {
  const [copied, setCopied] = useState(false);
  const copy = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  return (
    <div className="flex items-center gap-2 mt-2 bg-muted rounded-md px-3 py-2">
      <code className="text-xs flex-1 break-all text-foreground">{url}</code>
      <Button size="sm" variant="ghost" onClick={copy} className="shrink-0">
        {copied ? <CheckCircle2 className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
      </Button>
    </div>
  );
}

export default function TwilioSetup() {
  return (
    <div className="max-w-2xl mx-auto p-6 space-y-6">
      <div className="flex items-center gap-3">
        <div className="p-2 bg-primary/10 rounded-lg">
          <Phone className="w-6 h-6 text-primary" />
        </div>
        <div>
          <h1 className="text-2xl font-bold">AI Phone Intake — Twilio Setup</h1>
          <p className="text-muted-foreground text-sm">Connect your Twilio number to the Murava AI health agent</p>
        </div>
      </div>

      {/* Status */}
      <Card>
        <CardContent className="pt-4 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Twilio Number</span>
            <Badge variant="outline">{TWILIO_NUMBER}</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Incoming Call Webhook</span>
            <Badge className="bg-green-100 text-green-700 border-green-200">Ready</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Speech Processing</span>
            <Badge className="bg-green-100 text-green-700 border-green-200">Ready</Badge>
          </div>
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Languages</span>
            <Badge variant="secondary">English + Kinyarwanda</Badge>
          </div>
        </CardContent>
      </Card>

      {/* Webhook URLs */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Your Webhook URLs</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <p className="text-sm font-medium text-muted-foreground">Incoming Call URL (paste this in Twilio)</p>
            <CopyableURL url={WEBHOOK_URLS.incoming} />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Speech Processing URL (auto-used internally)</p>
            <CopyableURL url={WEBHOOK_URLS.process} />
          </div>
        </CardContent>
      </Card>

      {/* Setup Steps */}
      <Card>
        <CardHeader className="pb-2">
          <CardTitle className="text-base">Setup Steps</CardTitle>
        </CardHeader>
        <CardContent className="space-y-5">
          {steps.map((step) => (
            <div key={step.num} className="flex gap-4">
              <div className="w-7 h-7 rounded-full bg-primary text-primary-foreground flex items-center justify-center text-xs font-bold shrink-0 mt-0.5">
                {step.num}
              </div>
              <div className="flex-1">
                <p className="font-medium text-sm">{step.title}</p>
                <p className="text-sm text-muted-foreground mt-0.5">{step.desc}</p>
                {step.link && (
                  <a href={step.link} target="_blank" rel="noopener noreferrer">
                    <Button size="sm" variant="outline" className="mt-2 gap-1">
                      <ExternalLink className="w-3 h-3" />
                      {step.linkLabel}
                    </Button>
                  </a>
                )}
                {step.webhookKey && <CopyableURL url={WEBHOOK_URLS[step.webhookKey]} />}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Rwanda Trial Fix */}
      <Card className="border-orange-200 bg-orange-50">
        <CardHeader className="pb-2">
          <CardTitle className="text-base text-orange-800">⚠️ Calling from Rwanda (Trial Account Fix)</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-orange-700 space-y-2">
          <p><strong>Problem:</strong> Twilio trial accounts only allow calls from verified numbers.</p>
          <p><strong>Fix — verify your Rwanda number:</strong></p>
          <ol className="list-decimal ml-4 space-y-1">
            <li>Go to <a href="https://console.twilio.com/us1/develop/phone-numbers/verified-caller-ids" target="_blank" className="underline font-medium">Twilio → Verified Caller IDs</a></li>
            <li>Click <strong>"Add a new Caller ID"</strong></li>
            <li>Enter your Rwanda number with country code e.g. <strong>+2507XXXXXXXX</strong></li>
            <li>Twilio will call or SMS that number with a verification code</li>
            <li>Once verified, you can call +1 (833) 692-6331 from that number</li>
          </ol>
          <p className="mt-1 font-medium">OR: Upgrade your Twilio account to remove all restrictions.</p>
        </CardContent>
      </Card>

      {/* How It Works */}
      <Card className="bg-muted/30">
        <CardHeader className="pb-2">
          <CardTitle className="text-base">How It Works</CardTitle>
        </CardHeader>
        <CardContent className="text-sm text-muted-foreground space-y-1">
          <p>📞 Patient calls <strong>{TWILIO_NUMBER}</strong> from their Rwanda number</p>
          <p>🤖 AI greets in Kinyarwanda + English</p>
          <p>❓ AI asks: <em>Name → Age → Main complaint → Duration</em></p>
          <p>🧠 AI triages (Critical / High / Medium / Low) and routes to correct care</p>
          <p>🗣️ AI speaks the response + advice back to the patient</p>
          <p>💾 Full intake saved to Community Worker Visits automatically</p>
          <p>📋 Staff review in Phone Intake or Community Worker pages</p>
        </CardContent>
      </Card>
    </div>
  );
}